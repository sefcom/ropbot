from enum import Enum


class Platform(Enum):
    LINUX = 0,
    WINDOWS = 1,
    MAC = 2,
