from arcanist.synthesizer.smt.simplifiers import *
from pysmt.shortcuts import *

def test_z3_simple_bv_sub():
    simplifier = Z3Simplifier()
    a = Symbol("a", BVType(32))
    b = Symbol("b", BVType(32))
    s = simplifier.simplify((a + b) - (b + a))
    assert s == BV(0, 32)