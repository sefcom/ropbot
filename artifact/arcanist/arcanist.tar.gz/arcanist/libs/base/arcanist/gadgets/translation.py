from abc import ABC, abstractmethod
from typing import Generic, TypeVar

from arcanist.architecture import Architecture
from arcanist.gadgets.extraction import RawGadget, RawGadgetLibrary
from arcanist.synthesizer.gadget import GadgetBase, GadgetLibrary

G = TypeVar("G", bound=GadgetBase)


class GadgetTranslator(ABC, Generic[G]):
    @abstractmethod
    def translate_single(self, arch: Architecture, gadget: RawGadget) -> G | None:
        raise NotImplementedError

    @abstractmethod
    def translate_library(self, library: RawGadgetLibrary) -> GadgetLibrary[G]:
        raise NotImplementedError
