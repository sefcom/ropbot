from arcanist.architecture import Architecture
from arcanist.gadgets.extraction import GadgetExtractor, RawGadget, RawGadgetLibrary, UnknownArchitectureError, UnsupportedArchitectureError
from typing import Optional
from ropper.service import RopperService  # type: ignore
from dataclasses import dataclass


def arch_to_ropper_arch_str(arch: Architecture) -> str:
    match arch:
        case Architecture.x86:
            return 'x86'
        case Architecture.x86_64:
            return 'x86_64'
        case Architecture.ARMv7:
            return 'ARM'
        case Architecture.ARMv7_THUMB:
            return 'ARMTHUMB'
        case Architecture.AARCH64:
            return 'ARM64'
        case _:
            raise UnsupportedArchitectureError()


def arch_from_ropper_arch_str(arch: str | None) -> Architecture:
    match arch:
        case 'x86':
            return Architecture.x86
        case 'x86_64':
            return Architecture.x86_64
        case 'ARM':
            return Architecture.ARMv7
        case 'ARMTHUMB':
            return Architecture.ARMv7_THUMB
        case 'ARM64':
            return Architecture.AARCH64
        case None:
            raise UnknownArchitectureError()
        case _:
            raise UnsupportedArchitectureError()


@dataclass
class RopperExtractor(GadgetExtractor):
    inst_count: int | None = None

    def extract_from_elf(self, path: str, base: Optional[int] = None, arch: Optional[Architecture] = None) -> RawGadgetLibrary:
        options = {'color': False}
        if self.inst_count is not None:
            options["inst_count"] = self.inst_count

        rs = RopperService(options)
        elf = path

        rs.addFile(elf)

        if arch is not None:
            arch_str = arch_to_ropper_arch_str(arch)
            rs.setArchitectureFor(name=elf, arch=arch_str)
        else:
            arch_str = str(rs.getFileFor(name=elf).arch)
            arch = arch_from_ropper_arch_str(arch_str)

        if base is not None:
            rs.setImageBaseFor(name=elf, imagebase=base)

        rs.loadGadgetsFor()

        gadgets = []
        for gadget in rs.getFileFor(name=elf).gadgets:
            gadgets.append(RawGadget(gadget.simpleInstructionString(), gadget.address,
                                     bytes(gadget.bytes), len(gadget.lines)))

        return RawGadgetLibrary(arch, gadgets)

    def extract_from_raw(self, path: str, arch: Architecture, base: Optional[int] = None,) -> RawGadgetLibrary:
        options = {'color': False}
        if self.inst_count is not None:
            options["inst_count"] = self.inst_count

        rs = RopperService(options)
        rawbin = path

        rs.addFile(rawbin, arch=arch_to_ropper_arch_str(arch))

        if base is not None:
            rs.setImageBaseFor(name=rawbin, imagebase=base)

        rs.loadGadgetsFor()

        gadgets = []
        for gadget in rs.getFileFor(name=rawbin).gadgets:
            gadgets.append(RawGadget(gadget.simpleInstructionString(), gadget.address,
                                     bytes(gadget.bytes), len(gadget.lines)))

        return RawGadgetLibrary(arch, gadgets)
