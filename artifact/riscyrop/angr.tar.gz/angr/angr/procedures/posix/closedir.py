from __future__ import annotations
from .close import close


# :/
class closedir(close):
    pass
