from collections import deque
from arcanist.translator.binaryninja.workflow.gadget_exit_intrinsic import GADGET_EXIT_INTRINSIC_NAME
from binaryninja import BasicBlockEdge, LowLevelILBasicBlock
from binaryninja.log import log_debug
from binaryninja.architecture import RegisterName
from binaryninja.workflow import Activity, AnalysisContext
from binaryninja.lowlevelil import LowLevelILFunction, LowLevelILLabel, ExpressionIndex, LowLevelILJump, LowLevelILCall, LowLevelILRet, LowLevelILIf, LowLevelILGoto
from binaryninja.enums import LowLevelILOperation, BranchType
from abc import ABC, abstractmethod

from typing import Deque, Dict, List, Set, Tuple

import logging
LOGGER = logging.getLogger(__name__)


class JumpRetCallRewriter(ABC):
    @staticmethod
    @abstractmethod
    def rewrite_call(il: LowLevelILFunction, addr: int, instr_length: int, instr: LowLevelILCall, exit_label: LowLevelILLabel) -> List[ExpressionIndex]:
        raise NotImplementedError()

    @staticmethod
    @abstractmethod
    def rewrite_jump(il: LowLevelILFunction, addr: int, instr_length: int, instr: LowLevelILJump, exit_label: LowLevelILLabel) -> List[ExpressionIndex]:
        raise NotImplementedError()

    @staticmethod
    @abstractmethod
    def rewrite_ret(il: LowLevelILFunction, addr: int, instr_length: int, instr: LowLevelILRet, exit_label: LowLevelILLabel) -> List[ExpressionIndex]:
        raise NotImplementedError()


class ARMv7JumpRetCallRewriter(JumpRetCallRewriter):
    @staticmethod
    def rewrite_call(il: LowLevelILFunction, addr: int, instr_length: int, instr: LowLevelILCall, exit_label: LowLevelILLabel) -> List[ExpressionIndex]:
        return [il.set_reg(
            4, RegisterName('lr'), il.const_pointer(4, addr + 4)),
            il.set_reg(4, RegisterName('pc'), instr.dest.expr_index),
            il.goto(exit_label)]

    @staticmethod
    def rewrite_jump(il: LowLevelILFunction, addr: int, instr_length: int, instr: LowLevelILJump, exit_label: LowLevelILLabel) -> List[ExpressionIndex]:
        return [il.set_reg(4, RegisterName('pc'), instr.dest.expr_index),
                il.goto(exit_label)]

    @staticmethod
    def rewrite_ret(il: LowLevelILFunction, addr: int, instr_length: int, instr: LowLevelILRet, exit_label: LowLevelILLabel) -> List[ExpressionIndex]:
        # in ARM, LLIL_RET is just a jump
        return [il.set_reg(4, RegisterName('pc'), instr.dest.expr_index),
                il.goto(exit_label)]


class x86JumpRetCallRewriter(JumpRetCallRewriter):
    # it should properly encode the semantics of jump/call/ret:
    # - turn everything into a LLIL jump
    # - push 'eip' on call
    # - set 'eip' value
    # - pop 'eip' on ret
    @staticmethod
    def rewrite_call(il: LowLevelILFunction, addr: int, instr_length: int, instr: LowLevelILCall, exit_label: LowLevelILLabel) -> List[ExpressionIndex]:
        ret_addr = addr + instr_length
        return [il.push(4, il.const_pointer(4, ret_addr)), il.set_reg(4, RegisterName('eip'), instr.dest.expr_index),
                il.goto(exit_label)]

    @staticmethod
    def rewrite_jump(il: LowLevelILFunction, addr: int, instr_length: int, instr: LowLevelILJump, exit_label: LowLevelILLabel) -> List[ExpressionIndex]:
        return [il.set_reg(4, RegisterName('eip'), instr.dest.expr_index),
                il.goto(exit_label)]

    @staticmethod
    def rewrite_ret(il: LowLevelILFunction, addr: int, instr_length: int, instr: LowLevelILRet, exit_label: LowLevelILLabel) -> List[ExpressionIndex]:
        return [il.set_reg(4, RegisterName('eip'), il.pop(4)),
                il.goto(exit_label)]


class x86_64JumpRetCallRewriter(JumpRetCallRewriter):
    # it should properly encode the semantics of jump/call/ret:
    # - turn everything into a LLIL jump
    # - push 'rip' on call
    # - set 'rip' value
    # - pop 'rip' on ret
    @staticmethod
    def rewrite_call(il: LowLevelILFunction, addr: int, instr_length: int, instr: LowLevelILCall, exit_label: LowLevelILLabel) -> List[ExpressionIndex]:
        ret_addr = addr + instr_length
        return [il.push(8, il.const_pointer(8, ret_addr)), il.set_reg(8, RegisterName('rip'), instr.dest.expr_index),
                il.goto(exit_label)]

    @staticmethod
    def rewrite_jump(il: LowLevelILFunction, addr: int, instr_length: int, instr: LowLevelILJump, exit_label: LowLevelILLabel) -> List[ExpressionIndex]:
        return [il.set_reg(8, RegisterName('rip'), instr.dest.expr_index),
                il.goto(exit_label)]

    @staticmethod
    def rewrite_ret(il: LowLevelILFunction, addr: int, instr_length: int, instr: LowLevelILRet, exit_label: LowLevelILLabel) -> List[ExpressionIndex]:
        return [il.set_reg(8, RegisterName('rip'), il.pop(8)),
                il.goto(exit_label)]


class JumpRetCallRewriterActivity(Activity):
    _rewriters = {
        'thumb2': ARMv7JumpRetCallRewriter,
        'armv7': ARMv7JumpRetCallRewriter,
        'x86': x86JumpRetCallRewriter,
        'x86_64': x86_64JumpRetCallRewriter
    }

    def __init__(self, configuration: str):
        super().__init__(configuration, handle=None,
                         action=rewrite_jump_ret_call)


def find_back_edges(il: LowLevelILFunction) -> Set[BasicBlockEdge]:
    visited = set()
    back_edges = set()
    queue = deque([il[ExpressionIndex(0)].il_basic_block])
    while queue:
        bb: LowLevelILBasicBlock = queue.popleft()
        log_debug(f"visiting {bb}")
        visited.add(bb)

        for edge in bb.outgoing_edges:
            log_debug(f"visiting {bb} {edge}")
            if edge.target in visited:
                back_edges.add(edge)
                log_debug(f"back edge: {edge}")
            else:
                queue.append(edge.target)
    return back_edges


def check_back_edges_for_if(instr: LowLevelILIf, back_edges: Set[BasicBlockEdge]) -> Tuple[bool, bool]:
    # FIXME: Binary Ninja has a bug in LiftedIL, the il_basic_block is not the correct one!
    # try:
    #     # bb = instr.il_basic_block
    # except AssertionError:
    #     # there's no basic block associated with the instruction
    #     # this means it hasn't been visited during CFG building
    #     # so it must be unreachable anyway
    #     return (False, False)

    bb = None
    for basic_block in instr.function.basic_blocks:
        if basic_block.start <= instr.instr_index and basic_block.end > instr.instr_index:
            bb = basic_block
            break

    if bb is None:
        return (False, False)

    assert len(bb.outgoing_edges) <= 2

    log_debug(f"{bb}")

    edges = bb.outgoing_edges
    is_true_branch_back_edge = any(
        map(lambda edge: edge.type == BranchType.TrueBranch and edge in back_edges, edges))
    is_false_branch_back_edge = any(
        map(lambda edge: edge.type == BranchType.FalseBranch and edge in back_edges, edges))

    # is_true_branch_back_edge = any(
    #     map(lambda edge: edge.type == BranchType.TrueBranch and edge.back_edge, edges))
    # is_false_branch_back_edge = any(
    #     map(lambda edge: edge.type == BranchType.FalseBranch and edge.back_edge, edges))

    return (is_true_branch_back_edge, is_false_branch_back_edge)


def rewrite_jump_ret_call(analysis_context: AnalysisContext) -> None:
    il = analysis_context.lifted_il
    assert il is not None
    num_instrs = len(il)

    back_edges = find_back_edges(il)
    log_debug(f"back edges: {back_edges}")

    arch_name = il.arch.name
    assert isinstance(arch_name, str)
    rewriter = JumpRetCallRewriterActivity._rewriters.get(arch_name)
    if rewriter is None:
        raise NotImplementedError(
            f"No jump/ret/call rewriter available for {arch_name}")

    log_debug(f"num_instrs: {num_instrs}")

    original_labels: Set[int] = set()
    for i in range(num_instrs):
        instr = il[i]
        match instr:
            case LowLevelILIf():
                original_labels.add(instr.true)
                original_labels.add(instr.false)
            case LowLevelILGoto():
                original_labels.add(instr.dest)

    new_labels: Dict[int, LowLevelILLabel] = dict(
        [(original, LowLevelILLabel()) for original in original_labels])
    to_mark_labels: Deque[int] = deque(sorted(original_labels))

    undefined_label = LowLevelILLabel()
    exit_label = LowLevelILLabel()
    num_added_instr = 0

    exits = set()

    for i in range(num_instrs):
        instr = il[i]
        addr = instr.address
        il.set_current_address(addr)
        length = il.view.get_instruction_length(addr)

        if to_mark_labels and to_mark_labels[0] == i:
            original = to_mark_labels.popleft()
            il.mark_label(new_labels[original])
        log_debug(f"instr {i} @ {addr}: {instr}")

        if instr.operation == LowLevelILOperation.LLIL_IF:
            # if it's a back-edge just re-route it to undefined
            # this should ideally be in another pass but rewriting already
            # existing if/goto is a pain with the API...
            is_true_back_edge, is_false_back_edge = check_back_edges_for_if(
                instr, back_edges)
            log_debug(f"is true back {is_true_back_edge}")
            log_debug(f"is false back {is_false_back_edge}")
            t = undefined_label if is_true_back_edge else new_labels[instr.true]
            f = undefined_label if is_false_back_edge else new_labels[instr.false]
            il.append(il.if_expr(instr.condition.expr_index, t, f))

        elif instr.operation == LowLevelILOperation.LLIL_GOTO:
            # no need to check for back edge, because if it's a back-edge
            # then it will never lead to controllable exit, so the basic
            # block will be removed by the 'remove unusable blocks' pass
            g = new_labels[instr.dest]
            il.append(il.goto(g))

        # if the instruction is a LLIL_CALL or LLIL_TAILCALL
        if instr.operation in [LowLevelILOperation.LLIL_CALL, LowLevelILOperation.LLIL_TAILCALL]:
            new_instrs = rewriter.rewrite_call(
                il, addr, length, instr, exit_label)
            for new_instr in new_instrs:
                il.append(new_instr)
            num_added_instr += len(new_instrs) - 1
            log_debug(f"add exit @ {i + num_instrs + num_added_instr}")
            exits.add(i + num_instrs + num_added_instr)

        # otherwise if the instruction is a LLIL_JUMP
        elif instr.operation == LowLevelILOperation.LLIL_JUMP:
            new_instrs = rewriter.rewrite_jump(
                il, addr, length, instr, exit_label)
            for new_instr in new_instrs:
                il.append(new_instr)
            num_added_instr += len(new_instrs) - 1
            log_debug(f"add exit @ {i + num_instrs + num_added_instr}")
            exits.add(i + num_instrs + num_added_instr)

        # otherwise if the instruction is a LLIL_RET
        elif instr.operation == LowLevelILOperation.LLIL_RET:
            new_instrs = rewriter.rewrite_ret(
                il, addr, length, instr, exit_label)
            for new_instr in new_instrs:
                il.append(new_instr)
            num_added_instr += len(new_instrs) - 1
            log_debug(f"add exit @ {i + num_instrs + num_added_instr}")
            exits.add(i + num_instrs + num_added_instr)

        # otherwise if it's another instruction just copy it
        else:
            il.append(il.nop())
            il.replace_expr(il[-1].expr_index, instr)

        # eventually replace the original instruction at its
        # original index with a nop
        il.replace_expr(instr.expr_index, il.nop())

    # everything left to labelize should goto undefined
    if to_mark_labels:
        while to_mark_labels:
            original = to_mark_labels.popleft()
            label = new_labels[original]
            il.mark_label(label)

    undefined_inst_idx = il.undefined()
    il.mark_label(undefined_label)
    il.append(undefined_inst_idx)

    # add the special noreturn instr that marks the endpoint the execution must reach
    # to jump to another gadget
    il.mark_label(exit_label)
    intrinsic_inst_idx = il.intrinsic([], GADGET_EXIT_INTRINSIC_NAME, [il.flag(name)
                                                                       for name in il.arch.flags])
    il.append(intrinsic_inst_idx)
    il.append(il.no_ret())

    il.finalize()

    # saved_addr = il.current_address
    # for bb in il.basic_blocks:
    #     for edge in bb.outgoing_edges:
    #         if edge.back_edge:
    #             LOGGER.debug("BAAAAAAAAAAAAAACK")
    #             last_inst = il[ExpressionIndex(bb.end-1)]
    #             match last_inst:
    #                 case LowLevelILJump():
    #                     il.set_current_address(
    #                         il[ExpressionIndex(last_inst.index)].address)
    #                     il.replace_expr(il[ExpressionIndex(
    #                         last_inst.index)], il.undefined())
    #                     il.set_current_address(saved_addr)
    #                 case LowLevelILIf():
    #                     true_label = new_labels[last_inst.true]
    #                     false_label = new_labels[last_inst.false]

    #                     il.set_current_address(
    #                         il[ExpressionIndex(last_inst.index)].address)

    #                     if edge.type is BranchType.FalseBranch:
    #                         new_if = il.if_expr(
    #                             last_inst.condition.expr_index, true_label, undefined_label)
    #                     else:
    #                         assert edge.type is BranchType.TrueBranch
    #                         new_if = il.if_expr(
    #                             last_inst.condition.expr_index, undefined_label, false_label)

    #                     il.replace_expr(il[ExpressionIndex(
    #                         last_inst.index)], new_if)
    #                     il.set_current_address(saved_addr)
