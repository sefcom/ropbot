from dataclasses import dataclass, field

from .state_builder import StateBuilderBase
from arcanist.synthesizer.gadget import GadgetBase
from pysmt import fnode
from pysmt.shortcuts import FreshSymbol, Symbol, And
from pysmt.solvers.solver import Solver
from pysmt.typing import BVType

from typing import Callable, Optional, List, Any

from .archinfo import ArchInfo
from .state import State
from .memory_layout import MemoryLayout

from abc import ABC, abstractmethod
from more_itertools import sliding_window

import logging
LOGGER = logging.getLogger(__name__)


class Assumptions(ABC):
    @abstractmethod
    def assumptions(self, input: State) -> fnode.FNode:
        raise NotImplementedError


@dataclass(frozen=True)
class SimpleAssumptionFunction(Assumptions):
    func: Callable[[State], fnode.FNode]

    def assumptions(self, input: State) -> fnode.FNode:
        return self.func(input)


class Specifications(ABC):
    @abstractmethod
    def specifications(self, input: State, output: State) -> fnode.FNode:
        raise NotImplementedError


@dataclass(frozen=True)
class SimpleSpecificationFunction(Specifications):
    func: Callable[[State, State], fnode.FNode]

    def specifications(self, input: State, output: State) -> fnode.FNode:
        return self.func(input, output)


def _implication_from_gadget(input: State, output: State, connect_idx: fnode.FNode, mem_layout: MemoryLayout, gadget: GadgetBase, gadget_idx: int) -> fnode.FNode:
    idx_matches = connect_idx.Equals(gadget_idx)
    gadget_connect_states = gadget.connect(input, output, mem_layout)
    return idx_matches.Implies(gadget_connect_states)


def _connect_two_states(input: State, output: State, connect_idx: fnode.FNode, mem_layout: MemoryLayout, gadgets: List[GadgetBase]) -> fnode.FNode:
    ite = gadgets[0].connect(input, output, mem_layout)
    for i in range(1, len(gadgets)):
        idx_matches: fnode.FNode = connect_idx.Equals(i)
        gadget_connect_states = gadgets[i].connect(input, output, mem_layout)
        ite = idx_matches.Ite(gadget_connect_states, ite)
    return ite

    # implications = [
    #     _implication_from_gadget(
    #         input, output, connect_idx, mem_layout, gadgets[i], i)
    #     for i in range(len(gadgets))
    # ]

    # return And(implications)


class OneShotSynthesisInstanceFormulaBuilder:
    def __init__(self, instance_num: int, arch: ArchInfo, chain_len: int, mem_layout: MemoryLayout, assumption: Assumptions, specification: Specifications, state_builder: StateBuilderBase):
        self._mem_layout = mem_layout
        self._assumption = assumption
        self._specification = specification

        num_states = chain_len + 1
        self._states = [state_builder.build_with_name(
            f"instance{instance_num}_state{i}") for i in range(num_states)]

    @property
    def input(self) -> State:
        return self._states[0]

    @property
    def output(self) -> State:
        return self._states[-1]

    def gadget_connect_states(self, gadgets: List[GadgetBase], connect_ids: List[fnode.FNode]) -> fnode.FNode:
        connections = [
            _connect_two_states(input, output, connect_idx,
                                self._mem_layout, gadgets)
            for connect_idx, (input, output) in zip(connect_ids, sliding_window(self._states, 2))
        ]

        return And(connections)

    def assumptions(self) -> fnode.FNode:
        return self._assumption.assumptions(self.input)

    def specifications(self) -> fnode.FNode:
        return self._specification.specifications(self.input, self.output)


class OneShotSynthesisFormulaBuilder:
    def __init__(self, arch: ArchInfo, chain_len: int, gadgets: List[GadgetBase], state_builder_type: type[StateBuilderBase]):
        self._arch = arch
        self._instances: List[OneShotSynthesisInstanceFormulaBuilder] = []
        self._chain_len = chain_len
        self._gadgets = gadgets
        self._state_builder = state_builder_type(arch, gadgets)

        ids_width = len(gadgets).bit_length()
        self._connect_ids = [FreshSymbol(BVType(
            ids_width), f"gadget_id{i}_%d") for i in range(chain_len)]

    def _bound_connect_ids(self) -> fnode.FNode:
        bounds = [(connect_id >= 0) & (connect_id < len(self._gadgets))
                  for connect_id in self._connect_ids]
        return And(bounds)

    def add_instance(self, mem_layout: MemoryLayout, assumption: Assumptions, specification: Specifications) -> None:
        instance = OneShotSynthesisInstanceFormulaBuilder(
            len(self._instances), self._arch, self._chain_len, mem_layout, assumption, specification, self._state_builder)
        self._instances.append(instance)

    def finalize(self) -> fnode.FNode:
        assertions = [self._bound_connect_ids()]

        for instance in self._instances:
            connections = instance.gadget_connect_states(
                self._gadgets, self._connect_ids)
            assumptions = instance.assumptions()
            specifications = instance.specifications()

            assertions.extend([connections, assumptions, specifications])

        return And(assertions)


@dataclass(frozen=True)
class SynthesizedChain:
    chain: List[GadgetBase]
    model: Any


class OneShotSynthesizer:
    _solver: Solver
    _arch: ArchInfo
    _chain_length: int
    _gadgets: List[GadgetBase]
    _formula_builder: OneShotSynthesisFormulaBuilder = field(init=False)

    def __init__(self, _solver: Solver, _arch: ArchInfo, _chain_length: int, _gadgets: List[GadgetBase], state_builder_type: type[StateBuilderBase] = StateBuilderBase) -> None:
        self._solver = _solver
        self._arch = _arch
        self._chain_length = _chain_length
        self._gadgets = _gadgets
        self._formula_builder = OneShotSynthesisFormulaBuilder(
            self._arch, self._chain_length, self._gadgets, state_builder_type)

    def add_instance(self, mem_layout: MemoryLayout, assumption: Assumptions, specification: Specifications) -> None:
        self._formula_builder.add_instance(
            mem_layout, assumption, specification)

    def synthesize(self) -> SynthesizedChain | None:
        formula = self._formula_builder.finalize()
        self._solver.add_assertion(formula)
        sat = self._solver.solve()
        if not sat:
            return None

        model = self._solver.get_model()
        connect_ids = [model.get_value(
            connect_idx).bv2nat() for connect_idx in self._formula_builder._connect_ids]
        chain = [self._gadgets[idx] for idx in connect_ids]

        return SynthesizedChain(chain, model)


class IncrementalSynthesizer:
    _solver: Solver
    _arch: ArchInfo
    _gadgets: List[GadgetBase]

    def __init__(self, solver: Solver, arch: ArchInfo, gadgets: List[GadgetBase], state_builder_type: type[StateBuilderBase] = StateBuilderBase) -> None:
        self._solver = solver
        self._arch = arch
        self._gadgets = gadgets
        self._state_builder = state_builder_type(arch, gadgets)

    def _build_state_transition_formula(self, gadget_id: fnode.FNode, layout: MemoryLayout, input: State, output: State) -> fnode.FNode:
        gadget_id_in_bounds = (gadget_id >= 0) & (
            gadget_id < len(self._gadgets))
        connect_states = _connect_two_states(
            input, output, gadget_id, layout, self._gadgets)
        return And([gadget_id_in_bounds, connect_states])

    def synthesize(self, max_length: int, layout: MemoryLayout, assumptions: Assumptions, specifications: Specifications) -> SynthesizedChain | None:
        if max_length <= 0:
            raise ValueError("chain length must be strictly greater than 0")

        LOGGER.debug(
            f"Trying incremental synthesis of max length {max_length}...")
        ids_width = len(self._gadgets).bit_length()

        gadget_ids: List[fnode.FNode] = []
        states: List[State] = []

        def new_gadget_id() -> fnode.FNode:
            i = len(gadget_ids)
            return FreshSymbol(BVType(ids_width), f"gadget_id{i}_%d")

        def new_state() -> State:
            i = len(states)
            return self._state_builder.build_with_name(f"state{i}")

        LOGGER.debug("Creating initial state...")
        states.append(new_state())
        LOGGER.debug("Asserting assumptions on initial state...")
        self._solver.add_assertion(
            assumptions.assumptions(states[0]), "assumptions")

        while len(gadget_ids) < max_length:
            LOGGER.debug(
                f"Trying to synthesize chain of length {len(gadget_ids)+1}")

            LOGGER.debug("Creating transition gadget id...")
            last_gadget_id = new_gadget_id()
            gadget_ids.append(last_gadget_id)

            LOGGER.debug("Creating new state...")
            last_state = new_state()
            states.append(last_state)

            LOGGER.debug("Building state transition formula to new state...")
            formula = self._build_state_transition_formula(
                last_gadget_id, layout, states[-2], states[-1])
            self._solver.add_assertion(
                formula, f"transition{len(gadget_ids) - 1}")

            LOGGER.debug("Building specifications on final state...")
            spec_formula = specifications.specifications(states[0], states[-1])

            LOGGER.debug("Starting to solve...")
            sat = self._solver.solve([spec_formula])
            if sat:
                LOGGER.debug("Solver returned SAT!")
                model = self._solver.get_model()
                concrete_gadget_ids = [model.get_value(
                    idx).bv2nat() for idx in gadget_ids]
                gadgets = [self._gadgets[idx] for idx in concrete_gadget_ids]
                return SynthesizedChain(gadgets, model)

            LOGGER.debug("Solver returned UNSAT...")

        return None
