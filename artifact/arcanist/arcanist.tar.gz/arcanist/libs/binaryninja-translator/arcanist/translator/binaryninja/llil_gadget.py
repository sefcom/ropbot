from abc import ABC
from collections import deque
from graphlib import TopologicalSorter
from typing import Dict, Iterable, List, Optional, Self, Set, Tuple, cast
from functools import cached_property
from arcanist.gadgets.extraction import RawGadget
from arcanist.translator.binaryninja.gating.expression import GammaExpression, PathExpression
from arcanist.translator.binaryninja.gating.forest import CompressedForest
from arcanist.translator.binaryninja.util import arcanist_arch_to_binja_arch_name, arcanist_platform_to_binja_platform_name
from arcanist.translator.binaryninja.workflow import gadget_analysis_workflow
import arcanist
import arcanist.architecture
import arcanist.platform

import binaryninja
from binaryninja.lowlevelil import Phi, LowLevelILRegPhi, LowLevelILFlagPhi, LowLevelILMemPhi, LowLevelILStore, LowLevelILStoreSsa, LowLevelILRegSplitDestSsa, LowLevelILSetFlag, LowLevelILSetFlagSsa, LowLevelILSetRegStackAbsSsa, LowLevelILSetRegStackRelSsa, LowLevelILSetReg, LowLevelILSetRegSplit, LowLevelILSetRegSsaPartial, LowLevelILSetRegSplitSsa, LowLevelILRegSsa, LowLevelILSetRegSsa, ILRegister, ILFlag, SSAFlag, SSARegister, LowLevelILFunction, LowLevelILIf, LowLevelILNoret, LowLevelILBasicBlock, LowLevelILCall, LowLevelILInstruction, LowLevelILJump, LowLevelILTailcall, LowLevelILRet, ExpressionIndex
from binaryninja.highlight import HighlightColor
from binaryninja.enums import DisassemblyOption, LowLevelILOperation, HighlightStandardColor, BranchType
from binaryninja.types import FunctionBuilder, BoolWithConfidence
from binaryninja.function import DisassemblySettings, Function
from binaryninja.flowgraph import FlowGraph, FlowGraphNode
from binaryninja.basicblock import BasicBlockEdge

from dataclasses import dataclass

import logging
LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True)
class BlockLiveOutInfo:
    block: LowLevelILBasicBlock
    # to each flag associate it's live version at block's exit
    _flags: Dict[ILFlag, SSAFlag]
    # to each reg associate it's live version at block's exit
    _regs: Dict[ILRegister, SSARegister]
    # live version of memory at block's exit
    _mem: int

    def get_live_ssa_register(self, reg: ILRegister) -> SSARegister | None:
        ssa_reg = self._regs.get(reg)
        if ssa_reg is not None:
            return ssa_reg

        # if it's a temporary variable there's no default live version
        if reg.temp:
            return None

        # by default if reg is not in the dict
        # it means that the live version is the default one
        # from the entry, which is the 'version 0'
        return SSARegister(reg, 0)

    def get_live_ssa_flag(self, flag: ILFlag) -> SSAFlag | None:
        ssa_flag = self._flags.get(flag)
        if ssa_flag is not None:
            return ssa_flag

        # if it's a temporary variable there's no default live version
        if flag.temp:
            return None

        # by default if reg is not in the dict
        # it means that the live version is the default one
        # from the entry, which is the 'version 0'
        return SSAFlag(flag, 0)

    def get_live_memory_version(self) -> int:
        return self._mem


@dataclass(frozen=True)
class BlockGatingPathExpression:
    from_entry: PathExpression
    from_immediate_dominator: PathExpression


class BlockOutputCondition(ABC):
    pass


@dataclass(frozen=True)
class MustSatisfyCondition(BlockOutputCondition):
    condition: LowLevelILInstruction


@dataclass(frozen=True)
class MustNotSatisfyCondition(BlockOutputCondition):
    condition: LowLevelILInstruction


class CustomWorkflowSSAGadgetAnalysis:
    def __init__(self) -> None:
        raise TypeError(f"Cannot instantiate {self.__class__.__name__}")

    @classmethod
    def lift(cls, data: bytes, address: int, arch: str, platform: str, asm_str: str) -> Optional['CustomWorkflowSSAGadgetAnalysis.LLILGadget']:
        bv = binaryninja.load(
            data,
            options={
                'loader.imageBase': address,
                'loader.platform': arch,
                'analysis.linearSweep.autorun': False,
                'analysis.mode': 'full',
                'analysis.workflows.functionWorkflow': gadget_analysis_workflow.name,
            })
        bv.platform = binaryninja.Platform[platform]
        func = bv.add_function(address)
        assert func is not None

        try:
            return cls.LLILGadget(func, asm_str)
        except:
            return None

    @classmethod
    def lift_raw_gadget(cls, raw_gadget: RawGadget, arch: arcanist.architecture.Architecture, platform: arcanist.platform.Platform) -> Optional['CustomWorkflowSSAGadgetAnalysis.LLILGadget']:
        binja_arch = arcanist_arch_to_binja_arch_name(
            arch)
        if binja_arch is None:
            raise NotImplementedError("unimplemented architecture")

        binja_platform = arcanist_platform_to_binja_platform_name(
            arch, platform)
        if binja_platform is None:
            raise NotImplementedError("unimplemented platform")

        return cls.lift(raw_gadget.raw_bytes, raw_gadget.address, binja_arch, binja_platform, raw_gadget.assembly_string)

    @staticmethod
    def _find_basic_blocks_that_may_lead_to_controllable_exit(controllable_exit_bbs: List[LowLevelILBasicBlock]) -> Set[LowLevelILBasicBlock]:
        # reverse DFS to find blocks that may lead to controllable exit BBs
        to_visit_bbs = deque(controllable_exit_bbs)
        visited_bbs = set()
        while to_visit_bbs:
            bb = to_visit_bbs.popleft()
            visited_bbs.add(bb)
            for edge in bb.incoming_edges:
                if not edge.back_edge:
                    source = cast(LowLevelILBasicBlock, edge.source)
                    to_visit_bbs.appendleft(source)

        return visited_bbs

    @staticmethod
    def _find_controllable_exit_basic_block(llil: LowLevelILFunction) -> LowLevelILBasicBlock | None:
        # the last instruction should always be the noreturn that we inserted during our
        # custom workflow passes, so we try to get its basic block
        # moreover, because we rewrite all CALL/TAILCALL/JUMP... it should be the only
        # LLIL_NORET instruction in the gadget...
        noret_index = None
        for i in range(len(llil)):
            if isinstance(llil[ExpressionIndex(i)], LowLevelILNoret):
                assert noret_index is None
                noret_index = i

        if noret_index is None:
            return None

        # if it's None, then it's just not reachable!
        return cast(LowLevelILBasicBlock | None, llil.get_basic_block_at(noret_index))

    @staticmethod
    def _find_preconditions_edges(llil: LowLevelILFunction, usable_basic_blocks: Set[LowLevelILBasicBlock]) -> Tuple[
            Dict[LowLevelILBasicBlock, BlockOutputCondition],
            Set[BasicBlockEdge], Set[BasicBlockEdge]]:

        # FIXME: this function is way more complicated than it should be
        # considering what ensures the 'RemoveUnusableBlocks' pass

        block_output_conditions: Dict[LowLevelILBasicBlock,
                                      BlockOutputCondition] = dict()
        must_never_take = set()
        must_always_take = set()

        for bb in llil.basic_blocks:
            if bb not in usable_basic_blocks:
                outgoing = bb.outgoing_edges
                incoming = bb.incoming_edges
                must_never_take.update(outgoing)
                must_never_take.update(incoming)
            else:
                for edge in bb.outgoing_edges:
                    if edge.back_edge:
                        must_never_take.add(edge)

        for bb in llil.basic_blocks:
            outgoing = bb.outgoing_edges
            assert len(outgoing) <= 2

            if len(outgoing) == 2:
                if_instr = llil[ExpressionIndex(bb.end - 1)]
                assert isinstance(if_instr, LowLevelILIf)
                cond = if_instr.condition

                if outgoing[1] not in must_never_take and outgoing[0] in must_never_take:
                    must_always_take.add(outgoing[1])
                    if outgoing[0].type == BranchType.TrueBranch:
                        block_output_conditions[bb] = MustNotSatisfyCondition(
                            cond)
                    else:
                        assert outgoing[0].type == BranchType.FalseBranch
                        block_output_conditions[bb] = MustSatisfyCondition(
                            cond)
                elif outgoing[0] not in must_never_take and outgoing[1] in must_never_take:
                    must_always_take.add(outgoing[0])
                    if outgoing[0].type == BranchType.TrueBranch:
                        block_output_conditions[bb] = MustSatisfyCondition(
                            cond)
                    else:
                        assert outgoing[0].type == BranchType.FalseBranch
                        block_output_conditions[bb] = MustNotSatisfyCondition(
                            cond)

        return block_output_conditions, must_always_take, must_never_take

    class LLILGadget:
        def __init__(self, func: Function, asm_str: str):
            self._asm_str = asm_str
            self._func = func
            self._llil_ssa = func.low_level_il.ssa_form

            exit_bb = CustomWorkflowSSAGadgetAnalysis._find_controllable_exit_basic_block(
                self._llil_ssa)
            if exit_bb is None:
                raise NotImplementedError()

            self._exit_bb = exit_bb

            self._bbs_that_may_lead_to_controllable_exit = CustomWorkflowSSAGadgetAnalysis._find_basic_blocks_that_may_lead_to_controllable_exit(
                [self._exit_bb])
            self._block_output_conditions, self._must_always_take_edges, self._must_never_take_edges = CustomWorkflowSSAGadgetAnalysis._find_preconditions_edges(
                self._llil_ssa, self._bbs_that_may_lead_to_controllable_exit)

        @property
        def assembly_string(self) -> str:
            return self._asm_str

        @property
        def address(self) -> int:
            return self._func.start

        @property
        def llil_ssa(self) -> LowLevelILFunction:
            return self._llil_ssa

        @property
        def exit_basic_block(self) -> LowLevelILBasicBlock:
            return self._exit_bb

        @property
        def must_take_edges(self) -> Set[BasicBlockEdge]:
            return self._must_always_take_edges

        @property
        def must_not_take_edges(self) -> Set[BasicBlockEdge]:
            return self._must_never_take_edges

        @property
        def block_output_condition(self) -> Dict[LowLevelILBasicBlock, BlockOutputCondition]:
            return self._block_output_conditions

        # @property
        # def must_always_satisfy_condition(self) -> Set[LowLevelILInstruction]:
        #     return self._must_always_be_true_conditions

        # @property
        # def must_never_satisfy_condition(self) -> Set[LowLevelILInstruction]:
        #     return self._must_always_be_false_conditions

        def highlighted_flowgraph(self, controllable_color: HighlightColor | HighlightStandardColor = HighlightStandardColor.GreenHighlightColor, uncontrollable_color: HighlightColor | HighlightStandardColor = HighlightStandardColor.RedHighlightColor) -> FlowGraph:
            graph = FlowGraph()
            nodes = dict()

            disasm_settings = DisassemblySettings()
            disasm_settings.set_option(DisassemblyOption.ShowAddress, True)

            for bb in self.llil_ssa:
                node = FlowGraphNode(graph)
                if bb in self._bbs_that_may_lead_to_controllable_exit:
                    node.highlight = controllable_color
                else:
                    node.highlight = uncontrollable_color
                node.lines = bb.get_disassembly_text(disasm_settings)
                graph.append(node)
                nodes[bb] = node

            for bb in self.llil_ssa:
                for ed in bb.outgoing_edges:
                    target = cast(LowLevelILBasicBlock, ed.target)
                    nodes[bb].add_outgoing_edge(ed.type, nodes[target])

            return graph

        @cached_property
        def used_registers(self) -> List[ILRegister]:
            """
            The list of registers (ILRegister) used by the gadget (read or write), excluding the temporary variables ('tempX' registers)
            """
            regs = map(lambda ssa_reg: ssa_reg.reg,
                       self.llil_ssa.ssa_regs_without_versions)
            regs_without_temps = filter(lambda reg: not reg.temp, regs)
            return list(regs_without_temps)

        @cached_property
        def used_flags(self) -> List[ILFlag]:
            """
            The list of flags (ILFlag) used by the gadget (read or write), excluding the temporary variables ('tempX' flags)
            """
            flags = map(lambda ssa_flag: ssa_flag.flag,
                        self.llil_ssa.ssa_flags_without_versions)
            flags_without_temps = filter(lambda flag: not flag.temp, flags)
            return list(flags_without_temps)

        @cached_property
        def basic_blocks_topological_sort(self) -> List[LowLevelILBasicBlock]:
            """
            Topological sort of basic blocks (in llil_ssa)

            Does not consider edges/blocks that cannot lead to controllable exit (i.e in 'must_never_take_edges')
            """
            llil = self.llil_ssa
            sorter: TopologicalSorter = TopologicalSorter()

            for bb in llil.basic_blocks:
                for edge in bb.incoming_edges:
                    source = cast(LowLevelILBasicBlock, edge.source)
                    # do not consider the edge we ensure are not taken
                    if not edge in self._must_never_take_edges:
                        sorter.add(bb, source)

            return list(sorter.static_order())

        @cached_property
        def basic_blocks_liveout_information(self) -> Dict[LowLevelILBasicBlock, BlockLiveOutInfo]:
            # the graph is a DAG because we ignore the back-edges
            # so we do not need any fixpoint algorithm, only topo sort
            liveout_info: Dict[LowLevelILBasicBlock, BlockLiveOutInfo] = dict()
            worklist = self.basic_blocks_topological_sort

            il = self.llil_ssa

            for bb in worklist:
                livein_flags: Dict[ILFlag, SSAFlag] = dict()
                livein_regs: Dict[ILRegister, SSARegister] = dict()
                livein_mem: int = 0

                incoming_edges = filter(
                    lambda edge: edge not in self.must_not_take_edges, bb.incoming_edges)
                parents = map(lambda edge: cast(
                    LowLevelILBasicBlock, edge.source), incoming_edges)
                for parent in parents:
                    livein_flags.update(liveout_info[parent]._flags)
                    livein_regs.update(liveout_info[parent]._regs)
                    livein_mem = liveout_info[parent]._mem

                liveout_flags: Dict[ILFlag, SSAFlag] = livein_flags
                liveout_regs: Dict[ILRegister, SSARegister] = livein_regs
                liveout_mem: int = livein_mem
                for instr in map(lambda i: il[ExpressionIndex(i)], range(bb.start, bb.end)):
                    match instr:
                        # register operations
                        case LowLevelILSetRegSsa():
                            liveout_regs[instr.dest.reg] = instr.dest
                        case LowLevelILSetRegSplitSsa():
                            assert isinstance(instr.lo, LowLevelILRegSplitDestSsa) and isinstance(
                                instr.hi, LowLevelILRegSplitDestSsa)
                            lo_reg = instr.lo
                            hi_reg = instr.hi
                            liveout_regs[lo_reg.dest.reg] = lo_reg.dest
                            liveout_regs[hi_reg.dest.reg] = hi_reg.dest
                        case LowLevelILSetRegSsaPartial():
                            liveout_regs[instr.dest] = instr.full_reg
                        case LowLevelILRegPhi():
                            liveout_regs[instr.dest.reg] = instr.dest

                        case LowLevelILSetRegStackAbsSsa() | LowLevelILSetRegStackRelSsa():
                            raise NotImplementedError(
                                "set reg stack-abs and stack-rel not implemented")

                        # flag operations
                        case LowLevelILSetFlagSsa():
                            liveout_flags[instr.dest.flag] = instr.dest
                        case LowLevelILFlagPhi():
                            liveout_flags[instr.dest.flag] = instr.dest

                        # memory operations
                        case LowLevelILStoreSsa():
                            liveout_mem = instr.dest_memory
                        case LowLevelILMemPhi():
                            liveout_mem = instr.dest_memory

                        # non-ssa guard
                        case LowLevelILSetReg() | LowLevelILSetRegSplit() | LowLevelILSetFlag() | LowLevelILStore():
                            raise TypeError(
                                "ssa version should not contain non-ssa instructions")

                liveout_info[bb] = BlockLiveOutInfo(
                    bb, liveout_flags, liveout_regs, liveout_mem)

            return liveout_info

        def get_register_live_version_at(self, instr_idx: int, reg: ILRegister) -> SSARegister:
            il = self.llil_ssa
            bb = cast(LowLevelILBasicBlock | None,
                      il.get_basic_block_at(instr_idx))
            if bb is None:
                raise IndexError(
                    f"unknown basic block at llil ssa index {instr_idx}")

            instr = il[ExpressionIndex(instr_idx)]
            if isinstance(instr, Phi):
                raise ValueError(
                    "cannot get a unique live version for an instruction in the phi part of a block")

            incoming_edges = filter(
                lambda edge: edge not in self.must_not_take_edges, bb.incoming_edges)
            parents = map(lambda edge: cast(
                LowLevelILBasicBlock, edge.source), incoming_edges)

            live_regs = dict()
            for parent in parents:
                live_regs.update(
                    self.basic_blocks_liveout_information[parent]._regs)

            i = bb.start
            while i != instr_idx:
                current = il[ExpressionIndex(i)]
                match current:
                    case LowLevelILSetRegSsa():
                        live_regs[current.dest.reg] = current.dest
                    case LowLevelILSetRegSplitSsa():
                        assert isinstance(current.lo, LowLevelILRegSplitDestSsa) and isinstance(
                            current.hi, LowLevelILRegSplitDestSsa)
                        lo_reg = current.lo
                        hi_reg = current.hi
                        live_regs[lo_reg.dest.reg] = lo_reg.dest
                        live_regs[hi_reg.dest.reg] = hi_reg.dest
                    case LowLevelILSetRegSsaPartial():
                        live_regs[current.dest] = current.full_reg
                    case LowLevelILRegPhi():
                        live_regs[current.dest.reg] = current.dest
                i += 1

            live_version = live_regs.get(reg)
            if live_version is not None:
                return live_version

            return SSARegister(reg, 0)

        @cached_property
        def basic_blocks_gating_expressions(self) -> Dict[LowLevelILBasicBlock, BlockGatingPathExpression]:
            """
            The gating gamma expressions for basic block.

            Does not consider edges/blocks that cannot lead to controllable exit (i.e in 'must_never_take_edges').

            Conditions that must always be satified to reach a controllable exit are not encoded in the gamma 
            expressions, because we treat them as a precondition to the execution of the gadget, so this avoids
            redundancy.
            """
            llil = self.llil_ssa

            def build_edge_expr(edge: BasicBlockEdge) -> PathExpression:
                if edge.type == BranchType.UnconditionalBranch:
                    return PathExpression(edge.source, edge.target, GammaExpression.make_lambda(edge.source))
                elif edge.type == BranchType.FalseBranch or edge.type == BranchType.TrueBranch:
                    source = cast(LowLevelILBasicBlock, edge.source)
                    if_instr = llil[ExpressionIndex(source.end - 1)]
                    assert isinstance(if_instr, LowLevelILIf)

                    # because of the filter on edges, this edge is guaranteed not to be in must_never_take_edges
                    # so, if the opposite edge is relevant and not a 'must never take'
                    # that-is-to-say if this edge is not a 'must always take'
                    # then encode this edge as a gamma with the associated condition
                    if not edge in self.must_take_edges:
                        if edge.type == BranchType.TrueBranch:
                            return PathExpression(source, edge.target, GammaExpression.make_gamma(if_instr.condition, GammaExpression.make_lambda(source), GammaExpression.make_empty()))
                        else:  # FalseBranch
                            return PathExpression(source, edge.target, GammaExpression.make_gamma(if_instr.condition, GammaExpression.make_empty(), GammaExpression.make_lambda(source)))
                    # if it's a 'must always take' we do not encode the condition because
                    # it should be encoded directly in the gadget's preconditions to avoid redundancy
                    # thus we just consider this edge as a fallthrough here
                    else:
                        # build a lambda with the condition embedded to still keep in mind that even though this edge
                        # should always be taken, it relies on a pre-condition (the embedded condition must be (un)satisfied)
                        return PathExpression(source, edge.target, GammaExpression.make_lambda(source, if_instr.condition))

                raise NotImplementedError("should not reach")

            gating_path_from_idom: Dict[LowLevelILBasicBlock,
                                        PathExpression] = dict()

            forest: CompressedForest = CompressedForest()
            for bb in self._bbs_that_may_lead_to_controllable_exit:
                forest.add_root(bb, PathExpression(
                    bb, bb, GammaExpression.make_lambda()))
                gating_path_from_idom[bb] = PathExpression(
                    bb, bb, GammaExpression.make_lambda())

            toposort = self.basic_blocks_topological_sort
            worklist = list(reversed(toposort))

            for u in worklist:
                # LOGGER.info("-----------------------------------")
                # LOGGER.info(f"u is {u}")
                dom_children = set(
                    cast(List[LowLevelILBasicBlock], u.dominator_tree_children))
                dom_children_topo_order = [
                    n for n in toposort if n in dom_children]

                for v in dom_children_topo_order:
                    # LOGGER.info(f"v is {v}")
                    if not v in self._bbs_that_may_lead_to_controllable_exit:
                        continue

                    forest.update(v, PathExpression(
                        u, v, GammaExpression.make_empty()))

                    for edge in filter(lambda edge: edge not in self.must_not_take_edges, v.incoming_edges):
                        w = edge.source
                        # LOGGER.info(f"w is {w}")

                        edge_path_expr = build_edge_expr(edge)
                        if w == u:
                            union_path_expr = edge_path_expr
                        else:
                            w_path_expr = forest.eval(w)
                            # LOGGER.info(f"w path expr is {w_path_expr}")
                            union_path_expr = w_path_expr.concat(
                                edge_path_expr)

                        path_expr = forest.eval(v).union(union_path_expr)
                        forest.update(v, path_expr)

                    gating_path = forest.eval(v)
                    gating_path_from_idom[v] = gating_path

                    if v == u.immediate_post_dominator:
                        path_expr = PathExpression(
                            gating_path.start, gating_path.end, GammaExpression.make_lambda(u))
                    else:
                        path_expr = gating_path

                    forest.update(v, path_expr)
                    forest.link(u, v)

            gating_expressions = dict()
            for bb in self._bbs_that_may_lead_to_controllable_exit:
                gating_for_bb = BlockGatingPathExpression(
                    forest.eval(bb), gating_path_from_idom[bb])
                gating_expressions[bb] = gating_for_bb

            return gating_expressions
