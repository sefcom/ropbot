from binaryninja.lowlevelil import LowLevelILInstruction
from binaryninja.enums import RegisterValueType

import arcanist.architecture
import arcanist.platform


def _is_value_potentially_controllable(val: LowLevelILInstruction) -> bool:
    _controllable_types = [RegisterValueType.EntryValue,
                           RegisterValueType.UndeterminedValue,
                           RegisterValueType.NotInSetOfValues,
                           RegisterValueType.StackFrameOffset,
                           RegisterValueType.ReturnAddressValue]
    # FIXME:
    # if possible_values.type == RegisterValueType.UnsignedRangeValue?
    # for example edx = edx + ecx; jump(rdx) will return a possible range
    # of [0 - 0xffffffff], should we consider that valid?
    return val.possible_values.type in _controllable_types


def binaryninja_arch_name_to_arcanist_arch(arch_name: str) -> arcanist.architecture.Architecture | None:
    match arch_name:
        case 'x86':
            return arcanist.architecture.Architecture.x86
        case 'x86_64':
            return arcanist.architecture.Architecture.x86_64
        case 'armv7':
            return arcanist.architecture.Architecture.ARMv7
        case 'thumb2':
            return arcanist.architecture.Architecture.ARMv7_THUMB
        case 'aarch64':
            return arcanist.architecture.Architecture.AARCH64

    return None


def arcanist_arch_to_binja_arch_name(arch: arcanist.architecture.Architecture) -> str | None:
    match arch:
        case arcanist.architecture.Architecture.x86:
            return 'x86'
        case arcanist.architecture.Architecture.x86_64:
            return 'x86_64'
        case arcanist.architecture.Architecture.ARMv7:
            return 'armv7'
        case arcanist.architecture.Architecture.ARMv7_THUMB:
            return 'thumb2'
        case arcanist.architecture.Architecture.AARCH64:
            return 'aarch64'

    return None


def arcanist_platform_to_binja_platform_name(arch: arcanist.architecture.Architecture, plat: arcanist.platform.Platform) -> str | None:
    arch_name = arcanist_arch_to_binja_arch_name(arch)
    if arch_name is None:
        return None

    match plat:
        case arcanist.platform.Platform.LINUX:
            plat_name = 'linux'
        case arcanist.platform.Platform.WINDOWS:
            plat_name = 'windows'
        case arcanist.platform.Platform.MAC:
            plat_name = 'mac'
        case _:
            return None

    return f"{plat_name}-{arch_name}"
