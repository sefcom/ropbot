from arcanist.synthesizer.archinfo import ArchInfo
from arcanist.synthesizer.gadget import GadgetBase
from arcanist.synthesizer.state import State

from typing import List

import logging
LOGGER = logging.getLogger(__name__)


class StateBuilderBase:
    def __init__(self, arch: ArchInfo, _gadgets: List[GadgetBase]):
        self._arch = arch

    @property
    def arch(self) -> ArchInfo:
        return self._arch

    def build_with_name(self, name: str) -> State:
        regs = self.arch.register_symbols(name)
        flags = self.arch.flag_symbols(name)
        mem = self.arch.memory_symbol(name)
        return State(self.arch, regs, flags, mem)


class OnlyUsedRegisterStateBuilder(StateBuilderBase):
    def __init__(self, arch: ArchInfo, _gadgets: List[GadgetBase]):
        super().__init__(arch, _gadgets)
        used_regs = set()
        for gadget in _gadgets:
            used_regs.update(gadget.used_regs)
        LOGGER.debug(f"used regs: {used_regs}")
        self._filter = lambda reg_info: reg_info.name in used_regs

    def build_with_name(self, name: str) -> State:
        regs = self.arch.register_symbols(name, self._filter)
        flags = self.arch.flag_symbols(name)
        mem = self.arch.memory_symbol(name)
        return State(self.arch, regs, flags, mem)
