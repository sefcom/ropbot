from binaryninja.workflow import Activity, AnalysisContext
from binaryninja.lowlevelil import ExpressionIndex, SSAFlag, LowLevelILFlagPhi, LowLevelILRegPhi, SSARegister, LowLevelILIntrinsic, LowLevelILUndef, LowLevelILUnimpl, LowLevelILInstruction, LowLevelILSetFlag, LowLevelILBasicBlock, LowLevelILSetReg, ExpressionIndex, LowLevelILNoret, LowLevelILFunction, LowLevelILBasicBlock
from binaryninja.enums import LowLevelILOperation
from binaryninja.log import log_debug, log_error
from binaryninja.architecture import RegisterIndex

from typing import List, cast


def remove_temp0_from_phis(analysis_context: AnalysisContext) -> None:
    # analysis_context.llil.generate_ssa_form()
    il = analysis_context.llil.ssa_form

    def is_temp_version_0(ssa_reg: SSARegister) -> bool:
        return ssa_reg.reg.temp and ssa_reg.version == 0

    def is_not_temp_version_0(ssa_reg: SSARegister) -> bool:
        return not is_temp_version_0(ssa_reg)

    def is_cond_version_0(ssa_flag: SSAFlag) -> bool:
        return ssa_flag.flag.temp and ssa_flag.version == 0

    def is_not_cond_version_0(ssa_flag: SSAFlag) -> bool:
        return not is_cond_version_0(ssa_flag)

    for i in range(len(il)):
        instr = il[ExpressionIndex(i)]
        operand_list: List[int] = []
        if isinstance(instr, LowLevelILRegPhi) and any(map(is_temp_version_0, instr.src)):
            for ssa_reg in filter(is_not_temp_version_0, instr.src):
                operand_list.append(ssa_reg.reg.index)
                operand_list.append(ssa_reg.version)

            ###########################################################################################
            # Removed because we still want to know whether we are in the 'phi part' of a basic block #
            # so even if there's only one candidate, still keep it as a phi                           #
            ###########################################################################################
            # if len(operand_list) == 2:
            #     src_expr = il.expr(LowLevelILOperation.LLIL_REG_SSA,
            #                        operand_list[0], operand_list[1], size=il.arch.address_size)
            #     dest_index = instr.dest.reg.index
            #     dest_version = instr.dest.version
            #     # only one candidate left
            #     phi = il.expr(LowLevelILOperation.LLIL_SET_REG_SSA, dest_index, dest_version,
            #                   src_expr, size=il.arch.address_size, flags=0)
            ###########################################################################################

            if len(operand_list):
                candidates_expr = il.add_operand_list(
                    cast(List[ExpressionIndex], operand_list))

                dest_reg_index = instr.dest.reg.index
                dest_reg_version = instr.dest.version

                reg_phi = il.expr(LowLevelILOperation.LLIL_REG_PHI,
                                  ExpressionIndex(dest_reg_index), ExpressionIndex(dest_reg_version), ExpressionIndex(len(operand_list)), candidates_expr, size=0, flags=None)
            else:
                raise ValueError(
                    "no more candidates for phi, should not happen")

            # replace the phi
            il.replace_expr(instr, reg_phi)

        elif isinstance(instr, LowLevelILFlagPhi) and any(map(is_cond_version_0, instr.src)):
            for ssa_flag in filter(is_not_cond_version_0, instr.src):
                operand_list.append(ssa_flag.flag.index)
                operand_list.append(ssa_flag.version)

            if len(operand_list):
                candidates_expr = il.add_operand_list(
                    cast(List[ExpressionIndex], operand_list))

                dest_flag_index = instr.dest.flag.index
                dest_flag_version = instr.dest.version

                flag_phi = il.expr(LowLevelILOperation.LLIL_FLAG_PHI,
                                   ExpressionIndex(dest_flag_index), ExpressionIndex(dest_flag_version), ExpressionIndex(len(operand_list)), candidates_expr, size=0, flags=None)
            else:
                raise ValueError(
                    "no more candidates for phi, should not happen")

            # replace the phi
            il.replace_expr(instr, flag_phi)


class RemoveTemp0FromPhisActivity(Activity):
    def __init__(self, configuration: str):
        super().__init__(configuration, handle=None,
                         action=remove_temp0_from_phis)
