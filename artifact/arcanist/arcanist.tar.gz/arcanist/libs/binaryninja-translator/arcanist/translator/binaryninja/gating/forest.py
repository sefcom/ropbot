###############################################################################
# this code is adapted from https://crates.io/crates/elu
###############################################################################

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, TypeVar, Generic

from arcanist.translator.binaryninja.gating.expression import Expression, PathExpression


K = TypeVar("K")


@dataclass
class Node:
    parent: Node | None
    value: PathExpression

    @property
    def is_root(self) -> bool:
        return self.parent is None


class KeyAlreadyAssignedError(Exception):
    pass


class CompressedForest(Generic[K]):
    def __init__(self) -> None:
        self._nodes: Dict[K, Node] = dict()

    def add_root(self, key: K, value: PathExpression) -> None:
        if self._nodes.get(key) is not None:
            # TODO: better error message
            raise KeyAlreadyAssignedError()

        self._nodes[key] = Node(None, value)

    def eval_all(self) -> Dict[K, PathExpression]:
        res = dict()
        for key in self._nodes:
            val = self.eval(key)
            res[key] = val
        return res

    def eval(self, key: K) -> PathExpression:
        node = self._nodes[key]
        if not node.is_root:
            self._compress(node)

        match node.parent:
            case None:
                return node.value
            case _:
                return node.parent.value.concat(node.value)

    def update(self, key: K, value: PathExpression) -> None:
        node = self._nodes[key]

        if node.is_root:
            node.value = value
        else:
            self._compress(node)
            # node is not root and compress ensure parent is root
            assert node.parent is not None
            parent = node.parent
            parent.value = value

    def link(self, key_a: K, key_b: K) -> None:
        node_a = self._nodes[key_a]
        node_b = self._nodes[key_b]

        if node_a.parent is None:
            root_a = node_a
        else:
            self._compress(node_a)
            root_a = node_a.parent

        if node_b.parent is None:
            root_b = node_b
        else:
            self._compress(node_b)
            root_b = node_b.parent

        root_b.parent = root_a
        # if "node a" is not the root of it's tree
        # need to update the value of "node b"
        if root_a != node_a:
            new_value = node_a.value.concat(root_b.value)
            root_b.value = new_value

    def _compress(self, node: Node) -> None:
        # assume it's not a root
        assert node.parent is not None
        parent = node.parent

        # while the parent is not a root
        if not parent.is_root:
            # TODO: get rid of recursive call
            self._compress(parent)

            node_val = node.value
            parent_val = parent.value
            parent_of_parent = parent.parent

            merged_values = parent_val.concat(node_val)
            node.value = merged_values
            node.parent = parent_of_parent
