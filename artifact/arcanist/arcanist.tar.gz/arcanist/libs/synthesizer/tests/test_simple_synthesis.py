from collections import OrderedDict
from typing import Set
from arcanist.synthesizer.gadget import GadgetBase
from pysmt.fnode import FNode
from pysmt.shortcuts import And, TRUE, Solver
from pysmt.logics import QF_AUFBV
from arcanist.architecture import Endian
from arcanist.synthesizer.archinfo import ArchInfo, RegInfo
from arcanist.synthesizer.memory import TaintedMemory
from arcanist.synthesizer.memory_layout import MemoryLayout
from arcanist.synthesizer.state import State
from arcanist.synthesizer.synthesis import Assumptions, Specifications, OneShotSynthesizer
from arcanist.synthesizer.tainted_types.bitvec import TaintedBitvec


def test_dummy_synthesis():
    class DummyGadget(GadgetBase):
        def __init__(self):
            pass

        def connect(self, input: State, output: State, mem_layout: MemoryLayout) -> FNode:
            assertions = [input.memory.Equals(output.memory)]
            for in_reg, out_reg in zip(input.registers.values(), output.registers.values()):
                assertions.append(in_reg.Equals(out_reg))
            return And(assertions)

        def assembly_str(self) -> str:
            return "nop"

        def used_regs(self) -> Set[str]:
            return set()

        def has_store_operation(self) -> bool:
            return False

    class DummyAssumptions(Assumptions):
        def __init__(self):
            pass

        def assumptions(self, input: State) -> FNode:
            endian = input.arch_info.endian
            ptr_width = input.arch_info.pointer_width
            assertions = [input.memory.Equals(
                TaintedMemory.new_zero_untainted(endian, ptr_width))]
            for reg in input.registers.values():
                assertions.append(reg.Equals(
                    TaintedBitvec.new_zero_untainted(reg.bv_width)))

            return And(assertions)

    class DummySpecifications(Specifications):
        def __init__(self):
            pass

        def specifications(self, input: State, output: State) -> FNode:
            return TRUE()

    regs = OrderedDict({"r0": RegInfo("r0", 32), "pc": RegInfo("pc", 32)})
    flags = OrderedDict()
    arch = ArchInfo(Endian.Little, 32, regs, flags, "pc")
    solver = Solver(logic=QF_AUFBV, name='z3')
    synthesizer = OneShotSynthesizer(solver, arch, 1, [DummyGadget()])
    synthesizer.add_instance(
        MemoryLayout(), DummyAssumptions(), DummySpecifications())
    assert synthesizer.synthesize() is not None


def test_plus_two_synthesis():
    class PlusOneGadget(GadgetBase):
        def __init__(self):
            pass

        def connect(self, input: State, output: State, mem_layout: MemoryLayout) -> FNode:
            assertions = [input.memory.Equals(output.memory)]
            for in_reg, out_reg in zip(input.registers.values(), output.registers.values()):
                assertions.append((in_reg + 1).Equals(out_reg))
            return And(assertions)

        def assembly_str(self) -> str:
            return "r0 = r0 + 1\npc = pc + 1"

        def used_regs(self) -> Set[str]:
            return set(["r0", "pc"])

        def has_store_operation(self) -> bool:
            return False

    class AllZeroAssumptions(Assumptions):
        def __init__(self):
            pass

        def assumptions(self, input: State) -> FNode:
            endian = input.arch_info.endian
            ptr_width = input.arch_info.pointer_width
            assertions = [input.memory.Equals(
                TaintedMemory.new_zero_untainted(endian, ptr_width))]
            for reg in input.registers.values():
                assertions.append(reg.Equals(
                    TaintedBitvec.from_int(0, reg.bv_width)))

            return And(assertions)

    class AllTwoSpecifications(Specifications):
        def __init__(self):
            pass

        def specifications(self, input: State, output: State) -> FNode:
            assertions = []
            for in_reg, out_reg in zip(input.registers.values(), output.registers.values()):
                assertions.append((in_reg + 2).Equals(out_reg))
            return And(assertions)

    regs = OrderedDict({"r0": RegInfo("r0", 32), "pc": RegInfo("pc", 32)})
    flags = OrderedDict()
    arch = ArchInfo(Endian.Little, 32, regs, flags, "pc")
    solver = Solver(logic=QF_AUFBV, name='z3')
    synthesizer = OneShotSynthesizer(solver, arch, 2, [PlusOneGadget()])
    synthesizer.add_instance(
        MemoryLayout(), AllZeroAssumptions(), AllTwoSpecifications())
    chain = synthesizer.synthesize()
    assert chain is not None
