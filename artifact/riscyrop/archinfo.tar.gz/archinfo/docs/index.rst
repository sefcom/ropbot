Welcome to archinfo's documentation!
====================================


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Readme <readme>
   API <api>


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
