import argparse

from arcanist.extractor.ropper import RopperExtractor
from arcanist.platform import Platform
from arcanist.synthesizer.gadget import JSONGadget
from arcanist.synthesizer.smt.simplifiers import Z3Simplifier
from arcanist.translator.binaryninja.translate import BinaryNinjaTranslator
from arcanist.architecture import Architecture

from timeit import default_timer as timer

import json

import logging
logging.basicConfig(level=logging.NOTSET,
                    format="[%(levelname)s] (%(name)s) %(message)s")
LOGGER = logging.getLogger('arcanist-extractor')


def main():
    parser = argparse.ArgumentParser(
        description="Extract gadgets from binary and serialize as JSON"
    )

    parser.add_argument("binary", help="Path to the target binary")
    parser.add_argument("output", help="Path to the output JSON file")

    format_group = parser.add_subparsers(dest="format")
    format_group.default = "elf"
    format_group.add_parser("elf", help="ELF file format")
    raw_parser = format_group.add_parser("raw", help="RAW file format")
    raw_parser.add_argument("arch", help="Archictecture of RAW binary", type=str, choices=[
                            "x86_64", "ARMv7", "ARMv7_THUMB"], default='x86_64')

    parser.add_argument(
        "--baseaddr", help="Base address of binary", type=lambda x: int(x, 0), default=0)
    parser.add_argument(
        "--log", help="Path to optional result log file", default=None)

    parser.add_argument(
        "--inst_count", help="Max number of instructions in a gadget", type=int, default=None)

    args = parser.parse_args()

    start = timer()
    extractor = RopperExtractor(args.inst_count)

    LOGGER.info(f"Extracting gadgets from {args.binary}...")
    if args.format == "elf":
        raw_library = extractor.extract_from_elf(
            args.binary, args.baseaddr, None)
    elif args.format == "raw":
        match args.arch:
            case "x86_64":
                arch = Architecture.x86_64
            case "ARMv7":
                arch = Architecture.ARMv7
            case "ARMv7_THUMB":
                arch = Architecture.ARMv7_THUMB
        raw_library = extractor.extract_from_raw(
            args.binary, arch, args.baseaddr)

    raw_count = len(raw_library.gadgets)
    LOGGER.info(f"Done extracting {raw_count} gadgets")

    translator = BinaryNinjaTranslator(Platform.LINUX, Z3Simplifier())
    LOGGER.info("Translating gadgets...")
    translated_library = translator.translate_library_json(
        raw_library)
    translated_count = len(translated_library.gadgets)
    LOGGER.info(f"Done translating {translated_count} gadgets")
    elapsed = timer() - start
    LOGGER.info(f"Extraction and translation done in {elapsed}s")

    LOGGER.info(f"Saving library to {args.output}...")
    with open(args.output, "w") as f:
        f.write(translated_library.to_json_str())

    if args.log:
        LOGGER.info(f"Saving log results to {args.log}...")
        with open(args.log, "w") as f:
            json.dump({"time": elapsed, "raw_count": raw_count,
                       "translated_count": translated_count}, f)


if __name__ == '__main__':
    main()
