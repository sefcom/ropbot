from pysmt.simplifier import Simplifier
from pysmt.solvers.z3 import Z3Converter, Z3Solver
from collections import deque

from pysmt import fnode

import z3  # type: ignore

from typing import Deque, Any, List

import logging
LOGGER = logging.getLogger(__name__)


class CustomFormulaSimplifier(Simplifier):
    def walk_bv_sub(self, formula, args, **kwargs):
        # LOGGER.info(f"visiting BVSUB: {formula}")
        left = args[0]
        right = args[1]

        # # case (a - const) => a + (-const)
        # if right.is_constant():
        #     opposite_right = self.walk_bv_neg(self.manager.BVNeg(right), [right], **kwargs)
        #     return self.walk_bv_add(self.manager.BVAdd([left, opposite_right]), [left, opposite_right], **kwargs)

        # case (a - b) - c => a - (b + c)
        if left.is_bv_sub():
            new_right_args = [left.arg(1), right]
            new_right = self.walk_bv_add(self.manager.BVAdd(
                new_right_args), new_right_args, **kwargs)
            new_left = left.arg(0)
            new_sub = self.manager.BVSub(new_left, new_right)
            return self.walk_bv_sub(new_sub, [new_left, new_right], **kwargs)

        # case a - (b - c) => (a + c) - b
        elif right.is_bv_sub():
            new_left_args = [left, right.arg(1)]
            new_left = self.walk_bv_add(self.manager.BVAdd(
                new_left_args), new_left_args, **kwargs)
            new_right = right.arg(0)
            new_sub = self.manager.BVSub(new_left, new_right)
            return self.walk_bv_sub(new_sub, [new_left, new_right], **kwargs)

        # case (a + const) - b => (a - b) + const
        elif left.is_bv_add():
            last_left = left.args()[-1]
            if last_left.is_constant():
                new_left = self.manager.BVAdd(left.args()[:-1])
                new_sub = self.walk_bv_sub(self.manager.BVSub(
                    new_left, right), [new_left, right], **kwargs)
                return self.walk_bv_add(self.manager.BVAdd([new_sub, last_left]), [new_sub, last_left], **kwargs)

        # case a - (b + const) => (a - b) + -const
        elif right.is_bv_add():
            last_right = right.args()[-1]
            if last_right.is_constant():
                new_right = self.manager.BVAdd(right.args()[:-1])
                new_sub = self.walk_bv_sub(self.manager.BVSub(
                    left, new_right), [left, new_right], **kwargs)
                opposite_const = self.walk_bv_neg(
                    self.manager.BVNeg(last_right), [last_right], **kwargs)
                return self.walk_bv_add(self.manager.BVAdd([new_sub, opposite_const]), [new_sub, opposite_const], **kwargs)

        # elif left.is_bv_add() and right.is_bv_add():
        #     last_left = left.args()[-1]
        #     last_right = right.args()[-1]

        #     if last_left.is_constant() or last_right.is_constant():
        #         const_left = last_left.bv_unsigned_value() if last_left.is_constant() else 0
        #         const_right = last_right.bv_unsigned_value() if last_right.is_constant() else 0
        #         const_diff = (2**width + const_left - const_right) % (2**width)
        #         LOGGER.info(const_diff)

        #         new_left = self.manager.BVAdd(left.args()[:-1]) if last_left.is_constant() else left
        #         new_right = self.manager.BVAdd(right.args()[:-1]) if last_right.is_constant() else right
        #         new_sub = self.manager.BVSub(new_left, new_right)

        #         if const_diff != 0:
        #             const = self.manager.BV(const_diff, width)
        #             res = self.manager.BVAdd([new_sub, const])
        #         else:
        #             res = new_sub

        #         return res

        return super().walk_bv_sub(formula, args, **kwargs)

    def walk_bv_add(self, formula, args, **kwargs) -> fnode.FNode:
        # LOGGER.info(f"visiting BVADD: {formula}")

        constant_acc = 0
        to_sum: List[fnode.FNode] = []
        to_sub: List[fnode.FNode] = []
        width = formula.bv_width()

        rewrite = False
        constant_count = 0

        worklist: Deque[Any] = deque(args)
        while worklist:
            operand = worklist.popleft()
            if operand.is_constant():
                constant_acc += operand.bv_unsigned_value()
                constant_count += 1
                # if there's more than one constant, rewrite
                # or if there's still element(s) in the worklist (i.e. the constant is not the last arg), rewrite
                if constant_count > 1 or worklist:
                    rewrite = True
            elif operand.is_bv_add():
                worklist.extendleft(reversed(operand.args()))
                # need to flatten, rewrite
                rewrite = True
            elif operand.is_bv_sub():
                # there're other elements, rewrite
                if len(to_sum) > 0:
                    rewrite = True
                to_sum.append(operand.arg(0))
                to_sub.append(operand.arg(1))
            else:
                # there's a nested sub, rewrite
                if len(to_sub) > 0:
                    rewrite = True
                to_sum.append(operand)

        if not rewrite:
            return self.manager.BVAdd(args)

        constant_acc %= 2**width
        const = self.manager.BV(constant_acc, width)
        if not (to_sum or to_sub):
            return const

        if not to_sub and constant_acc:
            to_sum.append(const)

        res = self.manager.BVAdd(to_sum) if to_sum else None
        res = self.walk_bv_add(res, to_sum, **kwargs) if to_sum else None

        if to_sub:
            sub_part = self.walk_bv_add(
                self.manager.BVAdd(to_sub), to_sub, **kwargs)
            if res:
                res = self.walk_bv_sub(self.manager.BVSub(
                    res, sub_part), [res, sub_part], **kwargs)
            else:
                res = self.manager.BVNeg(sub_part)

            # put the constant at top level on the right
            if constant_acc:
                res = self.walk_bv_add(self.manager.BVAdd(
                    [res, const]), [res, const], **kwargs)

        return res


class Z3Simplifier(Simplifier):
    def __init__(self, env=None):
        super().__init__(env)
        self._solver = Z3Solver(self.env, 'QF_AUFBV')

    def simplify(self, formula):
        z3_formula = z3.simplify(self._solver.converter.convert(formula))
        return self._solver.converter.back(z3_formula)
