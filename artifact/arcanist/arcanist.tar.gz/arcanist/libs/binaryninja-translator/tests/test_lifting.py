import logging

from arcanist.architecture import Architecture
from arcanist.gadgets.extraction import RawGadget
from arcanist.platform import Platform
from arcanist.synthesizer.smt.simplifiers import Z3Simplifier
from arcanist.translator.binaryninja.llil_gadget import CustomWorkflowSSAGadgetAnalysis
from arcanist.translator.binaryninja.smt_gadget import SMTGadget
from arcanist.translator.binaryninja.translate import BinaryNinjaTranslator
LOGGER = logging.getLogger(__name__)


def test_push_pop_z3_simplify():
    raw_gadget = RawGadget("push rax; pop rbx; ret",
                           0x1000, b'\x50\x5B\xC3', 3)
    translator = BinaryNinjaTranslator(Platform.LINUX, Z3Simplifier())
    smt_gadget = translator.translate_single(Architecture.x86_64, raw_gadget)

    assert smt_gadget._liveout_formulae.registers['rbx'].value == smt_gadget.initial_regs['rax'].var.value
