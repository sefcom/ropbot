from __future__ import annotations

from arcanist.architecture import Endian

from .tainted_types.array import TaintedArray
from .tainted_types.bitvec import TaintedBitvec
from .tainted_types.bool import TaintedBool

from pysmt.exceptions import PysmtTypeError
from pysmt.shortcuts import Array, ArrayType, Symbol, BVZero, FALSE, BVConcat, And, BVType, BV, TRUE
from pysmt.typing import BV8, BOOL
from pysmt import fnode
from pysmt.simplifier import Simplifier

from typing import Self, cast


class TaintedMemory(TaintedArray):
    def __init__(self, endian: Endian, content: fnode.FNode, taints: fnode.FNode):
        self._endian = endian
        super().__init__(content, taints)
        if not content.get_type().index_type.is_bv_type():
            raise PysmtTypeError(
                f"Expected SMT type of indices in 'content' and 'taints' to be 'BV8' for constructing {self.__class__.__name__}, got '{content.get_type().index_type}' instead ")
        if not content.get_type().elem_type.is_bv_type(8):
            raise PysmtTypeError(
                f"Expected SMT type of elements in 'content' to be 'BV8' for constructing {self.__class__.__name__}, got '{content.get_type().elem_type}' instead ")

    def _check_index_type(self, index: fnode.FNode) -> None:
        if not index.get_type().is_bv_type(self.ptr_width):
            raise PysmtTypeError(
                f"Expected SMT type of index to be 'BV{{{self.ptr_width}}}' for memory operation, got '{index.get_type()}'")

    @property
    def ptr_width(self) -> int:
        return cast(int, self.content.get_type().index_type.width)

    @property
    def endian(self) -> Endian:
        return self._endian

    @classmethod
    def with_name(cls, endian: Endian, ptr_width: int, name: str) -> Self:
        content = Symbol(name + "_content", ArrayType(BVType(ptr_width), BV8))
        taints = Symbol(name + "_taints", ArrayType(BVType(ptr_width), BOOL))
        return cls(endian, content, taints)

    @classmethod
    def new_zero_untainted(cls, endian: Endian, ptr_width: int) -> Self:
        content = Array(BVType(ptr_width), BVZero(8))
        taints = Array(BVType(ptr_width), FALSE())
        return cls(endian, content, taints)

    # def assert_range_tainted(self, start: int, size: int) -> fnode.FNode:
    #     tainted = [self.taints.Select(BV(addr, self.ptr_width))
    #                for addr in range(start, start+size)]

    #     return And(tainted)

    def clone_untainted(self) -> TaintedMemory:
        content = self.content
        taints = Array(BVType(self.ptr_width), FALSE())
        return TaintedMemory(self.endian, content, taints)

    def taint_range(self, start: int, size: int) -> TaintedMemory:
        content = self.content
        taints = self.taints
        for addr in range(start, start+size):
            taints = taints.Store(BV(addr, self.ptr_width), TRUE())

        return TaintedMemory(self.endian, content, taints)

    def _read_byte(self, index: fnode.FNode) -> TaintedBitvec:
        value = self.content.Select(index)
        taint = self.taints.Select(index)
        return TaintedBitvec(value, taint)

    def _write_byte(self, index: fnode.FNode, bv: TaintedBitvec) -> TaintedMemory:
        content = self.content.Store(index, bv.value)
        taints = self.taints.Store(index, bv.taint)
        return TaintedMemory(self.endian, content, taints)

    def read_at(self, index: fnode.FNode, count: int) -> TaintedBitvec:
        self._check_index_type(index)
        endian_range = range(
            count) if self.endian is Endian.Big else range(count-1, -1, -1)

        tainted_bytes = [self._read_byte(index + i) for i in endian_range]
        values, taints = zip(*[(b.value, b.taint) for b in tainted_bytes])
        value = values[0] if count == 1 else BVConcat(values)
        taint = taints[0] if count == 1 else And(taints)
        return TaintedBitvec(value, taint)

    def write_at(self, index: fnode.FNode, bv: TaintedBitvec) -> TaintedMemory:
        self._check_index_type(index)
        if (bv.bv_width % 8) != 0:
            raise ValueError(
                f"Trying to write bit-vector whose width is not a multiple of 8 (got {bv.bv_width})")

        tainted_bytes = [bv.Extract(i, i + 7)
                         for i in range(0, bv.bv_width, 8)]
        if self.endian is Endian.Big:
            tainted_bytes.reverse()

        count = bv.bv_width // 8
        memory = self
        for i in range(count):
            memory = memory._write_byte(index + i, tainted_bytes[i])

        return memory

    def simplify(self, simplifier: Simplifier | None) -> TaintedMemory:
        if simplifier is None:
            simplifier = Simplifier()
        return TaintedMemory(self.endian, simplifier.simplify(self.content), simplifier.simplify(self.taints))


@TaintedBool.Ite.register
def _(self, then: TaintedMemory, elze: TaintedMemory) -> TaintedMemory:
    if type(then) is not type(elze):
        raise TypeError(
            f"Both sides of if-then-else should be of same type, but got 'then':{type(then)}, 'else':{type(elze)}")

    if then.endian != elze.endian:
        raise ValueError(
            f"Both sides of if-then-else should have the same endianness, but got 'then':{then.endian}, 'else':{elze.endian}")

    if then.ptr_width != elze.ptr_width:
        raise ValueError(
            f"Both sides of if-then-else should have the same pointer width, but got 'then':{then.ptr_width}, 'else':{elze.ptr_width}")

    endian = then.endian
    ptr_width = then.ptr_width

    content = self.value.Ite(then.content, elze.content)
    taints = self.taint.Ite(self.value.Ite(
        then.taints, elze.taints), Array(BVType(ptr_width), FALSE()))

    return TaintedMemory(endian, content, taints)
