from arcanist.synthesizer.smt.simplifiers import *
from pysmt.shortcuts import *

def test_bv_add_simple_nested_sub():
    simplifier = CustomFormulaSimplifier()
    a = Symbol("a", BVType(32))
    b = Symbol("b", BVType(32))
    c = Symbol("c", BVType(32))
    s = simplifier.simplify(a + (b - c))
    assert s == ((a + b) - c)

def test_bv_add_nested_sub_nested_add():
    simplifier = CustomFormulaSimplifier()
    a = Symbol("a", BVType(32))
    b = Symbol("b", BVType(32))
    c = Symbol("c", BVType(32))
    d = Symbol("d", BVType(32))
    e = Symbol("e", BVType(32))
    f = Symbol("f", BVType(32))
    g = Symbol("g", BVType(32))
    s = simplifier.simplify(a + (b + c) + ((d + e) - (f + g)))
    assert s == ((a + b + c + d + e) - (f + g))

def test_bv_add_simple_constant():
    simplifier = CustomFormulaSimplifier()
    a = Symbol("a", BVType(32))
    s = simplifier.simplify((a + 32) + 10)
    assert s == (a + 42)

def test_bv_sub_nested_sub_left():
    simplifier = CustomFormulaSimplifier()
    a = Symbol("a", BVType(32))
    b = Symbol("b", BVType(32))
    c = Symbol("c", BVType(32))
    s = simplifier.simplify((a - b) - c)
    assert s == (a - (b + c))

def test_bv_sub_nested_sub_right():
    simplifier = CustomFormulaSimplifier()
    a = Symbol("a", BVType(32))
    b = Symbol("b", BVType(32))
    c = Symbol("c", BVType(32))
    s = simplifier.simplify(a - (b - c))
    assert s == (a + c - b)

def test_bv_sub_nested_sub_leftright():
    simplifier = CustomFormulaSimplifier()
    a = Symbol("a", BVType(32))
    b = Symbol("b", BVType(32))
    c = Symbol("c", BVType(32))
    d = Symbol("d", BVType(32))
    s = simplifier.simplify((a - b) - (c - d))
    assert s == ((a + d) - (b + c))

def test_bv_sub_nested_sub_and_add():
    simplifier = CustomFormulaSimplifier()
    a = Symbol("a", BVType(32))
    b = Symbol("b", BVType(32))
    c = Symbol("c", BVType(32))
    d = Symbol("d", BVType(32))
    s = simplifier.simplify(a - (b - (c + d)))
    assert s == ((a + c + d) - b)

def test_bv_sub_with_nested_add_and_constants():
    simplifier = CustomFormulaSimplifier()
    a = Symbol("a", BVType(32))
    b = Symbol("b", BVType(32))
    c = Symbol("c", BVType(32))
    s = simplifier.simplify((52 + a) - (b + 10 + c))
    assert s == (a - (b + c) + 42)

def test_bv_sub_width_nested_add_and_nullifying_constants():
    simplifier = CustomFormulaSimplifier()
    a = Symbol("a", BVType(32))
    b = Symbol("b", BVType(32))
    c = Symbol("c", BVType(32))
    s = simplifier.simplify((52 + a) - (b + 52 + c))
    assert s == (a - (b + c))

def test_bv_sub_with_nested_add_and_left_constant():
    simplifier = CustomFormulaSimplifier()
    a = Symbol("a", BVType(32))
    b = Symbol("b", BVType(32))
    c = Symbol("c", BVType(32))
    s = simplifier.simplify((52 + a) - (b + c))
    assert s == (a - (b + c) + 52)

def test_bv_sub_with_nested_add_and_right_constant():
    simplifier = CustomFormulaSimplifier()
    a = Symbol("a", BVType(32))
    b = Symbol("b", BVType(32))
    c = Symbol("c", BVType(32))
    s = simplifier.simplify(a - (b + 10 + c))
    assert s == (a - (b + c) + (2**32 - 10))

def test_bv_add_constant_on_left():
    simplifier = CustomFormulaSimplifier()
    a = Symbol("a", BVType(32))
    s = simplifier.simplify(42 + a)
    assert s == (a + 42)