from arcanist.translator.binaryninja.workflow.phi_temp0_remove import RemoveTemp0FromPhisActivity
from binaryninja.workflow import Workflow
from binaryninja.architecture import Architecture
from binaryninja.log import log_debug

from arcanist.translator.binaryninja.workflow.jump_ret_call import JumpRetCallRewriterActivity
from arcanist.translator.binaryninja.workflow.unusable_blocks import RemoveUnusableBlocksActivity
from arcanist.translator.binaryninja.workflow.gadget_exit_intrinsic import inject_gadget_exit_intrinsic


# REGISTER ARCHITECTURE HOOKS

for arch in list(Architecture):
    log_debug(
        f"Registering 'gadget exit' intrinsic for {arch.name}")
    inject_gadget_exit_intrinsic(arch)

# BUILD AND REGISTER CUSTOM WORKFLOW

gadget_analysis_workflow = Workflow().clone("GadgetAnalysisSSAWorkflow")

jump_ret_call_rewriter_activity = JumpRetCallRewriterActivity(
    "extension.gadgetLifting.rewriteJumpRetCall")
gadget_analysis_workflow.register_activity(jump_ret_call_rewriter_activity)

remove_unusable_blocks_activity = RemoveUnusableBlocksActivity(
    "extension.gadgetLifting.removeUnusableBlocks")
gadget_analysis_workflow.register_activity(remove_unusable_blocks_activity)

remove_temp0_from_phis = RemoveTemp0FromPhisActivity(
    "extension.gadgetLifting.removeTemp0FromPhis")
gadget_analysis_workflow.register_activity(remove_temp0_from_phis)

function_analysis_configuration = gadget_analysis_workflow.get_activity(
    "core.function.fullAnalysis")
assert function_analysis_configuration is not None
subactivities = gadget_analysis_workflow.subactivities(
    function_analysis_configuration)

subactivities.remove('core.function.analyzeTailCalls')
subactivities.remove('core.function.translateTailCalls')

lifted_il_index = subactivities.index('core.function.generateLiftedIL')
subactivities.insert(
    lifted_il_index + 1, jump_ret_call_rewriter_activity.name)

medium_il_index = subactivities.index('core.function.generateMediumLevelIL')
subactivities.insert(medium_il_index, remove_unusable_blocks_activity.name)

remove_unusable_blocks_index = medium_il_index
subactivities.insert(remove_unusable_blocks_index +
                     1, remove_temp0_from_phis.name)

gadget_analysis_workflow.assign_subactivities(
    function_analysis_configuration, subactivities)
gadget_analysis_workflow.register()
