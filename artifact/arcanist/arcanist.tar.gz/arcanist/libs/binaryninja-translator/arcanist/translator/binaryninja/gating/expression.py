from __future__ import annotations

from dataclasses import dataclass
from typing import Generic, Self, TypeVar
from abc import ABC

C = TypeVar("C")  # condition type
B = TypeVar("B")  # basic block type


class IncompatiblePathExpressionsError(Exception):
    pass


@dataclass(frozen=True)
class PathExpression(Generic[C, B]):
    start: B
    end: B
    expression: Expression[C, B]

    def concat(self, other: PathExpression[C, B]) -> PathExpression[C, B]:
        if self.end != other.start:
            raise IncompatiblePathExpressionsError()

        return PathExpression[C, B](self.start, other.end, self.expression.concat(other.expression))

    def union(self, other: Self) -> PathExpression[C, B]:
        if self.start != other.start or self.end != other.end:
            raise IncompatiblePathExpressionsError()

        return PathExpression[C, B](self.start, self.end, self.expression.union(other.expression))

    def star(self) -> PathExpression[C, B]:
        if self.start != self.end:
            raise IncompatiblePathExpressionsError()

        return PathExpression[C, B](self.start, self.end, self.expression.star())


class Expression(ABC, Generic[C, B]):
    @classmethod
    def make_empty(cls) -> Self:
        raise NotImplementedError()

    @classmethod
    def make_lambda(cls, annotation: B | None = None) -> Self:
        raise NotImplementedError()

    def concat(self, other: Self) -> Self:
        raise NotImplementedError()

    def union(self, other: Self) -> Self:
        raise NotImplementedError()

    def star(self) -> Self:
        raise NotImplementedError()


class GammaExpression(Expression[C, B]):
    @classmethod
    def make_empty(cls) -> Empty[C, B]:
        return Empty()

    @classmethod
    def make_lambda(cls, annotation: B | None = None, condition: C | None = None) -> Lambda[C, B]:
        return Lambda(annotation, condition)

    @classmethod
    def make_gamma(cls, cond: C, then: Self, elze: Self) -> Gamma[C, B]:
        return Gamma(cond, then, elze)

    def concat(self, other: GammaExpression[C, B]) -> GammaExpression[C, B]:
        match self, other:
            case (Empty(), _) | (_, Empty()):
                return Empty()
            case Gamma(condition, then, elze), _:
                return Gamma(condition, then.concat(other), elze.concat(other))
            case Lambda(_, _), Lambda(annotation, _):
                if annotation is None:
                    return self
                return other
            case Lambda(_, _), _:
                return other

        raise NotImplementedError(
            "match statement should be complete, so this ought to be unreachable")

    def union(self, other: GammaExpression[C, B]) -> GammaExpression[C, B]:
        match self, other:
            case Empty(), _:
                return other
            case _, Empty():
                return self
            case Gamma(cond1, then1, elze1), Gamma(cond2, then2, elze2):
                if cond1 != cond2:
                    raise NotImplementedError(
                        f"cannot unionize gamma expressions whose condition does not match: left is {cond1} and right is {cond2}")
                return Gamma(cond1, then1.union(then2), elze1.union(elze2))
            case (Lambda(_, _), _) | (_, Lambda(_, _)):
                raise NotImplementedError(f"cannot unionize lambda expression")

        raise NotImplementedError(
            "match statement should be complete, so this ought to be unreachable")

    def star(self) -> GammaExpression[C, B]:
        raise NotImplementedError("star operator not implemented")


@dataclass(frozen=True)
class Empty(GammaExpression[C, B]):
    pass


@dataclass(frozen=True)
class Lambda(GammaExpression[C, B]):
    annotation: B | None
    condition: C | None


@dataclass(frozen=True)
class Gamma(GammaExpression[C, B]):
    condition: C
    then: GammaExpression[C, B]
    elze: GammaExpression[C, B]
