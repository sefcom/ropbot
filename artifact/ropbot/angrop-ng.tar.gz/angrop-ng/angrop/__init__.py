__version__ = "9.2.12.dev0"

from . import rop

import sys
if hasattr(sys, "set_int_max_str_digits"): sys.set_int_max_str_digits(0)

