from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from functools import cached_property
from typing import Any, Callable, Dict, TypeVar, cast, List, Tuple
from arcanist.architecture import Endian
from arcanist.synthesizer.gadget import GadgetInputSymbol, GadgetInputSymbols, GadgetOutputSymbol, GadgetOutputSymbols, JSONGadget
from arcanist.synthesizer.gadget import UninterpretedMemoryPredicates
from arcanist.synthesizer.memory import TaintedMemory
from arcanist.synthesizer.archinfo import ArchInfo, RegInfo, FlagInfo
from arcanist.synthesizer.tainted_types.bitvec import TaintedBitvec
from arcanist.synthesizer.tainted_types.bool import TaintedBool
from arcanist.translator.binaryninja.gating.expression import GammaExpression
from arcanist.translator.binaryninja.gating import expression

from arcanist.translator.binaryninja.llil_gadget import CustomWorkflowSSAGadgetAnalysis, MustNotSatisfyCondition, MustSatisfyCondition

from binaryninja.architecture import Architecture
from binaryninja.enums import Endianness
from binaryninja.lowlevelil import ExpressionIndex, LowLevelILBasicBlock, LowLevelILInstruction, SSARegister, SSAFlag, LowLevelILIntrinsicSsa, LowLevelILUnaryBase, LowLevelILRegSplitDestSsa, LowLevelILSetRegSplitSsa, LowLevelILTestBit, LowLevelILUnimplMem, LowLevelILRegSsaPartial, LowLevelILMods, LowLevelILDivs, LowLevelILAsr, LowLevelILRol, LowLevelILRor, LowLevelILAddOverflow, LowLevelILUnimpl, LowLevelILUndef, LowLevelILComparisonBase, LowLevelILSetFlagSsa, LowLevelILIf, LowLevelILCmpE, LowLevelILCmpNe, LowLevelILCmpUle, LowLevelILCmpUge, LowLevelILCmpUlt, LowLevelILCmpUgt, LowLevelILCmpSle, LowLevelILCmpSge, LowLevelILCmpSlt, LowLevelILCmpSgt, LowLevelILNoret, LowLevelILGoto, LowLevelILLowPart, LowLevelILNop, LowLevelILRegPhi, LowLevelILFlagPhi, LowLevelILMemPhi, LowLevelILSetRegSsaPartial, LowLevelILZx, LowLevelILSx, LowLevelILStoreSsa, LowLevelILSetRegSsa, LowLevelILNeg, LowLevelILNot, LowLevelILModu, LowLevelILDivu, LowLevelILLsl, LowLevelILLsr, LowLevelILMul, LowLevelILBinaryBase, LowLevelILAnd, LowLevelILOr, LowLevelILXor, LowLevelILAdc, LowLevelILSbb, LowLevelILAdd, LowLevelILSub, LowLevelILPop, LowLevelILLoad, LowLevelILLoadSsa, LowLevelILConst, LowLevelILConstPtr, LowLevelILRegSsa, LowLevelILFlagSsa, LowLevelILReg, LowLevelILFlag
from binaryninja.commonil import FloatingPoint
# from binaryninja.log import log_debug

from pysmt import fnode
from pysmt.shortcuts import And, Not, Function, BV
from pysmt.simplifier import Simplifier
from pysmt.walkers import IdentityDagWalker

from abc import ABC, abstractmethod

import logging
LOGGER = logging.getLogger(__name__)


def binaryninja_arch_to_synthesizer_arch_info(arch: Architecture) -> ArchInfo:
    _program_counters = {'armv7': 'pc',
                         'thumb2': 'pc',
                         'x86': 'eip',
                         'x86_64': 'rip'}
    try:
        program_counter = _program_counters[cast(str, arch.name)]
    except KeyError:
        raise NotImplementedError(
            f"conversion from binaryninja arch '{arch.name}' into ArchInfo not implemented") from None

    regs_info = OrderedDict()
    for name, info in map(lambda name: (name, arch.regs[name]), arch.full_width_regs):
        regs_info[str(name)] = RegInfo(name, info.size * 8)
    flags_info = OrderedDict()
    for name in arch.flags:
        flags_info[str(name)] = FlagInfo(name)

    endian = Endian.Little if arch.endianness is Endianness.LittleEndian else Endian.Big

    return ArchInfo(endian, arch.address_size * 8, regs_info, flags_info, program_counter)


def zero_ext_left_right_if_needed(op: Callable[[TaintedBitvec, TaintedBitvec], TaintedBitvec]) -> Callable[[TaintedBitvec, TaintedBitvec], TaintedBitvec]:
    # fix binop with operands of different sizes... this happens sometimes in lifted IL even though it should not...
    # or when dealing with constant values
    def op_with_zero_ext(left: TaintedBitvec, right: TaintedBitvec) -> TaintedBitvec:
        if right.bv_width < left.bv_width:
            right = right.ZeroExtend(left.bv_width - right.bv_width)
        elif left.bv_width < right.bv_width:
            left = left.ZeroExtend(right.bv_width - left.bv_width)
        return op(left, right)

    return op_with_zero_ext


_llil_rotation_ops: Dict[Any, Callable[[TaintedBitvec, int], TaintedBitvec]] = {
    LowLevelILRol: TaintedBitvec.Rol,
    LowLevelILRor: TaintedBitvec.Ror,
    LowLevelILAsr: TaintedBitvec.Asr,
}

_llil_bitvec_binop_to_tainted_bitvec: Dict[Any, Callable[[TaintedBitvec, TaintedBitvec], TaintedBitvec]] = {
    LowLevelILAdd: TaintedBitvec.__add__,
    LowLevelILSub: TaintedBitvec.__sub__,
    LowLevelILMul: TaintedBitvec.__mul__,
    LowLevelILDivu: TaintedBitvec.__truediv__,
    LowLevelILModu: TaintedBitvec.__mod__,
    LowLevelILDivs: TaintedBitvec.SignedDiv,
    LowLevelILMods: TaintedBitvec.SignedMod,
    LowLevelILAnd: zero_ext_left_right_if_needed(TaintedBitvec.__and__),
    LowLevelILOr: zero_ext_left_right_if_needed(TaintedBitvec.__or__),
    LowLevelILXor: zero_ext_left_right_if_needed(TaintedBitvec.__xor__),
    LowLevelILLsl: zero_ext_left_right_if_needed(TaintedBitvec.__lshift__),
    LowLevelILLsr: zero_ext_left_right_if_needed(TaintedBitvec.__rshift__),
}


def signed_add_overflow_flag(left: TaintedBitvec, right: TaintedBitvec) -> TaintedBool:
    return left.SignedAddOverflow(right) | left.SignedAddUnderflow(right)


def signed_sub_overflow_flag(left: TaintedBitvec, right: TaintedBitvec) -> TaintedBool:
    return left.SignedSubOverflow(right) | left.SignedSubUnderflow(right)


_llil_bitvec_binop_to_tainted_bool: Dict[Any, Callable[[TaintedBitvec, TaintedBitvec], TaintedBool]] = {
    LowLevelILCmpUle: TaintedBitvec.__le__,
    LowLevelILCmpUge: TaintedBitvec.__ge__,
    LowLevelILCmpUlt: TaintedBitvec.__lt__,
    LowLevelILCmpUgt: TaintedBitvec.__gt__,
    LowLevelILCmpSle: TaintedBitvec.SLe,
    LowLevelILCmpSge: TaintedBitvec.SGe,
    LowLevelILCmpSlt: TaintedBitvec.SLt,
    LowLevelILCmpSgt: TaintedBitvec.SGt,
    LowLevelILAddOverflow: signed_add_overflow_flag,
}

_llil_bool_binop_to_tainted_bool: Dict[Any, Callable[[TaintedBool, TaintedBool], TaintedBool]] = {
    LowLevelILAnd: TaintedBool.__and__,
    LowLevelILOr: TaintedBool.__or__,
    LowLevelILXor: TaintedBool.__xor__,
}


def ssa_reg_size(ssa_reg: SSARegister) -> int:
    if ssa_reg.reg.temp:
        return ssa_reg.reg.arch.address_size
    else:
        return ssa_reg.reg.info.size


class UnknownType:
    pass


def infer_expr_type(instr: LowLevelILInstruction) -> type[TaintedBitvec] | type[TaintedBool] | type[UnknownType]:
    # for some expressions you need to infer the type
    # for example 'al = flag:s != flag:o' is lifted for 'setl al' in x86
    # the result must be stored as a bitvector but you don't know if you
    # compare booleans or bit-vectors... so you must infer the type of operands
    # to know whether you compare bit-vectors or booleans...
    match instr:
        case LowLevelILRegSsa() | LowLevelILRegSsaPartial() | LowLevelILAdd() | LowLevelILSub() | LowLevelILMul() | LowLevelILLsl() | LowLevelILLsr() | LowLevelILDivu() | LowLevelILModu() | LowLevelILRol() | LowLevelILRor() | LowLevelILAsr() | LowLevelILDivs() | LowLevelILMods() | LowLevelILNeg() | LowLevelILAdc() | LowLevelILSbb() | LowLevelILLoadSsa() | LowLevelILZx() | LowLevelILSx() | LowLevelILLowPart() | LowLevelILConstPtr():
            return TaintedBitvec
        case LowLevelILFlagSsa() | LowLevelILCmpE() | LowLevelILCmpNe() | LowLevelILCmpUle() | LowLevelILCmpUge() | LowLevelILCmpUlt() | LowLevelILCmpUgt() | LowLevelILCmpSle() | LowLevelILCmpSge() | LowLevelILCmpSlt() | LowLevelILCmpSgt() | LowLevelILAddOverflow():
            return TaintedBool
        case LowLevelILAnd() | LowLevelILOr() | LowLevelILXor():
            return infer_and_check_binop_types(instr.left, instr.right)
        case LowLevelILNot():
            return infer_expr_type(instr.src)
        case LowLevelILConst() | LowLevelILUndef() | LowLevelILUnimpl() | LowLevelILUnimplMem():
            return UnknownType

    raise NotImplementedError(
        f'unable to infer type of expression {instr} ({type(instr).__name__})')


def infer_and_check_binop_types(left: LowLevelILInstruction, right: LowLevelILInstruction) -> type[TaintedBitvec] | type[TaintedBool]:
    left_type = infer_expr_type(left)
    right_type = infer_expr_type(right)
    if left_type == UnknownType:
        if right_type == UnknownType:
            return TaintedBitvec
        else:
            return cast(type[TaintedBitvec] | type[TaintedBool], right_type)
    elif right_type == UnknownType:
        return cast(type[TaintedBitvec] | type[TaintedBool], left_type)
    elif left_type == right_type:
        return cast(type[TaintedBitvec] | type[TaintedBool], left_type)
    else:
        raise TypeError(
            f"incompatible types for binop with 'left': {left} being {left_type.__name__},  and 'right': {right} being {right_type.__name__}")


def instruction_to_tainted_bitvec(instr: LowLevelILInstruction, cst_size: int, instr_idx: int, regs: Dict[SSARegister, TaintedBitvec], flags: Dict[SSAFlag, TaintedBool], memories: Dict[int, TaintedMemory]) -> TaintedBitvec:
    """
    handle the conversion of operands that translate to bit vectors
    """

    def binop(instr: LowLevelILBinaryBase) -> TaintedBitvec:
        op = _llil_bitvec_binop_to_tainted_bitvec.get(type(instr))
        if op is not None:
            left = instruction_to_tainted_bitvec(
                instr.left, cst_size, instr_idx, regs, flags, memories)
            right = instruction_to_tainted_bitvec(
                instr.right, left.bv_width, instr_idx, regs, flags, memories)

            return op(left, right)
        else:
            raise NotImplementedError(
                f"conversion of binop {type(instr)} not implemented")

    match instr:
        # constants and registers
        case LowLevelILRegSsa():
            expected_size = instr.size * 8
            bv_value = regs[instr.src]
            if bv_value.bv_width > expected_size:
                return bv_value.Extract(0, expected_size - 1)
            return bv_value
        case LowLevelILRegSsaPartial():
            expected_size = instr.size * 8
            full_reg_bv = regs[instr.full_reg]
            partial_offset = instr.src.info.offset * 8
            partial_size = instr.src.info.size * 8

            extract_size = min(partial_size, expected_size)
            partial_value = full_reg_bv.Extract(
                partial_offset, partial_offset + extract_size - 1)

            if partial_value.bv_width < expected_size:
                return partial_value.ZeroExtend(expected_size - partial_value.bv_width)

            return partial_value
        case LowLevelILConst() | LowLevelILConstPtr():
            # YES this may occur... for example when updating flags...
            # flag:z = (temp0.b & 0xfe) but in reality 0xfe is 0x1fe...
            # just truncate in this situation...
            # (that's what binary ninja does when displaying the operation)
            if instr.constant >= (1 << cst_size):
                const_value = instr.constant % (1 << cst_size)
            else:
                const_value = instr.constant

            # if the constant is negative and does not fit in the given size
            # sometimes AddOverflow is also used to check
            # the overfow of subtraction, for example in ARM a `cmp r5, 0xFFFFFFFF`
            # will induce an `add_overflow(r5, -0xFFFFFFFF)`
            # but `-0xFFFFFFFF` does not fit in 32bits...
            # so we must handle this particular case...
            if const_value < -(2**(cst_size-1)):
                return -TaintedBitvec.from_int(-const_value, cst_size)
            else:
                return TaintedBitvec.from_int(const_value, cst_size)

        # memory operations
        case LowLevelILLoadSsa():
            memory = memories[instr.src_memory]
            # memory read should only be valid if source is tainted
            # but we don't handle this here
            source = instruction_to_tainted_bitvec(
                instr.src, instr.function.arch.address_size * 8, instr_idx, regs, flags, memories)
            return memory.read_at(source.value, instr.size)

        # comparison operations
        # YES this may occur... for example with the x86 instruction
        # 'setl al' which is lifted into 'al = flag:s != flag:o'
        # it should be lifted to something like bool_to_int but isn't...
        case LowLevelILComparisonBase():
            tainted_bool = instruction_to_tainted_bool(
                instr, instr_idx, regs, flags, memories)
            return TaintedBitvec.from_tainted_bool(tainted_bool, cst_size)

        # rotation operations
        case LowLevelILRor() | LowLevelILRol() | LowLevelILAsr():
            if not isinstance(instr.right, LowLevelILConst):
                raise TypeError(
                    f"unsupported rotation operations {instr}, because 'right': {instr.right} is not an integer constant")
            op = _llil_rotation_ops[type(instr)]
            left = instruction_to_tainted_bitvec(
                instr.left, cst_size, instr_idx, regs, flags, memories)
            const_right = instr.right.constant % left.bv_width

            return op(left, const_right)

        # most of binary operations
        case LowLevelILBinaryBase():
            return binop(instr)

        # operations with carry/borrow
        case LowLevelILAdc():
            left = instruction_to_tainted_bitvec(
                instr.left, cst_size, instr_idx, regs, flags, memories)
            right = instruction_to_tainted_bitvec(
                instr.right, left.bv_width, instr_idx, regs, flags, memories)
            carry = TaintedBitvec.from_tainted_bool(
                instruction_to_tainted_bool(instr.carry, instr_idx, regs, flags, memories), left.bv_width)
            return left + right + carry
        case LowLevelILSbb():
            left = instruction_to_tainted_bitvec(
                instr.left, cst_size, instr_idx, regs, flags, memories)
            right = instruction_to_tainted_bitvec(
                instr.right, left.bv_width, instr_idx, regs, flags, memories)
            carry = TaintedBitvec.from_tainted_bool(
                instruction_to_tainted_bool(instr.carry, instr_idx, regs, flags, memories), left.bv_width)
            return left - (right + carry)

        # unary operations
        case LowLevelILNeg():
            source = instruction_to_tainted_bitvec(
                instr.src, cst_size, instr_idx, regs, flags, memories)
            return -source
        case LowLevelILNot():
            source = instruction_to_tainted_bitvec(
                instr.src, cst_size, instr_idx, regs, flags, memories)
            return ~source

        # special operations
        case LowLevelILZx():
            source = instruction_to_tainted_bitvec(
                instr.src, cst_size, instr_idx, regs, flags, memories)
            required_size = instr.size*8
            increase = required_size - source.bv_width
            return source.ZeroExtend(increase)
        case LowLevelILSx():
            source = instruction_to_tainted_bitvec(
                instr.src, cst_size, instr_idx, regs, flags, memories)
            increase = instr.size*8 - source.bv_width
            return source.SignExtend(increase)
        case LowLevelILLowPart():
            source = instruction_to_tainted_bitvec(
                instr.src, cst_size, instr_idx, regs, flags, memories)
            return source.Extract(0, instr.size * 8 - 1)

        case FloatingPoint():
            # this should never be reached due to workflow passes etc.
            raise NotImplementedError(
                "floating point operations are not supported and should not be present in gadgets")

        case LowLevelILReg() | LowLevelILFlag() | LowLevelILLoad() | LowLevelILPop():
            raise TypeError(
                f"non-ssa operation {type(instr)} in ssa to tainted bitvec conversion")

    raise NotImplementedError(
        f"unimplemented conversion of {type(instr).__name__} to tainted bitvec")


def instruction_to_tainted_bool(instr: LowLevelILInstruction, instr_idx: int, regs: Dict[SSARegister, TaintedBitvec], flags: Dict[SSAFlag, TaintedBool], memories: Dict[int, TaintedMemory]) -> TaintedBool:
    match instr:
        # flags & constants
        case LowLevelILFlagSsa():
            return flags[instr.src]
        case LowLevelILConst():
            assert 0 <= instr.constant <= 1
            return TaintedBool.from_bool(instr.constant == 1)

        # unimplemented or undefined
        case LowLevelILUndef() | LowLevelILUnimpl():
            return TaintedBool.new_false_untainted()

        # unary operators
        case LowLevelILNot():
            value = instruction_to_tainted_bool(
                instr.src, instr_idx, regs, flags, memories)
            return ~value

        # test-bit operation
        case LowLevelILTestBit():
            left = instruction_to_tainted_bitvec(
                instr.left, instr.function.arch.address_size * 8, instr_idx, regs, flags, memories)
            right = instruction_to_tainted_bitvec(
                instr.right, left.bv_width, instr_idx, regs, flags, memories)
            return ((left >> right) & 1).tainted_equals(1)

        # comparisons on booleans OR bit-vectors (these operations are valid on both types)
        case LowLevelILCmpE():
            operands_type = infer_and_check_binop_types(
                instr.left, instr.right)
            if operands_type == TaintedBitvec:
                left_bv = instruction_to_tainted_bitvec(
                    instr.left, instr.function.arch.address_size * 8, instr_idx, regs, flags, memories)
                right_bv = instruction_to_tainted_bitvec(
                    instr.right, left_bv.bv_width, instr_idx, regs, flags, memories)
                return left_bv.tainted_equals(right_bv)
            else:  # operands_type == TaintedBool
                left_bool = instruction_to_tainted_bool(
                    instr.left, instr_idx, regs, flags, memories)
                right_bool = instruction_to_tainted_bool(
                    instr.right, instr_idx, regs, flags, memories)
                return left_bool.tainted_equals(right_bool)
        case LowLevelILCmpNe():
            operands_type = infer_and_check_binop_types(
                instr.left, instr.right)
            if operands_type == TaintedBitvec:
                left_bv = instruction_to_tainted_bitvec(
                    instr.left, instr.function.arch.address_size * 8, instr_idx, regs, flags, memories)
                right_bv = instruction_to_tainted_bitvec(
                    instr.right, left_bv.bv_width, instr_idx, regs, flags, memories)
                return left_bv.tainted_not_equals(right_bv)
            else:  # operands_type == TaintedBool
                left_bool = instruction_to_tainted_bool(
                    instr.left, instr_idx, regs, flags, memories)
                right_bool = instruction_to_tainted_bool(
                    instr.right, instr_idx, regs, flags, memories)
                return left_bool.tainted_not_equals(right_bool)

        # other binary operations on *bit-vectors only* (mainly comparisons)
        # case LowLevelILAddOverflow():
        #     left_bv = instruction_to_tainted_bitvec(
        #         instr.left, instr.function.arch.address_size * 8, instr_idx, regs, flags, memories)
        #     # sometimes AddOverflow is also used to check
        #     # the overfow of subtraction, for example in ARM a `cmp r5, 0xFFFFFFFF`
        #     # will induce an `add_overflow(r5, -0xFFFFFFFF)`
        #     # but `-0xFFFFFFFF` does not fit in 32bits...
        #     # so we must split cases where the right operand is a negative constant...
        #     if (isinstance(instr.right, LowLevelILConstPtr) or isinstance(instr.right, LowLevelILConst)) and instr.right.constant < 0:
        #         cst = TaintedBitvec.from_int(-instr.right.constant,
        #                                      left_bv.bv_width)
        #         return signed_sub_overflow_flag(left_bv, cst)
        #     else:
        #         right_bv = instruction_to_tainted_bitvec(
        #             instr.right, left_bv.bv_width, instr_idx, regs, flags, memories)
        #         return signed_add_overflow_flag(left_bv, right_bv)

        case LowLevelILComparisonBase() | LowLevelILAddOverflow():
            op_bv = _llil_bitvec_binop_to_tainted_bool.get(type(instr))
            if op_bv is not None:
                left_bv = instruction_to_tainted_bitvec(
                    instr.left, instr.function.arch.address_size * 8, instr_idx, regs, flags, memories)
                right_bv = instruction_to_tainted_bitvec(
                    instr.right, left_bv.bv_width, instr_idx, regs, flags, memories)
                return op_bv(left_bv, right_bv)
            else:
                raise NotImplementedError(
                    f"conversion of bitvec operation {instr} to tainted bool in instruction {instr_idx} not implemented")

        # other binary operations on *booleans*
        case LowLevelILBinaryBase():
            op_bool = _llil_bool_binop_to_tainted_bool.get(type(instr))
            if op_bool is not None:
                left_bool = instruction_to_tainted_bool(
                    instr.left, instr_idx, regs, flags, memories)
                right_bool = instruction_to_tainted_bool(
                    instr.right, instr_idx, regs, flags, memories)
                return op_bool(left_bool, right_bool)
            else:
                raise NotImplementedError(
                    f"conversion of boolean binary operation {instr} to tainted bool in instruction {instr_idx} not implemented")

    raise NotImplementedError(
        f"conversion of operation {instr} to tainted bool in instruction {instr_idx} not implemented")


def do_phi_smt_translation(gadget:  CustomWorkflowSSAGadgetAnalysis.LLILGadget, instr: LowLevelILInstruction, instr_idx: int, regs: Dict[SSARegister, TaintedBitvec], flags: Dict[SSAFlag, TaintedBool], memories: Dict[int, TaintedMemory]) -> None:
    # if not isinstance(instr, Phi):
    #     raise TypeError("expected phi instruction to inherit Phi")

    T = TypeVar("T", SSARegister, SSAFlag, int)

    def phi_gamma_expr_to_tainted_value(expr: GammaExpression[LowLevelILInstruction, LowLevelILBasicBlock], candidates: Dict[LowLevelILBasicBlock, T]) -> TaintedBitvec | TaintedBool | TaintedMemory:
        def phi_gamma_expr_to_tainted_value_aux(expr: GammaExpression[LowLevelILInstruction, LowLevelILBasicBlock]) -> TaintedBitvec | TaintedBool | TaintedMemory | None:
            match expr:
                case expression.Empty():
                    return None

                case expression.Lambda(parent_bb, cond_instr):
                    if parent_bb is None:
                        raise NotImplementedError()

                    candidate = candidates[parent_bb]
                    try:
                        match candidate:
                            case SSAFlag():
                                return flags[candidate]
                            case SSARegister():
                                return regs[candidate]
                            case int():
                                return memories[candidate]
                    except KeyError:
                        raise KeyError(
                            f"unknown candidate: {candidate} for phi: {instr}") from None

                    raise TypeError(
                        "phi candidate must be SSAFlag, SSARegister or int (memory version)")

                case expression.Gamma(cond_instr, then_expr, elze_expr):
                    condition = instruction_to_tainted_bool(
                        cond_instr, instr_idx, regs, flags, memories)

                    then_value = phi_gamma_expr_to_tainted_value_aux(
                        then_expr)
                    elze_value = phi_gamma_expr_to_tainted_value_aux(
                        elze_expr)

                    match (then_value, elze_value):
                        case None, None:
                            return None
                        case _, None:
                            return then_value
                        case None, _:
                            return elze_value
                        case _, _:
                            return condition.Ite(then_value, elze_value)

            raise NotImplementedError("should never reach")

        res = phi_gamma_expr_to_tainted_value_aux(expr)
        if res is None:
            raise NotImplementedError()
        return res

    bb = cast(LowLevelILBasicBlock, instr.il_basic_block)
    parents = list(map(lambda edge: cast(LowLevelILBasicBlock, edge.source), filter(
        lambda edge: edge not in gadget.must_not_take_edges, bb.incoming_edges)))

    bb_gating = gadget.basic_blocks_gating_expressions[bb]
    idom_gating_gamma_expr = cast(
        GammaExpression, bb_gating.from_immediate_dominator.expression)

    match instr:
        case LowLevelILRegPhi():
            if len(instr.src) == 1:
                # this may occur because of the 'remove tempX#0 from phis' pass
                # in this case just consider this phi as a regular assignment
                regs[instr.dest] = regs[instr.src[0]]
            else:
                # reg_sources = set(instr.src)
                reg_candidates: Dict[LowLevelILBasicBlock,
                                     SSARegister] = dict()
                dest_reg = instr.dest.reg
                for parent in parents:
                    liveout_info = gadget.basic_blocks_liveout_information[parent]
                    reg_live_version = liveout_info.get_live_ssa_register(
                        dest_reg)
                    # it might be None for example if it's a temporary variable temp:X
                    # only assigned on one path
                    if reg_live_version is not None:
                        reg_candidates[parent] = reg_live_version

                regs[instr.dest] = cast(TaintedBitvec, phi_gamma_expr_to_tainted_value(
                    idom_gating_gamma_expr, reg_candidates))

        case LowLevelILFlagPhi():
            if len(instr.src) == 1:
                flags[instr.dest] = flags[instr.src[0]]
            else:
                flag_candidates: Dict[LowLevelILBasicBlock,
                                      SSAFlag] = dict()
                dest_flag = instr.dest.flag
                for parent in parents:
                    liveout_info = gadget.basic_blocks_liveout_information[parent]
                    flag_live_version = liveout_info.get_live_ssa_flag(
                        dest_flag)
                    # it might be None for example if it's a temporary variable temp:X
                    # only assigned on one path
                    if flag_live_version is not None:
                        flag_candidates[parent] = flag_live_version

                flags[instr.dest] = cast(TaintedBool, phi_gamma_expr_to_tainted_value(
                    idom_gating_gamma_expr, flag_candidates))

        case LowLevelILMemPhi():
            mem_candidates: Dict[LowLevelILBasicBlock, int] = dict()
            for parent in parents:
                liveout_info = gadget.basic_blocks_liveout_information[parent]
                mem_candidates[parent] = liveout_info.get_live_memory_version()
            memories[instr.dest_memory] = cast(TaintedMemory, phi_gamma_expr_to_tainted_value(
                idom_gating_gamma_expr, mem_candidates))

        case _:
            raise TypeError(f"unknown phi variant: {type(instr)}")


def process_llil_ssa_instruction_to_smt(gadget: CustomWorkflowSSAGadgetAnalysis.LLILGadget, instr_idx: int, instr: LowLevelILInstruction, regs: Dict[SSARegister, TaintedBitvec], flags: Dict[SSAFlag, TaintedBool], memories: Dict[int, TaintedMemory], is_exit_block: bool = False):
    if is_exit_block and (isinstance(instr, LowLevelILIntrinsicSsa) or isinstance(instr, LowLevelILNoret)):
        return

    # here we handle the instructions that can write memory/flags/registers
    match instr:

        # set reg operations
        case LowLevelILSetRegSsa():
            dest_size = ssa_reg_size(instr.dest)

            # in some case the source can be a boolean...
            # in that case it should be converted with 'bool_to_int' but isn't
            # for example in x86 you can find 'al = not(flag:c)'
            # so you need to infer type of rhs
            src_type = infer_expr_type(instr.src)
            if src_type == TaintedBool:
                source_bv = TaintedBitvec.from_tainted_bool(
                    instruction_to_tainted_bool(instr.src, instr_idx, regs, flags, memories), dest_size * 8)
            else:
                source_bv = instruction_to_tainted_bitvec(
                    instr.src, dest_size * 8, instr_idx, regs, flags, memories)
                if source_bv.bv_width > dest_size * 8:
                    source_bv = source_bv.Extract(0, dest_size * 8 - 1)
                elif source_bv.bv_width < dest_size * 8:
                    source_bv = source_bv.ZeroExtend(
                        dest_size * 8 - source_bv.bv_width)
            regs[instr.dest] = source_bv

        case LowLevelILSetRegSsaPartial():
            partial_offset = instr.dest.info.offset * 8
            partial_size = instr.dest.info.size * 8

            src_type = infer_expr_type(instr.src)
            if src_type == TaintedBool:
                source_bv = TaintedBitvec.from_tainted_bool(
                    instruction_to_tainted_bool(instr.src, instr_idx, regs, flags, memories), partial_size)
            else:
                source_bv = instruction_to_tainted_bitvec(
                    instr.src, partial_size, instr_idx, regs, flags, memories)
                if source_bv.bv_width > partial_size:
                    source_bv = source_bv.Extract(0, partial_size - 1)
                elif source_bv.bv_width < partial_size:
                    source_bv = source_bv.ZeroExtend(
                        partial_size - source_bv.bv_width)

            previous_reg = gadget.get_register_live_version_at(
                instr_idx, instr.full_reg.reg)
            previous_value = regs[previous_reg]
            full_reg_size = previous_value.bv_width

            if partial_offset + partial_size < full_reg_size:
                previous_upper_extract = previous_value.Extract(partial_offset + partial_size,
                                                                full_reg_size - 1)
                upper_new_value = previous_upper_extract.Concat(source_bv)
            else:
                upper_new_value = source_bv

            if partial_offset > 0:
                previous_lower_extract = previous_value.Extract(0,
                                                                partial_offset - 1)
                new_value = upper_new_value.Concat(previous_lower_extract)
            else:
                new_value = upper_new_value

            dest_reg = instr.full_reg
            regs[dest_reg] = new_value

        case LowLevelILSetRegSplitSsa():
            assert isinstance(instr.hi, LowLevelILRegSplitDestSsa) and isinstance(
                instr.lo, LowLevelILRegSplitDestSsa)
            hi_dest = instr.hi.dest
            lo_dest = instr.lo.dest
            value = instruction_to_tainted_bitvec(
                instr.src, (instr.lo.size + instr.hi.size) * 8, instr_idx, regs, flags, memories)
            regs[lo_dest] = value.Extract(0, instr.lo.size * 8 - 1)
            regs[hi_dest] = value.Extract(
                instr.lo.size * 8, instr.lo.size * 8 + instr.hi.size * 8 - 1)

        # set flags operations
        case LowLevelILSetFlagSsa():
            source_bool = instruction_to_tainted_bool(
                instr.src, instr_idx, regs, flags, memories)
            flags[instr.dest] = source_bool

        # set memory operations
        case LowLevelILStoreSsa():
            source_memory = memories[instr.src_memory]
            src_type = infer_expr_type(instr.src)
            if src_type == TaintedBool:
                value = TaintedBitvec.from_tainted_bool(
                    instruction_to_tainted_bool(instr.src, instr_idx, regs, flags, memories), instr.size * 8)
            else:
                value = instruction_to_tainted_bitvec(
                    instr.src, instr.size * 8, instr_idx, regs, flags, memories)
            # memory write should only be valid if dest is tainted
            # but we don't handle this here
            dest = instruction_to_tainted_bitvec(
                instr.dest, instr.function.arch.address_size * 8, instr_idx, regs, flags, memories)
            memories[instr.dest_memory] = source_memory.write_at(
                dest.value, value)

        # phi operations
        case LowLevelILRegPhi() | LowLevelILFlagPhi() | LowLevelILMemPhi():
            do_phi_smt_translation(gadget, instr, instr_idx, regs,
                                   flags, memories)

        # may be emitted just to update flags
        # these operations do not directly set any register/flag/memory value
        # but they update condition flags
        case LowLevelILBinaryBase() | LowLevelILUnaryBase() | LowLevelILLoadSsa() | LowLevelILRegSsa() | LowLevelILRegSsaPartial() | LowLevelILConst():
            pass
        # rest
        case LowLevelILNop() | LowLevelILGoto() | LowLevelILIf():
            pass
        case _:
            raise NotImplementedError(
                f"conversion of {type(instr)} operations into SMT assertion is not implemented")


class MemoryPreconditionsBuilderBase(ABC):
    @abstractmethod
    def __init__(self) -> None:
        raise NotImplementedError()

    @abstractmethod
    def add_read(self, addr: TaintedBitvec, byte_size: int) -> None:
        raise NotImplementedError()

    @abstractmethod
    def add_write(self, addr: TaintedBitvec, byte_size: int) -> None:
        raise NotImplementedError()

    @abstractmethod
    def build_preconditions(self, predicates: UninterpretedMemoryPredicates) -> fnode.FNode:
        raise NotImplementedError()


class BasicMemoryPreconditionsBuilder(MemoryPreconditionsBuilderBase):
    def __init__(self) -> None:
        self._reads: List[Tuple[TaintedBitvec, int]] = []
        self._writes: List[Tuple[TaintedBitvec, int]] = []

    def add_read(self, addr: TaintedBitvec, byte_size: int) -> None:
        self._reads.append((addr, byte_size))

    def add_write(self, addr: TaintedBitvec, byte_size: int) -> None:
        self._writes.append((addr, byte_size))

    def build_preconditions(self, predicates: UninterpretedMemoryPredicates) -> fnode.FNode:
        def is_read_valid(addr: TaintedBitvec, byte_size: int) -> fnode.FNode:
            is_in_readable_region = Function(predicates.is_range_readable_symbol, [
                addr.value, BV(byte_size, predicates.address_width)])
            return addr.taint & is_in_readable_region

        def is_write_valid(addr: TaintedBitvec, byte_size: int) -> fnode.FNode:
            is_in_writable_region = Function(predicates.is_range_writable_symbol, [
                addr.value, BV(byte_size, predicates.address_width)])
            return addr.taint & is_in_writable_region

        all_reads_valid = [is_read_valid(addr, size)
                           for addr, size in self._reads]
        all_writes_valid = [is_write_valid(addr, size)
                            for addr, size in self._writes]

        return And(all_reads_valid + all_writes_valid)


class RangeMemoryPreconditionsBuilder(MemoryPreconditionsBuilderBase):
    def __init__(self) -> None:
        raise NotImplementedError()

    @classmethod
    def extract_base_offset(cls, addr: fnode.FNode) -> Tuple[fnode.FNode, int]:
        raise NotImplementedError()

    def add_read(self, addr: TaintedBitvec, byte_size: int) -> None:
        raise NotImplementedError()

    def add_write(self, addr: TaintedBitvec, byte_size: int) -> None:
        raise NotImplementedError()

    def build_preconditions(self, predicates: UninterpretedMemoryPredicates) -> fnode.FNode:
        raise NotImplementedError()


@dataclass(frozen=True)
class SMTGadgetSemantics:
    registers: Dict[str, TaintedBitvec]
    flags: Dict[str, TaintedBool]
    memory: TaintedMemory


@dataclass(frozen=True)
class SMTGadgetPreconditions:
    formula: fnode.FNode
    memory_predicates: UninterpretedMemoryPredicates


class SelectAfterStoreWalker(IdentityDagWalker):
    def __init__(self, env=None, invalidate_memoization=False):
        super().__init__(env, invalidate_memoization)
        self._has_select_after_store = False

    @property
    def has_select_after_store(self) -> bool:
        return self._has_select_after_store

    def walk_array_select(self, formula: fnode.FNode, args: List[fnode.FNode], **kwargs) -> fnode.FNode:
        array: fnode.FNode = args[0]
        self._has_select_after_store = array.is_store()
        return super().walk_array_select(formula, args, **kwargs)


class SMTGadget(JSONGadget):
    def __init__(self, arch_info: ArchInfo, llil_gadget: CustomWorkflowSSAGadgetAnalysis.LLILGadget, smt_simplifier: Simplifier | None = None, memory_precondition_builder_type: type[MemoryPreconditionsBuilderBase] = BasicMemoryPreconditionsBuilder):
        # ensure that we cannot mistakenly use an smt variable from another environment
        # pysmt.environment.push_env()
        # pysmt.environment.get_env().enable_infix_notation = True

        self._simplifier = smt_simplifier if smt_simplifier is not None else Simplifier()
        self.llil_gadget = llil_gadget
        self.arch_info = arch_info

        self.initial_regs: Dict[str, GadgetInputSymbol[TaintedBitvec]] = dict()
        regs: Dict[SSARegister, TaintedBitvec] = dict()
        for reg in llil_gadget.used_registers:
            ssa_reg = SSARegister(reg, 0)
            regsym_name = f"{reg.name}#0"
            tbv = TaintedBitvec.with_name(regsym_name, reg.info.size * 8)
            self.initial_regs[reg.name] = GadgetInputSymbol(regsym_name, tbv)
            regs[ssa_reg] = tbv

        self.initial_flags: Dict[str, GadgetInputSymbol[TaintedBool]] = dict()
        flags: Dict[SSAFlag, TaintedBool] = dict()
        for flag in llil_gadget.used_flags:
            ssa_flag = SSAFlag(flag, 0)
            flagsym_name = f"{flag.name}#0"
            tbool = TaintedBool.with_name(flagsym_name)
            self.initial_flags[flag.name] = GadgetInputSymbol(
                flagsym_name, tbool)
            flags[ssa_flag] = tbool

        self.initial_mem = GadgetInputSymbol("mem#0", TaintedMemory.with_name(
            self.arch_info.endian, self.arch_info.pointer_width, "mem#0"))
        memories = {0: self.initial_mem.var}

        for bb in llil_gadget.basic_blocks_topological_sort:
            is_exit_bb = bb == llil_gadget.exit_basic_block
            for i in range(bb.start, bb.end):
                instr = llil_gadget.llil_ssa[ExpressionIndex(i)]
                process_llil_ssa_instruction_to_smt(
                    llil_gadget, i, instr, regs, flags, memories, is_exit_bb)

        self._regs = regs
        self._flags = flags
        self._memories = memories

        self._memory_preconditions_builder_type = memory_precondition_builder_type
        self._memory_predicates = UninterpretedMemoryPredicates.new_fresh(
            self.arch_info.pointer_width)

        self._preconditions_formula: fnode.FNode = self._build_preconditions_formula()
        self._liveout_formulae: SMTGadgetSemantics = self._build_liveout_formulae()

        self._output_symbols, self._final_formula = self._build_final_formula()

        has_store_operation = len(self._memories) > 1

        super().__init__(self.arch_info, llil_gadget.assembly_string, self._memory_predicates, GadgetInputSymbols(self.initial_regs, self.initial_flags,
                                                                                                                  self.initial_mem), self._output_symbols, self._final_formula, has_store_operation)

        # pysmt.environment.pop_env()

    @property
    def num_store_operation(self) -> int:
        return len(self._memories) - 1

    @cached_property
    def has_select_after_store_operation(self) -> bool:
        def _has_select_after_store(formula: fnode.FNode) -> bool:
            walker = SelectAfterStoreWalker()
            walker.walk(formula)
            return walker.has_select_after_store
        return any(map(lambda treg: _has_select_after_store(treg.value), self._liveout_formulae.registers.values()))\
            or any(map(lambda tflag: _has_select_after_store(tflag.value), self._liveout_formulae.flags.values()))\
            or _has_select_after_store(self._liveout_formulae.memory.content)

    def _new_memory_preconditions_builder(self) -> MemoryPreconditionsBuilderBase:
        return self._memory_preconditions_builder_type()

    def _build_final_formula(self) -> Tuple[GadgetOutputSymbols, fnode.FNode]:
        formulae = [self._preconditions_formula]

        output_regs: Dict[str, GadgetOutputSymbol[TaintedBitvec]] = dict()
        for regname, reg_formula in self._liveout_formulae.registers.items():
            width = self.arch_info.registers_info[regname].width
            prefix = f"out_{regname}"
            out_reg = TaintedBitvec.with_name(prefix, width)
            output_regs[regname] = GadgetOutputSymbol(prefix, out_reg)
            formulae.append(out_reg.Equals(reg_formula))

        output_flags: Dict[str, GadgetOutputSymbol[TaintedBool]] = dict()
        for flagname, flag_formula in self._liveout_formulae.flags.items():
            prefix = f"out_{flagname}"
            out_flag = TaintedBool.with_name(prefix)
            output_flags[flagname] = GadgetOutputSymbol(prefix, out_flag)
            formulae.append(out_flag.Equals(flag_formula))

        prefix = "out_mem"
        out_mem = TaintedMemory.with_name(
            self.arch_info.endian, self.arch_info.pointer_width, prefix)
        output_mem: GadgetOutputSymbol[TaintedMemory] = GadgetOutputSymbol(
            prefix, out_mem)
        formulae.append(out_mem.Equals(self._liveout_formulae.memory))

        return GadgetOutputSymbols(output_regs, output_flags, output_mem), self._simplifier.simplify(And(formulae))

    def _build_liveout_formulae(self) -> SMTGadgetSemantics:
        simplifier = self._simplifier
        liveout = self.llil_gadget.basic_blocks_liveout_information[
            self.llil_gadget.exit_basic_block]

        liveout_regs_smt: Dict[str, TaintedBitvec] = dict()
        liveout_flags_smt: Dict[str, TaintedBool] = dict()
        liveout_memory_smt: TaintedMemory = self._memories[liveout.get_live_memory_version(
        )].simplify(simplifier)

        # use _reg because only registers that are actually cloberred are worth considering
        for reg in filter(lambda reg: not reg.reg.temp, liveout._regs.values()):
            liveout_regs_smt[reg.reg.name] = self._regs[reg].simplify(
                simplifier)

        # use _flag because only flags that are actually cloberred are worth considering
        for flag in filter(lambda flag: not flag.flag.temp, liveout._flags.values()):
            liveout_flags_smt[flag.flag.name] = self._flags[flag].simplify(
                simplifier)

        return SMTGadgetSemantics(liveout_regs_smt, liveout_flags_smt, liveout_memory_smt)

    def _build_preconditions_formula(self) -> fnode.FNode:
        def may_reach_block(bb: LowLevelILBasicBlock) -> fnode.FNode:
            def gamma_expr_to_may_reach_condition(expr: GammaExpression[LowLevelILInstruction, LowLevelILBasicBlock]) -> TaintedBool:
                match expr:
                    case expression.Empty():
                        # there's no path to the block
                        return TaintedBool.from_bool(False)
                    case expression.Lambda(_, _):
                        # there's a path to the block
                        return TaintedBool.from_bool(True)
                    case expression.Gamma(cond_instr, then_expr, elze_expr):
                        condition = instruction_to_tainted_bool(
                            # FIXME: instruction index...
                            cond_instr, -1, self._regs, self._flags, self._memories)
                        then = gamma_expr_to_may_reach_condition(then_expr)
                        elze = gamma_expr_to_may_reach_condition(elze_expr)
                        ite: TaintedBool = condition.Ite(then, elze)
                        return ite
                raise NotImplementedError("should be unreachable")

            bb_gating = self.llil_gadget.basic_blocks_gating_expressions[bb]
            entry_gating_gamma_expr = cast(
                GammaExpression[LowLevelILInstruction, LowLevelILBasicBlock], bb_gating.from_entry.expression)
            tainted_condition = gamma_expr_to_may_reach_condition(
                entry_gating_gamma_expr)
            # if the formula is not tainted, then we don't know which path is taken, so the block may be reached
            # however if it is tainted, then the value must be true for the block to be reached
            return Not(tainted_condition.taint) | tainted_condition.value

        def build_block_preconditions(bb: LowLevelILBasicBlock) -> fnode.FNode:
            preconditions = []
            mem_preconditions_builder = self._new_memory_preconditions_builder()

            # TODO: group memory read/write ranges
            def visit_instr(instr: LowLevelILInstruction, instr_idx: int) -> fnode.FNode | None:
                precondition = None
                match instr:
                    case LowLevelILLoadSsa():
                        tainted_read_address = instruction_to_tainted_bitvec(
                            instr.src, instr.function.arch.address_size * 8, instr_idx, self._regs, self._flags, self._memories)
                        read_byte_size = instr.size
                        mem_preconditions_builder.add_read(
                            tainted_read_address, read_byte_size)
                    case LowLevelILStoreSsa():
                        tainted_write_address = instruction_to_tainted_bitvec(
                            instr.dest, instr.function.arch.address_size * 8, instr_idx, self._regs, self._flags, self._memories)
                        write_byte_size = instr.size
                        mem_preconditions_builder.add_write(
                            tainted_write_address, write_byte_size)
                    case LowLevelILDivu() | LowLevelILDivs():
                        tainted_divisor = instruction_to_tainted_bitvec(
                            instr.right, instr.left.size * 8, instr_idx, self._regs, self._flags, self._memories)
                        precondition = tainted_divisor.taint & (
                            tainted_divisor.value.NotEquals(0))
                return precondition

            for i in range(bb.start, bb.end):
                instr = self.llil_gadget.llil_ssa[ExpressionIndex(i)]
                preconditions.extend(list(instr.traverse(visit_instr, i)))

            preconditions.append(
                mem_preconditions_builder.build_preconditions(self._memory_predicates))

            bb_output_cond = self.llil_gadget.block_output_condition.get(bb)
            if bb_output_cond is not None:
                match bb_output_cond:
                    case MustSatisfyCondition(cond_instr):
                        must_sat_tainted_condition = instruction_to_tainted_bool(
                            cond_instr, -1, self._regs, self._flags, self._memories)
                        preconditions.append(
                            must_sat_tainted_condition.taint & must_sat_tainted_condition.value)
                    case MustNotSatisfyCondition(cond_instr):
                        must_unsat_tainted_condition = instruction_to_tainted_bool(
                            cond_instr, -1, self._regs, self._flags, self._memories)
                        preconditions.append(must_unsat_tainted_condition.taint & Not(
                            must_unsat_tainted_condition.value))

            return And(preconditions)

        block_preconditions = And([may_reach_block(bb).Implies(build_block_preconditions(
            bb)) for bb in self.llil_gadget.basic_blocks_topological_sort])

        gadget_addr = self.llil_gadget.address
        initial_pc = self.initial_regs[self.arch_info.program_counter].var
        pc_precondition = initial_pc.Equals(
            TaintedBitvec.from_int(gadget_addr, self.arch_info.pointer_width))

        return self._simplifier.simplify(And([pc_precondition, block_preconditions]))
