from pysmt import fnode
from pysmt.shortcuts import And
from typing import Self, Dict, Callable

from .tainted_types.bitvec import TaintedBitvec
from .tainted_types.bool import TaintedBool
from .memory import TaintedMemory
from .archinfo import ArchInfo


from dataclasses import dataclass

from collections import OrderedDict


@dataclass
class State:
    arch_info: ArchInfo
    registers: OrderedDict[str, TaintedBitvec]
    flags: OrderedDict[str, TaintedBool]
    memory: TaintedMemory

    # @classmethod
    # def with_name(cls, arch: ArchInfo, name: str) -> Self:
    #     regs = arch.register_symbols(name)
    #     flags = arch.flag_symbols(name)
    #     mem = arch.memory_symbol(name)
    #     return cls(arch, regs, flags, mem)

    def _substitute_rules(self, other: Self) -> Dict[fnode.FNode, fnode.FNode]:
        rules = self.memory._substitute_rules(other.memory)
        for self_reg, other_reg in zip(self.registers.values(), other.registers.values()):
            rules |= self_reg._substitute_rules(other_reg)
        return rules

    def map(self, reg_map: Callable[[str, TaintedBitvec], TaintedBitvec], flag_map: Callable[[str, TaintedBool], TaintedBool], mem_map: Callable[[TaintedMemory], TaintedMemory]) -> Self:
        new_regs = OrderedDict()
        for (regname, regval) in self.registers.items():
            new_regs[regname] = reg_map(regname, regval)

        new_flags = OrderedDict()
        for (flagname, flagval) in self.flags.items():
            new_flags[flagname] = flag_map(flagname, flagval)

        new_mem = mem_map(self.memory)

        return self.__class__(self.arch_info, new_regs, new_flags, new_mem)

    def Equals(self, other: Self) -> fnode.FNode:
        mem_equal = self.memory.Equals(other.memory)
        regs_equal = []
        for name, regval in self.registers.items():
            regs_equal.append(regval.Equals(other.registers[name]))

        flags_equal = []
        for name, flagval in self.flags.items():
            flags_equal.append(flagval.Equals(other.flags[name]))

        return And([mem_equal] + regs_equal + flags_equal)
