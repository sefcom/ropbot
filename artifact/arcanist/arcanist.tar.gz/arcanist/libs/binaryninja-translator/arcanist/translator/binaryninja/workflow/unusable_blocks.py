from arcanist.translator.binaryninja.util import _is_value_potentially_controllable
from arcanist.translator.binaryninja.workflow.gadget_exit_intrinsic import GADGET_EXIT_INTRINSIC_NAME
from binaryninja import BranchType, LowLevelILLabel
from binaryninja.workflow import Activity, AnalysisContext
from binaryninja.lowlevelil import LowLevelILConst, LowLevelILRor, LowLevelILRol, LowLevelILAsr, LowLevelILIntrinsic, LowLevelILUndef, LowLevelILUnimpl, LowLevelILInstruction, LowLevelILSetFlag, LowLevelILBasicBlock, LowLevelILSetReg, ExpressionIndex, LowLevelILNoret, LowLevelILFunction, LowLevelILBasicBlock, LowLevelILJump, LowLevelILIf
from binaryninja.enums import LowLevelILOperation
from binaryninja.log import log_debug
from typing import Set, cast, List
from collections import deque


def _has_basic_block_unsupported_operation(bb: LowLevelILBasicBlock) -> bool:
    _unsupported_operations = [
        # intrinsic
        LowLevelILOperation.LLIL_INTRINSIC,
        LowLevelILOperation.LLIL_SYSCALL,
        # crashing/debug operations
        LowLevelILOperation.LLIL_TRAP,
        LowLevelILOperation.LLIL_BP,
        # undefine/unimplemented
        LowLevelILOperation.LLIL_UNDEF,
        LowLevelILOperation.LLIL_UNIMPL,
        LowLevelILOperation.LLIL_UNIMPL_MEM,
        # stack reg operations (mainly for x86 floating-point stack)
        LowLevelILOperation.LLIL_SET_REG_STACK_REL,
        LowLevelILOperation.LLIL_REG_STACK_FREE_REL,
        LowLevelILOperation.LLIL_REG_STACK_FREE_REG,
        LowLevelILOperation.LLIL_REG_STACK_PUSH,
        LowLevelILOperation.LLIL_REG_STACK_POP,
        # flag-bit operation
        LowLevelILOperation.LLIL_FLAG_BIT,
        # complex operations with carry
        LowLevelILOperation.LLIL_RLC,
        LowLevelILOperation.LLIL_RRC,
        # double-precision operations
        LowLevelILOperation.LLIL_MULU_DP,
        LowLevelILOperation.LLIL_MULS_DP,
        LowLevelILOperation.LLIL_DIVU_DP,
        LowLevelILOperation.LLIL_DIVS_DP,
        LowLevelILOperation.LLIL_MODU_DP,
        LowLevelILOperation.LLIL_MODS_DP,
        # floating-point operations
        LowLevelILOperation.LLIL_FABS,
        LowLevelILOperation.LLIL_FNEG,
        LowLevelILOperation.LLIL_FADD,
        LowLevelILOperation.LLIL_FSUB,
        LowLevelILOperation.LLIL_FMUL,
        LowLevelILOperation.LLIL_FDIV,
        LowLevelILOperation.LLIL_FSQRT,
        LowLevelILOperation.LLIL_FCMP_E,
        LowLevelILOperation.LLIL_FCMP_NE,
        LowLevelILOperation.LLIL_FCMP_GE,
        LowLevelILOperation.LLIL_FCMP_LE,
        LowLevelILOperation.LLIL_FCMP_GT,
        LowLevelILOperation.LLIL_FCMP_GT,
        LowLevelILOperation.LLIL_FCMP_O,
        LowLevelILOperation.LLIL_FCMP_UO,
        LowLevelILOperation.LLIL_FLOAT_CONST,
        LowLevelILOperation.LLIL_FLOAT_CONV,
        LowLevelILOperation.LLIL_FLOAT_TO_INT,
        LowLevelILOperation.LLIL_INT_TO_FLOAT,
        LowLevelILOperation.LLIL_ROUND_TO_INT,
        LowLevelILOperation.LLIL_CEIL,
        LowLevelILOperation.LLIL_FLOOR,
        LowLevelILOperation.LLIL_FTRUNC,
    ]

    _unsupported_ssa_operations = [
        LowLevelILOperation.LLIL_SET_REG_STACK_ABS_SSA,
        LowLevelILOperation.LLIL_SET_REG_STACK_REL_SSA,
    ]

    def _is_instr_valid_visitor(_name: str, instr: LowLevelILInstruction, _op_type, _parent) -> bool:
        match instr:
            case LowLevelILRor() | LowLevelILRol() | LowLevelILAsr():
                # the bit-vector theory only supports rotations whose count is constant
                return isinstance(instr.right, LowLevelILConst)

        return (instr.operation not in _unsupported_operations) and (instr.ssa_form.operation not in _unsupported_ssa_operations)

    def _has_unsupported_operations(instr: LowLevelILInstruction) -> bool:
        log_debug(f'visiting {instr}')
        match instr:
            case LowLevelILSetReg() | LowLevelILSetFlag():
                # we tolerate the presence of 'undefined' or 'unimplemented' only when it's
                # the source of a flag or register assignment
                if isinstance(instr.src, LowLevelILUndef) or isinstance(instr.src, LowLevelILUnimpl):
                    return False

        return not instr.visit(_is_instr_valid_visitor)  # type: ignore

    # def _is_invalid_instr(instr: LowLevelILInstruction) -> bool:
    #     return (instr.operation not in _unsupported_operations) and (instr.ssa_form.operation not in _unsupported_ssa_operations)

    llil = bb.il_function
    instrs = [llil[ExpressionIndex(i)] for i in range(bb.start, bb.end)]

    return any(map(_has_unsupported_operations, instrs))


def _has_basic_block_controllable_exit_after_rewritten_jumpretcall(bb: LowLevelILBasicBlock) -> bool:
    llil = bb.il_function
    instr = llil[ExpressionIndex(bb.end - 2)]
    # a rewritten jump/ret/call should always be: 'set program counter; goto exit'
    # thus the penultimate instruction should be the one that set the program counter
    assert isinstance(instr, LowLevelILSetReg)

    return _is_value_potentially_controllable(instr.src)


def _find_usable_blocks_after_rewritten_jumpretcall(llil: LowLevelILFunction, exit_bb: LowLevelILBasicBlock) -> Set[LowLevelILBasicBlock]:
    to_visit = deque([exit_bb])
    visited = set()

    while to_visit:
        bb = to_visit.popleft()
        visited.add(bb)

        # if the current block is the 'exit_bb' (containing the noreturn)
        # then the sources of incoming edges are all candidate to be
        # controllable jumps/exits
        is_exit = (bb == exit_bb)

        incoming = bb.incoming_edges
        for edge in incoming:
            source = cast(LowLevelILBasicBlock, edge.source)

            # if it's a back-edge don't visit, we must ignore back-edges because we will ensure
            # they are never taken
            if edge.back_edge:
                continue

            # if the target block is the 'exit_bb'
            # then only visit it if the jump is potentially controllable
            if is_exit and not _has_basic_block_controllable_exit_after_rewritten_jumpretcall(source):
                continue

            # if the source block contains unsupported operations
            # do not visit it
            if _has_basic_block_unsupported_operation(source):
                continue

            to_visit.appendleft(source)

    return visited


def remove_unusable_blocks_after_rewritten_jumpretcall(analysis_context: AnalysisContext) -> None:
    # we must use the llil instead of lifted_il because
    # the detection of "potentially controllable" jumps
    # uses the "possible_values" property of binary ninja
    # which is only computed for llil/mlil.hlil it seems
    # but not for "lifted_il"
    il = analysis_context.llil
    saved_addr = il.current_address

    # find the noreturn instruction we inserted during the jump/ret/call rewrite pass
    # there should be only one noreturn
    # we cannot just take the last instruction (it's where it's supposed to be inserted)
    # because the lifting from lifted_il to llil can relocate it :S
    # so we must search for it again heh
    instr = None
    for i in range(len(il)):
        if isinstance(il[ExpressionIndex(i)], LowLevelILNoret):
            assert instr is None
            instr = il[ExpressionIndex(i)]

    if instr is not None:
        exit_bb = instr.il_basic_block
        assert instr.operation == LowLevelILOperation.LLIL_NORET

        # find blocks that can eventually lead to a controllable exit
        usable_blocks = _find_usable_blocks_after_rewritten_jumpretcall(
            il, exit_bb)
    else:
        # if we cannot find the noreturn, it must've been smashed during
        # the lifting from 'lifted_il' to 'llil', thus must be unreachable
        # so just remove everything
        usable_blocks = set()

    # undefine any operation that is not in a usable basic block
    # this simplifies the control-flow graph of the gadget in the end
    for bb in il.basic_blocks:
        if bb not in usable_blocks:
            for i in range(bb.start, bb.end):
                il.set_current_address(il[ExpressionIndex(i)].address)
                il.replace_expr(il[ExpressionIndex(i)], il.undefined())

    # recompute everything
    il.set_current_address(saved_addr)
    il.finalize()
    il.generate_ssa_form()


class RemoveUnusableBlocksActivity(Activity):
    def __init__(self, configuration: str):
        super().__init__(configuration, handle=None,
                         action=remove_unusable_blocks_after_rewritten_jumpretcall)
