from __future__ import annotations

from multimethod import multimethod
from typing import Any, Self, TypeVar, cast
from pysmt.shortcuts import FreshSymbol, Symbol, Bool, TRUE, FALSE, BVOne, BVZero, Not
from pysmt.typing import BOOL
from pysmt import fnode
from pysmt.exceptions import PysmtTypeError
from pysmt.simplifier import Simplifier

from .taint import SingleTaintValue

T = TypeVar("T")


class TaintedBool(SingleTaintValue):
    def __init__(self, value: fnode.FNode, taint: fnode.FNode) -> None:
        super().__init__(value, taint)
        if not value.get_type().is_bool_type():
            raise PysmtTypeError(
                f"Expected symbol type of 'value' to be 'BV' for constructing '{self.__class__.__name__}', got '{value.get_type()}' instead")

    @classmethod
    def with_name(cls, name: str) -> Self:
        value = Symbol(name + "_value", BOOL)
        taint = Symbol(name + "_taint", BOOL)
        return cls(value, taint)

    @classmethod
    def fresh(cls, template: str) -> Self:
        value = FreshSymbol(template + "_value", BOOL)
        taint = FreshSymbol(template + "_taint", BOOL)
        return cls(value, taint)

    @classmethod
    def from_bool(cls, b: bool) -> Self:
        return cls(Bool(b), TRUE())

    @classmethod
    def new_false_untainted(cls) -> Self:
        return cls(Bool(False), FALSE())

    @property
    def value(self) -> fnode.FNode:
        return self._value

    @property
    def taint(self) -> fnode.FNode:
        return self._taint

    def __invert__(self) -> TaintedBool:
        value = Not(self.value)
        taint = self.taint
        return TaintedBool(value, taint)

    @multimethod
    def __and__(self, other: Any) -> TaintedBool:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBool '&' operation")

    @multimethod
    def __or__(self, other: Any) -> TaintedBool:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBool '|' operation")

    @multimethod
    def __xor__(self, other: Any) -> TaintedBool:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBool '^' operation")

    @multimethod
    def Ite(self, then: T, elze: T) -> T:
        raise TypeError(
            f"Invalid types {type(then).__name__} and {type(elze).__name__} for TaintedBool 'if-then-else' operation")

    def Equals(self, other: Self) -> fnode.FNode:
        return self.value.Iff(other.value) & self.taint.Iff(other.taint)

    def tainted_equals(self, other: TaintedBool) -> TaintedBool:
        value = self.value.Iff(other.value)
        taint = self.taint & other.taint
        return TaintedBool(value, taint)

    def tainted_not_equals(self, other: TaintedBool) -> TaintedBool:
        value = Not(self.value.Iff(other.value))
        taint = self.taint & other.taint
        return TaintedBool(value, taint)

    def simplify(self, simplifier: Simplifier = Simplifier()) -> TaintedBool:
        return TaintedBool(simplifier.simplify(self.value), simplifier.simplify(self.taint))


@TaintedBool.__and__.register
def _(self, other: TaintedBool) -> TaintedBool:
    value = self.value & other.value
    taint = (self.taint & other.taint) | (self.taint & (
        self.value.Iff(FALSE()))) | (other.taint & (other.value.Iff(FALSE())))
    return TaintedBool(value, taint)


@TaintedBool.__and__.register
def _(self, b: bool) -> TaintedBool:
    if b == False:
        return TaintedBool.from_bool(False)
    return TaintedBool(self.value, self.taint)


@TaintedBool.__or__.register
def _(self, other: TaintedBool) -> TaintedBool:
    value = self.value | other.value
    taint = (self.taint & other.taint) | (self.taint & (
        self.value.Iff(TRUE()))) | (other.taint & (other.value.Iff(TRUE())))
    return TaintedBool(value, taint)


@TaintedBool.__or__.register
def _(self, b: bool) -> TaintedBool:
    if b == True:
        return TaintedBool.from_bool(True)
    return TaintedBool(self.value, self.taint)


@TaintedBool.__xor__.register
def _(self, other: TaintedBool) -> TaintedBool:
    value = self.value ^ other.value
    taint = self.taint & other.taint
    return TaintedBool(value, taint)


@TaintedBool.__xor__.register
def _(self, b: bool) -> TaintedBool:
    value = self.value ^ b
    taint = self.taint
    return TaintedBool(value, taint)


@TaintedBool.Ite.register
def _(self, then: TaintedBool, elze: TaintedBool) -> TaintedBool:
    if type(then) != type(elze):
        raise TypeError(
            f"Both sides of if-then-else should be of same type, but got 'then':{type(then)}, 'else':{type(elze)}")

    value = self.value.Ite(then.value, elze.value)
    taint = (then.taint & elze.taint & (then.value.Iff(elze.value))) | (
        self.taint & (self.value.Ite(then.taint, elze.taint)))
    return then.__class__(value, taint)
