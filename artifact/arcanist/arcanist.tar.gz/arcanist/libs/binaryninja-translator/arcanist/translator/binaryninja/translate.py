from typing import List, cast
from arcanist.architecture import Architecture
from arcanist.gadgets.extraction import RawGadget, RawGadgetLibrary, UnsupportedArchitectureError
from arcanist.gadgets.translation import GadgetTranslator
from arcanist.platform import Platform
from arcanist.synthesizer.archinfo import ArchInfo
from arcanist.synthesizer.gadget import GadgetLibrary, JSONGadget
from arcanist.translator.binaryninja.llil_gadget import CustomWorkflowSSAGadgetAnalysis
from arcanist.translator.binaryninja.smt_gadget import BasicMemoryPreconditionsBuilder, MemoryPreconditionsBuilderBase, SMTGadget, binaryninja_arch_to_synthesizer_arch_info
from arcanist.translator.binaryninja.util import arcanist_arch_to_binja_arch_name

import binaryninja

from pysmt.simplifier import Simplifier

import logging
LOGGER = logging.getLogger(__name__)


class BinaryNinjaTranslator(GadgetTranslator):
    def __init__(self, platform: Platform, smt_simplifier: Simplifier | None = None, memory_precondition_builder_type: type[MemoryPreconditionsBuilderBase] = BasicMemoryPreconditionsBuilder) -> None:
        self._simplifier = smt_simplifier if smt_simplifier is not None else Simplifier()
        self._memory_precondition_builder_type = memory_precondition_builder_type
        self._platform = platform

    def _translate_single(self, arch: Architecture, plat: Platform, arch_info: ArchInfo, gadget: RawGadget) -> SMTGadget | None:
        try:
            llil_gadget = CustomWorkflowSSAGadgetAnalysis.lift_raw_gadget(
                gadget, arch, plat)
        except Exception:
            LOGGER.warning(
                "Failed to lift gadget to LLIL, possibly due to Binary Ninja errors")
            return None

        if llil_gadget is None:
            return None
        try:
            smt_gadget = SMTGadget(
                arch_info, llil_gadget, self._simplifier, self._memory_precondition_builder_type)
        except Exception:
            LOGGER.warning(f"Failed to translate gadget possibly due to malformed LLIL instruction: {gadget.assembly_string}")
            return None

        return smt_gadget

    def translate_single(self, arch: Architecture, gadget: RawGadget) -> SMTGadget | None:
        arch_name = arcanist_arch_to_binja_arch_name(arch)
        if arch_name is None:
            raise UnsupportedArchitectureError(
                f"binary ninja translator does not support {arch}")
        # type: ignore
        binja_arch: binaryninja.Architecture = binaryninja.Architecture[arch_name]
        arch_info = binaryninja_arch_to_synthesizer_arch_info(
            binja_arch)
        return self._translate_single(arch, self._platform, arch_info, gadget)

    def translate_library(self, library: RawGadgetLibrary) -> GadgetLibrary[SMTGadget]:
        arch_name = arcanist_arch_to_binja_arch_name(library.architecture)
        if arch_name is None:
            raise UnsupportedArchitectureError(
                f"binary ninja translator does not support {library.architecture}")
        # type: ignore
        binja_arch: binaryninja.Architecture = binaryninja.Architecture[arch_name]
        arch_info = binaryninja_arch_to_synthesizer_arch_info(
            binja_arch)

        gadgets = list(filter(lambda g: g is not None, map(lambda raw: self._translate_single(
            library.architecture, self._platform, arch_info, raw), library.gadgets)))

        # cast required because type inferance does not detect that we filter out all None values
        return GadgetLibrary(library.architecture, arch_info, cast(List[SMTGadget], gadgets))

    def translate_library_json(self, library: RawGadgetLibrary) -> GadgetLibrary[JSONGadget]:
        arch_name = arcanist_arch_to_binja_arch_name(library.architecture)
        if arch_name is None:
            raise UnsupportedArchitectureError(
                f"binary ninja translator does not support {library.architecture}")
        # type: ignore
        binja_arch: binaryninja.Architecture = binaryninja.Architecture[arch_name]
        arch_info = binaryninja_arch_to_synthesizer_arch_info(
            binja_arch)

        gadgets = []
        for raw in library.gadgets:
            gadget = self._translate_single(
                library.architecture, self._platform, arch_info, raw)
            if gadget is None:
                continue
            gadgets.append(JSONGadget.from_other(gadget))

        return GadgetLibrary(library.architecture, arch_info, cast(List[JSONGadget], gadgets))
