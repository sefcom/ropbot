from io import StringIO
from pysmt.smtlib.printers import SmtDagPrinter
from pysmt import fnode


class ArcanistSMTPrinter(SmtDagPrinter):
    def walk_bv_constant(self, formula: fnode.FNode):
        self.write("#x" + formula.bv_str(fmt='x'))


def to_smtlib(formula: fnode.FNode) -> str:
    buf = StringIO()
    p = SmtDagPrinter(buf)
    p.printer(formula)
    res = buf.getvalue()
    buf.close()
    return res
