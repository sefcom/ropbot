from __future__ import annotations
from collections import OrderedDict
from io import StringIO
from arcanist.architecture import Architecture, Endian
from arcanist.synthesizer.archinfo import ArchInfo, FlagInfo, RegInfo
from arcanist.synthesizer.memory import TaintedMemory
import dataclasses
from dataclasses import dataclass
from typing import Callable, Dict, Generic, List, Self, TypeVar, final, Any, Set
from arcanist.synthesizer.memory_layout import MemoryLayout
from arcanist.synthesizer.state import State
from arcanist.synthesizer.tainted_types.bitvec import TaintedBitvec
from arcanist.synthesizer.tainted_types.bool import TaintedBool
from pysmt import fnode
from pysmt.substituter import FunctionInterpretation
from pysmt.shortcuts import And
from pysmt.smtlib.parser import SmtLibParser, Tokenizer

from functools import cached_property

import json

from abc import ABC, abstractmethod

from pysmt.shortcuts import BOOL, BVType, FreshSymbol, FunctionType, Symbol

from arcanist.synthesizer.smt.printer import to_smtlib

import logging
LOGGER = logging.getLogger(__name__)


class GadgetBase(ABC):
    @abstractmethod
    def connect(self, input: State, output: State, mem_layout: MemoryLayout) -> fnode.FNode:
        raise NotImplementedError

    @property
    @abstractmethod
    def assembly_str(self) -> str:
        raise NotImplementedError

    @property
    @abstractmethod
    def has_store_operation(self) -> bool:
        raise NotImplementedError

    @property
    @abstractmethod
    def used_regs(self) -> Set[str]:
        raise NotImplementedError


G = TypeVar('G', bound=GadgetBase)
H = TypeVar("H", bound=GadgetBase)


@dataclass(frozen=True)
class GadgetLibrary(Generic[G]):
    arch: Architecture
    arch_info: ArchInfo
    gadgets: List[G]

    def filter(self, f: Callable[[G], bool]) -> GadgetLibrary[G]:
        gadgets = list(filter(f, self.gadgets))
        return GadgetLibrary(self.arch, self.arch_info, gadgets)

    def map(self, f: Callable[[G], H]) -> GadgetLibrary[H]:
        gadgets = list(map(f, self.gadgets))
        return GadgetLibrary(self.arch, self.arch_info, gadgets)

    def to_json_str(self: GadgetLibrary[JSONGadget]) -> str:
        return json.dumps(self.to_json_dict())

    def to_json_dict(self: GadgetLibrary[JSONGadget]) -> Dict[str, Any]:
        if len(self.gadgets) > 0 and not isinstance(self.gadgets[0], JSONGadget):
            raise TypeError("can only serialize JSONGadget to JSON")

        d: Dict[str, Any] = dict()
        d["arch"] = self.arch.value
        d["arch_info"] = dataclasses.asdict(self.arch_info)
        d["gadgets"] = list(map(JSONGadget.to_json_dict, self.gadgets))

        return d

    @staticmethod
    def from_json_str(s: str) -> GadgetLibrary[JSONGadget]:
        d = json.loads(s)
        return GadgetLibrary.from_json_dict(d)

    @staticmethod
    def from_json_dict(d: Dict[Any, Any]) -> GadgetLibrary[JSONGadget]:
        arch = Architecture(d["arch"])

        arch_info_dict = d["arch_info"]
        endian = Endian(arch_info_dict["endian"])
        pointer_width = arch_info_dict["pointer_width"]

        registers_info_dict = arch_info_dict["registers_info"]
        registers_info = OrderedDict(map(lambda r: (r[0], RegInfo(
            r[1]["name"], r[1]["width"])), registers_info_dict.items()))

        flags_info_dict = arch_info_dict["flags_info"]
        flags_info = OrderedDict(
            map(lambda f: (f[0], FlagInfo(f[1]["name"])), flags_info_dict.items()))

        program_counter = arch_info_dict["program_counter"]

        arch_info = ArchInfo(endian, pointer_width,
                             registers_info, flags_info, program_counter)

        gadgets = list(
            map(lambda g: JSONGadget.from_json_dict(arch_info, g), d["gadgets"]))

        return GadgetLibrary(arch, arch_info, gadgets)


@dataclass(frozen=True)
class JSONGadget(GadgetBase):
    arch: ArchInfo
    assembly: str
    memory_predicates: UninterpretedMemoryPredicates
    inputs: GadgetInputSymbols
    outputs: GadgetOutputSymbols
    formula: fnode.FNode
    _has_store_operation: bool

    @staticmethod
    def from_other(other: JSONGadget) -> JSONGadget:
        return JSONGadget(other.arch, other.assembly, other.memory_predicates, other.inputs, other.outputs, other.formula, other.has_store_operation)

    @staticmethod
    def from_json_dict(arch: ArchInfo, d: Dict[Any, Any]) -> JSONGadget:
        assert isinstance(d, dict)

        assembly = d["assembly"]
        assert isinstance(assembly, str)

        inputs_dict = d["inputs"]
        assert isinstance(inputs_dict, dict)
        assert isinstance(inputs_dict["registers"], dict)
        assert isinstance(inputs_dict["flags"], dict)
        assert isinstance(inputs_dict["memory"], str)

        outputs_dict = d["outputs"]
        assert isinstance(outputs_dict, dict)
        assert isinstance(outputs_dict["registers"], dict)
        assert isinstance(outputs_dict["flags"], dict)
        assert isinstance(outputs_dict["memory"], str)

        predicates_dict = d["memory_predicates"]
        assert isinstance(predicates_dict, dict)
        assert isinstance(
            predicates_dict["is_range_readable_symbol"], str)
        assert isinstance(
            predicates_dict["is_range_writable_symbol"], str)
        assert isinstance(
            predicates_dict["address_width"], int)
        assert predicates_dict["address_width"] == arch.pointer_width

        formula_smtlib = d["formula"]
        assert isinstance(formula_smtlib, str)

        smt_parser = SmtLibParser()

        # create input registers symbols and add them to parser cache
        input_regs: Dict[str, GadgetInputSymbol[TaintedBitvec]] = dict()
        for regname, regsym in inputs_dict["registers"].items():
            width = arch.registers_info[regname].width
            bv = TaintedBitvec.with_name(regsym, width)
            input_regs[regname] = GadgetInputSymbol(regsym, bv)
            smt_parser.cache.bind(bv.value.symbol_name(), bv.value)
            smt_parser.cache.bind(bv.taint.symbol_name(), bv.taint)

        # create input flags symbols and add them to parser cache
        input_flags: Dict[str, GadgetInputSymbol[TaintedBool]] = dict()
        for flagname, flagsym in inputs_dict["flags"].items():
            b = TaintedBool.with_name(flagsym)
            input_flags[flagname] = GadgetInputSymbol(flagsym, b)
            smt_parser.cache.bind(b.value.symbol_name(), b.value)
            smt_parser.cache.bind(b.taint.symbol_name(), b.taint)

        # create input memory symbols and add them to parser cache
        inmem = TaintedMemory.with_name(
            arch.endian, arch.pointer_width, inputs_dict["memory"])
        input_mem: GadgetInputSymbol[TaintedMemory] = GadgetInputSymbol(
            inputs_dict["memory"], inmem)
        smt_parser.cache.bind(inmem.content.symbol_name(), inmem.content)
        smt_parser.cache.bind(inmem.taints.symbol_name(), inmem.taints)

        # build inputs struct
        inputs = GadgetInputSymbols(input_regs, input_flags, input_mem)

        # create output registers symbols and add them to parser cache
        output_regs: Dict[str, GadgetOutputSymbol[TaintedBitvec]] = dict()
        for regname, outregsym in outputs_dict["registers"].items():
            width = arch.registers_info[regname].width
            bv = TaintedBitvec.with_name(outregsym, width)
            output_regs[regname] = GadgetOutputSymbol(outregsym, bv)
            smt_parser.cache.bind(bv.value.symbol_name(), bv.value)
            smt_parser.cache.bind(bv.taint.symbol_name(), bv.taint)

        # create output flags symbols and add them to parser cache
        output_flags: Dict[str, GadgetOutputSymbol[TaintedBool]] = dict()
        for flagname, outflagsym in outputs_dict["flags"].items():
            b = TaintedBool.with_name(outflagsym)
            output_flags[flagname] = GadgetOutputSymbol(outflagsym, b)
            smt_parser.cache.bind(b.value.symbol_name(), b.value)
            smt_parser.cache.bind(b.taint.symbol_name(), b.taint)

        # create output memory symbols and add them to parser cache
        outmem = TaintedMemory.with_name(
            arch.endian, arch.pointer_width, outputs_dict["memory"])
        output_mem: GadgetOutputSymbol[TaintedMemory] = GadgetOutputSymbol(
            outputs_dict["memory"], outmem)
        smt_parser.cache.bind(outmem.content.symbol_name(), outmem.content)
        smt_parser.cache.bind(outmem.taints.symbol_name(), outmem.taints)

        # build outputs struct
        outputs = GadgetOutputSymbols(output_regs, output_flags, output_mem)

        # build memory predicates structure and add symbols to parser cache
        mem_predicates = UninterpretedMemoryPredicates.with_name(
            arch.pointer_width, predicates_dict["is_range_readable_symbol"], predicates_dict["is_range_writable_symbol"])
        smt_parser.cache.bind(
            predicates_dict["is_range_readable_symbol"], mem_predicates.is_range_readable_symbol)
        smt_parser.cache.bind(
            predicates_dict["is_range_writable_symbol"], mem_predicates.is_range_writable_symbol)

        # parse formula
        sio = StringIO(formula_smtlib)
        tokens = Tokenizer(sio)
        formula = smt_parser.get_expression(tokens)
        if formula is None:
            formula = smt_parser.atom(
                formula_smtlib, smt_parser.env.formula_manager)
        assert isinstance(formula, fnode.FNode)

        has_mem_store_operations = d["has_store_operation"]

        return JSONGadget(arch, assembly, mem_predicates, inputs, outputs, formula, has_mem_store_operations)

    @staticmethod
    def from_json_str(arch: ArchInfo, s: str) -> JSONGadget:
        d = json.loads(s)
        return JSONGadget.from_json_dict(arch, d)

    def to_json_dict(self) -> Dict[Any, Any]:
        input_regs = dict(map(lambda reg: (reg[0],
                                           reg[1].prefix), self.inputs.registers.items()))
        input_flags = dict(map(lambda flag: (flag[0],
                                             flag[1].prefix), self.inputs.flags.items()))
        input_mem = self.inputs.memory.prefix

        inputs: Dict[str, Dict[str, str] | str] = dict()
        inputs["registers"] = input_regs
        inputs["flags"] = input_flags
        inputs["memory"] = input_mem

        output_regs = dict(map(lambda reg: (reg[0],
                                            reg[1].symbol), self.outputs.registers.items()))
        output_flags = dict(map(lambda flag: (flag[0],
                                              flag[1].symbol), self.outputs.flags.items()))
        output_mem = self.outputs.memory.symbol

        outputs: Dict[str, Dict[str, str] | str] = dict()
        outputs["registers"] = output_regs
        outputs["flags"] = output_flags
        outputs["memory"] = output_mem

        predicates = {"address_width": self.memory_predicates.address_width, "is_range_readable_symbol":
                      self.memory_predicates.is_range_readable_symbol.symbol_name(), "is_range_writable_symbol": self.memory_predicates.is_range_writable_symbol.symbol_name()}

        d: Dict[str, Any] = dict()
        d["assembly"] = self.assembly
        d["memory_predicates"] = predicates
        d["inputs"] = inputs
        d["outputs"] = outputs
        d["formula"] = to_smtlib(self.formula)
        d["has_store_operation"] = self.has_store_operation

        return d

    def to_json_str(self) -> str:
        d = self.to_json_dict()
        return json.dumps(d)

    @final
    def _build_substitutions(self, input_state: State, output_state: State) -> Dict[fnode.FNode, fnode.FNode]:
        substitution_rules = dict()
        for name, inregsym in self.inputs.registers.items():
            tbv = inregsym.var
            substitution_rules[tbv.value] = input_state.registers[name].value
            substitution_rules[tbv.taint] = input_state.registers[name].taint

        for name, outregsym in self.outputs.registers.items():
            tbv = outregsym.var
            substitution_rules[tbv.value] = output_state.registers[name].value
            substitution_rules[tbv.taint] = output_state.registers[name].taint

        for name, inflagsym in self.inputs.flags.items():
            tbool = inflagsym.var
            substitution_rules[tbool.value] = input_state.flags[name].value
            substitution_rules[tbool.taint] = input_state.flags[name].taint

        for name, outflagsym in self.outputs.flags.items():
            tbool = outflagsym.var
            substitution_rules[tbool.value] = output_state.flags[name].value
            substitution_rules[tbool.taint] = output_state.flags[name].taint

        substitution_rules[self.inputs.memory.var.content] = input_state.memory.content
        substitution_rules[self.inputs.memory.var.taints] = input_state.memory.taints

        substitution_rules[self.outputs.memory.var.content] = output_state.memory.content
        substitution_rules[self.outputs.memory.var.taints] = output_state.memory.taints

        return substitution_rules

    @final
    def _build_memory_predicates_interpretations(self, memory_layout: MemoryLayout) -> fnode.FNode:
        address_symbol = FreshSymbol(BVType(self.arch.pointer_width))
        size_symbol = FreshSymbol(BVType(self.arch.pointer_width))
        is_readable_interpretation = FunctionInterpretation(
            [address_symbol, size_symbol], memory_layout.assert_range_readable(address_symbol, size_symbol))
        is_writable_interpretation = FunctionInterpretation(
            [address_symbol, size_symbol], memory_layout.assert_range_writable(address_symbol, size_symbol))

        interpretations = {self.memory_predicates.is_range_readable_symbol: is_readable_interpretation,
                           self.memory_predicates.is_range_writable_symbol: is_writable_interpretation}

        return interpretations

    @final
    def build_formula(self, input: State, output: State, mem_layout: MemoryLayout) -> fnode.FNode:
        substitutions = self._build_substitutions(input, output)
        interpretations = self._build_memory_predicates_interpretations(
            mem_layout)

        formulae = [self.formula.substitute(
            substitutions, interpretations).simplify()]

        # build equality formulae for all registers that are not modified by the gadget
        # i.e. that are not present in self.output.registers and whose equality is not enforced by 'self.formula'
        for regname in filter(lambda regname: regname not in self.outputs.registers, output.registers.keys()):
            in_reg = input.registers[regname]
            out_reg = output.registers[regname]
            formulae.append(out_reg.Equals(in_reg))

        # build equality formulae for all flags that are not modified by the gadget
        # i.e. that are not present in self.output.flags and whose equality is not enforced by 'self.formula'
        for flagname in filter(lambda flagname: flagname not in self.outputs.flags, output.flags.keys()):
            in_flag = input.flags[flagname]
            out_flag = output.flags[flagname]
            formulae.append(out_flag.Equals(in_flag))

        return And(formulae).simplify()

    @final
    def connect(self, input: State, output: State, mem_layout: MemoryLayout) -> fnode.FNode:
        formula = self.build_formula(input, output, mem_layout)
        return formula

    @final
    @property
    def assembly_str(self) -> str:
        return self.assembly

    @final
    @property
    def has_store_operation(self) -> bool:
        return self._has_store_operation

    @final
    @cached_property
    def used_regs(self) -> Set[str]:
        regs: Set[str] = set()
        regs.update(self.inputs.registers.keys())
        regs.update(self.outputs.registers.keys())
        return regs


T = TypeVar("T")


@dataclass(frozen=True)
class GadgetInputSymbol(Generic[T]):
    prefix: str
    var: T


@dataclass(frozen=True)
class GadgetOutputSymbol(Generic[T]):
    symbol: str
    var: T


@dataclass(frozen=True)
class GadgetInputSymbols:
    registers: Dict[str, GadgetInputSymbol[TaintedBitvec]]
    flags: Dict[str, GadgetInputSymbol[TaintedBool]]
    memory: GadgetInputSymbol[TaintedMemory]


@dataclass(frozen=True)
class GadgetOutputSymbols:
    registers: Dict[str, GadgetOutputSymbol[TaintedBitvec]]
    flags: Dict[str, GadgetOutputSymbol[TaintedBool]]
    memory: GadgetOutputSymbol[TaintedMemory]


@dataclass(frozen=True)
class UninterpretedMemoryPredicates:
    address_width: int
    is_range_readable_symbol: fnode.FNode
    is_range_writable_symbol: fnode.FNode

    @classmethod
    def with_name(cls, address_width: int, is_range_readable_name: str, is_range_writable_name: str) -> Self:
        bv_type = BVType(address_width)
        is_valid_range_function_type = FunctionType(BOOL, [bv_type, bv_type])
        is_range_readable = Symbol(is_range_readable_name,
                                   is_valid_range_function_type)
        is_range_writable = Symbol(is_range_writable_name,
                                   is_valid_range_function_type)

        return cls(address_width, is_range_readable, is_range_writable)

    @classmethod
    def new_fresh(cls, address_width: int) -> Self:
        bv_type = BVType(address_width)
        is_valid_range_function_type = FunctionType(BOOL, [bv_type, bv_type])
        is_range_readable = FreshSymbol(
            is_valid_range_function_type, 'is_range_readable%d')
        is_range_writable = FreshSymbol(
            is_valid_range_function_type, 'is_range_writable%d')

        return cls(address_width, is_range_readable, is_range_writable)
