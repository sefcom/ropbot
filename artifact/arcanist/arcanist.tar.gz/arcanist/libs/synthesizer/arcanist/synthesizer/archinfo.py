from arcanist.architecture import Endian

from .memory import TaintedMemory
from .tainted_types.bitvec import TaintedBitvec
from .tainted_types.bool import TaintedBool

from typing import Callable
from dataclasses import dataclass
from collections import OrderedDict


@dataclass(frozen=True)
class RegInfo:
    name: str
    width: int

    def symbol(self, prefix: str) -> TaintedBitvec:
        return TaintedBitvec.with_name(f"{prefix}_{self.name}", self.width)


@dataclass(frozen=True)
class FlagInfo:
    name: str

    def symbol(self, prefix: str) -> TaintedBool:
        return TaintedBool.with_name(f"{prefix}_{self.name}")


@dataclass(frozen=True)
class ArchInfo:
    endian: Endian
    pointer_width: int
    registers_info: OrderedDict[str, RegInfo]
    flags_info: OrderedDict[str, FlagInfo]
    program_counter: str

    def register_symbols(self, prefix: str, f: Callable[[RegInfo], bool] | None = None) -> OrderedDict[str, TaintedBitvec]:
        reg_values = self.registers_info.values()
        reg_iter = reg_values if f is None else filter(f, reg_values)
        return OrderedDict([(reg.name, reg.symbol(prefix)) for reg in reg_iter])

    def flag_symbols(self, prefix: str, f: Callable[[FlagInfo], bool] | None = None) -> OrderedDict[str, TaintedBool]:
        flag_values = self.flags_info.values()
        flag_iter = flag_values if f is None else filter(f, flag_values)
        return OrderedDict([(flag.name, flag.symbol(prefix)) for flag in flag_iter])

    def memory_symbol(self, prefix: str) -> TaintedMemory:
        return TaintedMemory.with_name(self.endian, self.pointer_width, prefix + "_memory")
