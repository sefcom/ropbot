from abc import ABC, abstractmethod
from typing import List, Optional
from dataclasses import dataclass

from arcanist.architecture import Architecture


@dataclass(frozen=True)
class RawGadget:
    assembly_string: str
    address: int
    raw_bytes: bytes
    instruction_count: int


@dataclass(frozen=True)
class RawGadgetLibrary:
    architecture: Architecture
    gadgets: List[RawGadget]


class UnsupportedArchitectureError(Exception):
    pass  # TODO: implement?


class UnknownArchitectureError(Exception):
    pass  # TODO: implement?


class GadgetExtractor(ABC):
    @abstractmethod
    def extract_from_elf(self, path: str, base: Optional[int] = None, arch: Optional[Architecture] = None) -> RawGadgetLibrary:
        raise NotImplementedError()

    @abstractmethod
    def extract_from_raw(self, path: str, arch: Architecture, base: Optional[int] = None) -> RawGadgetLibrary:
        raise NotImplementedError()
