class RegNotFoundException(Exception):
    pass


class RopException(Exception):
    pass


class RopTimeoutException(RopException):
    pass
