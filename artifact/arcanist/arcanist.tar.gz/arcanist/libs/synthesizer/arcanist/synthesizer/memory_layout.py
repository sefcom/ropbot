from dataclasses import dataclass, field
from typing import List

from pysmt import fnode
from pysmt.shortcuts import Or


@dataclass(frozen=True)
class MemoryRegion:
    start: int
    end: int
    is_readable: bool = field(kw_only=True)
    is_writable: bool = field(kw_only=True)
    name: str | None = None

    def assert_range_included(self, start: fnode.FNode, size: fnode.FNode | int) -> fnode.FNode:
        return (self.start <= start) & (start <= self.end + 1 - size)


@dataclass(init=False)
class MemoryLayout:
    _regions: List[MemoryRegion]

    def __init__(self) -> None:
        self._regions = []

    def add_region(self, start: int, end: int, *, readable: bool, writable: bool, name: str | None = None) -> None:
        assert start <= end
        self._regions.append(MemoryRegion(
            start, end, is_readable=readable, is_writable=writable, name=name))

    def assert_range_readable(self, start: fnode.FNode, byte_size: fnode.FNode | int) -> fnode.FNode:
        possibilities = [
            region.assert_range_included(start, byte_size)
            for region in self._regions if region.is_readable
        ]

        return Or(possibilities)

    def assert_range_writable(self, start: fnode.FNode, byte_size: fnode.FNode | int) -> fnode.FNode:
        possibilities = [
            region.assert_range_included(start, byte_size)
            for region in self._regions if region.is_writable
        ]

        return Or(possibilities)
