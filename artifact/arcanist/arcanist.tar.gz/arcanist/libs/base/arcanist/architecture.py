from enum import StrEnum


class Architecture(StrEnum):
    x86 = 'x86'
    x86_64 = 'x86_64'
    ARMv7 = 'armv7'
    ARMv7_THUMB = 'armv7-thumb'
    AARCH64 = 'aarch64'


class Endian(StrEnum):
    Little = 'little'
    Big = 'big'
