from __future__ import annotations
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Dict, Self
from pysmt import fnode
from pysmt.exceptions import PysmtTypeError

from arcanist.synthesizer.smt.printer import to_smtlib

if TYPE_CHECKING:
    from .bool import TaintedBool


class SingleTaintValue(ABC):
    def __init__(self, value: fnode.FNode, taint: fnode.FNode):
        if not isinstance(value, fnode.FNode):
            raise TypeError(
                f"Expected 'FNode' as 'value' for constructing {self.__class__.__name__}, got '{type(value).__name__}' instead")
        if not isinstance(taint, fnode.FNode):
            raise TypeError(
                f"Expected 'FNode' as 'taint' for constructing {self.__class__.__name__}, got '{type(taint).__name__}' instead")
        if not taint.get_type().is_bool_type():
            raise PysmtTypeError(
                f"Expected symbol type of 'taint' to be 'BOOL' for construting {self.__class__.__name__}, got '{taint.get_type()}' instead")
        self._value = value
        self._taint = taint

    def __eq__(self, other: object) -> bool:
        if isinstance(other, SingleTaintValue):
            return self.value == other.value and self.taint == other.taint
        return False

    def to_json_dict(self) -> Dict[str, str]:
        return {"value": to_smtlib(self.value), "taint": to_smtlib(self.taint)}

    @property
    def value(self) -> fnode.FNode:
        return self._value

    @property
    def taint(self) -> fnode.FNode:
        return self._taint

    @abstractmethod
    def tainted_equals(self, other: Self) -> 'TaintedBool':
        raise NotImplementedError()

    def _substitute_rules(self, other: Self) -> Dict[fnode.FNode, fnode.FNode]:
        return {self.value: other.value, self.taint: other.taint}
