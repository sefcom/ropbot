from __future__ import annotations
from arcanist.synthesizer.smt.printer import ArcanistSMTPrinter
from pysmt import fnode
from pysmt.exceptions import PysmtTypeError

from arcanist.synthesizer.smt.printer import to_smtlib

from typing import Self, Dict


class TaintedArray:
    def __init__(self, content: fnode.FNode, taints: fnode.FNode):
        if not isinstance(content, fnode.FNode):
            raise TypeError(
                f"Expected 'FNode' as 'content' for constructing {self.__class__.__name__}, got '{type(content).__name__}' instead")
        if not isinstance(taints, fnode.FNode):
            raise TypeError(
                f"Expected 'FNode' as 'taints' for constructing {self.__class__.__name__}, got '{type(taints).__name__}' instead")
        if not content.get_type().is_array_type():
            raise PysmtTypeError(
                f"Expected SMT type of 'content' to be 'Array' for constructing {self.__class__.__name__}, got '{content.get_type()}' instead ")
        if not taints.get_type().is_array_type():
            raise PysmtTypeError(
                f"Expected SMT type of 'taints' to be 'Array' for constructing {self.__class__.__name__}, got '{taints.get_type()}' instead ")
        if not taints.get_type().elem_type.is_bool_type():
            raise PysmtTypeError(
                f"Expected SMT type of elements in 'taints' to be 'Bool' for constructing {self.__class__.__name__}, got '{taints.get_type().elem_type}' instead ")
        if taints.get_type().index_type != content.get_type().index_type:
            raise PysmtTypeError(
                f"Expected SMT type of indices in 'content' and 'taints' to be the same for constructing {self.__class__.__name__}, got '{content.get_type().index_type}' and '{taints.get_type().index_type}' instead ")
        self._content = content
        self._taints = taints

    def to_json_dict(self):
        return {"content": to_smtlib(self.content), "taints": to_smtlib(self.taints)}

    def __eq__(self, other: object) -> bool:
        if isinstance(other, TaintedArray):
            return self.content == other.content and self.taints == other.taints
        return False

    @property
    def content(self) -> fnode.FNode:
        return self._content

    @property
    def taints(self) -> fnode.FNode:
        return self._taints

    def _substitute_rules(self, other: Self) -> Dict[fnode.FNode, fnode.FNode]:
        return {self.content: other.content, self.taints: other.taints}

    def Equals(self, other: Self) -> fnode.FNode:
        return self.content.Equals(other.content) & self.taints.Equals(other.taints)
