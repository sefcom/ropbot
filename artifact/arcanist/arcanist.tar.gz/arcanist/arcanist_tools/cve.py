import time
import sys
import argparse
import json
import multiprocessing
from multiprocessing import Queue
from multiprocessing.synchronize import Barrier, Event
import threading
from threading import Thread
import psutil
import queue

import random
from arcanist.synthesizer.memory_layout import MemoryLayout
from arcanist.synthesizer.state import State
from arcanist.synthesizer.state_builder import OnlyUsedRegisterStateBuilder
from arcanist.synthesizer.synthesis import Assumptions, IncrementalSynthesizer, SimpleAssumptionFunction, SimpleSpecificationFunction, Specifications, SynthesizedChain
from arcanist.synthesizer.tainted_types.bitvec import TaintedBitvec
from arcanist.synthesizer.tainted_types.bool import TaintedBool
from pysmt.shortcuts import Solver, BV
from typing import Any, Dict, List, Callable
from timeit import default_timer as timer

from pysmt import fnode
from pysmt.shortcuts import And, TRUE

from arcanist.synthesizer.gadget import GadgetBase, GadgetLibrary, JSONGadget

import logging
logging.basicConfig(level=logging.NOTSET,
                    format="[%(levelname)s] (%(name)s) %(message)s")
LOGGER = logging.getLogger('arcanist-cve-synthesis')


# def random_gadgets(gadgets: List[JSONGadget], size: int, proportion_mem_store: float) -> List[JSONGadget]:
#     # l = list(filter(
#     #     lambda g: g.assembly_str.startswith('pop {r4, r5, pc}') or g.assembly_str.startswith('pop.w {r3, r4, r5, r6, r7, r8, sb, pc}') or 'mov sp' in g.assembly_str, gadgets))
#     # for g in l:
#     #     LOGGER.info(f"{g.assembly_str}")
#     #     LOGGER.info(g.formula.to_smtlib())
#     # return l
#     with_mem_stores = list(
#         # and g.formula.to_smtlib().count('store') <= 16
#         filter(lambda g: g.has_store_operation, gadgets))
#     without_mem_stores = list(filter(
#         lambda g: not g.has_store_operation, gadgets))
#     with_count = min(len(with_mem_stores), int(size * proportion_mem_store))
#     without_count = size - with_count
#     return random.sample(population=without_mem_stores, k=without_count) + random.sample(population=with_mem_stores, k=with_count)

def _get_rare_gadgets(gadgets: List[dict]) -> List[dict]:
    rare_patterns = ["xchg rsp", "xchg esp",
                     "mov rsp", "mov esp", "mov sp", "movs sp"]

    def _is_rare(gadget: dict) -> bool:
        asm: str = gadget['assembly']
        return any(map(lambda pattern: pattern in asm, rare_patterns))
    return list(filter(_is_rare, gadgets))


def _get_r9_gadgets(gadgets: List[dict]) -> List[dict]:
    patterns = ["xchg r9", "mov r9"]

    def _is_set_r9(gadget: dict) -> bool:
        asm: str = gadget['assembly']
        return any(map(lambda pattern: pattern in asm, patterns))
    return list(filter(_is_set_r9, gadgets))


def random_gadgets_json(gadgets: List[dict], size: int, proportion_mem_store: float, balance_jop_rop: bool, force_rare_gadgets: bool, force_r9_gadgets: bool) -> List[dict]:
    selected_gadgets = []

    if force_r9_gadgets:
        r9_gadgets = _get_r9_gadgets(gadgets)
        num = min(len(r9_gadgets), int(size*0.1))
        selected_gadgets += random.sample(population=r9_gadgets, k=num)

    if force_rare_gadgets:
        rare_gadgets = _get_rare_gadgets(gadgets)
        num = min(len(rare_gadgets), int(size*0.1))
        selected_gadgets += random.sample(population=rare_gadgets, k=num)
        size -= num

    if balance_jop_rop:
        def is_jop(g: dict) -> bool:
            last_inst = g['assembly'].split(";")[-2]
            return last_inst.startswith(" call") or last_inst.startswith(" jmp") or last_inst.startswith(" blx") or last_inst.startswith(" bx")
        jop_gadgets = list(filter(is_jop, gadgets))
        rop_gadgets = list(filter(lambda g: not is_jop(g), gadgets))
        with_mem_stores_jop = list(
            filter(lambda g: g['has_store_operation'], jop_gadgets))
        without_mem_stores_jop = list(
            filter(lambda g: not g['has_store_operation'], jop_gadgets))
        with_mem_stores_rop = list(
            filter(lambda g: g['has_store_operation'], rop_gadgets))
        without_mem_stores_rop = list(
            filter(lambda g: not g['has_store_operation'], rop_gadgets))

        jop_count = min(size // 2, len(jop_gadgets))
        rop_count = min(size - jop_count, len(rop_gadgets))
        with_jop_count = min(len(with_mem_stores_jop),
                             int(jop_count * proportion_mem_store))
        without_jop_count = min(
            jop_count - with_jop_count, len(without_mem_stores_jop))
        with_rop_count = min(len(with_mem_stores_rop),
                             int(rop_count * proportion_mem_store))
        without_rop_count = min(
            rop_count - with_rop_count, len(with_mem_stores_rop))

        selected_gadgets += random.sample(population=without_mem_stores_jop, k=without_jop_count) + random.sample(population=with_mem_stores_jop, k=with_jop_count) + \
            random.sample(population=without_mem_stores_rop, k=without_rop_count) + \
            random.sample(population=with_mem_stores_rop, k=with_rop_count)
    else:
        with_mem_stores = list(
            filter(lambda g: g['has_store_operation'], gadgets))
        without_mem_stores = list(filter(
            lambda g: not g['has_store_operation'], gadgets))
        with_count = min(len(with_mem_stores), int(
            size * proportion_mem_store))
        without_count = size - with_count
        selected_gadgets += random.sample(population=without_mem_stores, k=without_count) + \
            random.sample(population=with_mem_stores, k=with_count)

    return selected_gadgets


def get_synthesis_function(args: Any) -> None:
    if args.strategy == 'incremental':
        return incremental_solving
    elif args.strategy == 'one-shot':
        return one_shot_solving

    raise ValueError(f"unknown strategy {args.strategy}")


def initialize_worker(init_barrier: Barrier, seed_queue: Queue, mem_store_proportion_queue: Queue, args: Any, mem_layout: MemoryLayout, assumptions: Assumptions, specifications: Specifications) -> None:
    seed = seed_queue.get()
    random.seed(seed)

    LOGGER.info("Loading gadgets...")
    with open(args.gadgets, "r") as f:
        # library = GadgetLibrary.from_json_str(f.read())
        library_json = json.loads(f.read())
    # LOGGER.info(f"Loaded {len(library.gadgets)} gadgets")

    mem_store_proportion = mem_store_proportion_queue.get()
    LOGGER.info(
        f"Selecting {args.library_size} gadgets with {mem_store_proportion*100}% of memory stores...")
    # gadgets = random_gadgets(
    #     library.gadgets, args.library_size, mem_store_proportion)

    force_r9_gadgets = args.force_r9_gadgets if args.assumptions == 'CVE-2021-35211' else False

    gadgets_json = random_gadgets_json(
        library_json['gadgets'], args.library_size, mem_store_proportion, args.balance_rop_jop_gadgets, args.force_rare_gadgets, force_r9_gadgets)

    library_json['gadgets'] = gadgets_json
    library = GadgetLibrary.from_json_dict(library_json)

    LOGGER.info(f"Loaded {len(library.gadgets)} gadgets")

    init_barrier.wait()

    return (args, library.arch_info, library.gadgets, mem_store_proportion, mem_layout, assumptions, specifications)


def one_shot_solving() -> Any:
    raise NotImplementedError


def incremental_solving(idx: int, result_queue: Queue, start_event: Event, **kwargs) -> None:
    args, arch_info, gadgets, mem_store_proportion, mem_layout, assumptions, specifications = initialize_worker(
        **kwargs)
    start_event.wait()

    solver_options = {}
    # if mem_store_proportion > 0:
    #     solver_options['fun-store-lambdas'] = 1
    #     solver_options['beta-reduce'] = 1
    solver = Solver(logic='QF_AUFBV*', name='btor',
                    solver_options=solver_options)
    synthesizer = IncrementalSynthesizer(
        solver, arch_info, gadgets, OnlyUsedRegisterStateBuilder)

    try:
        chain = synthesizer.synthesize(
            args.max_length, mem_layout, assumptions, specifications)
    except Exception as e:
        LOGGER.warning(e)
        chain = None

    result_queue.put((idx, timer(), chain))
    return


def make_optee_cve_2022_46152_memory_layout(args: Any) -> MemoryLayout:
    mem_layout = MemoryLayout()
    mem_layout.add_region(0x8F700000, 0x8F700FFF, readable=True,
                          writable=False, name="shared-mem-buffer")
    mem_layout.add_region(
        0x8db5eac8, 0x8db5eaff, readable=True, writable=False, name="thread-stack-ro")
    return mem_layout


def make_vlc_cve_2018_11529_memory_layout(args: Any) -> MemoryLayout:
    mem_layout = MemoryLayout()
    # ecx is in a valid memory region, but no info on this so we dedicate a full region to it
    mem_layout.add_region(0x001E0000, 0x001EFFFF,
                          readable=True, writable=True, name="ecx-buffer")
    # buffer where the corrupted object is located, don't have exact address
    mem_layout.add_region(0x001D0000, 0x001D007F, readable=True,
                          writable=False, name="corrupted-object")
    # stack region, don't have exact address
    mem_layout.add_region(0x41000000, 0x41FFFFFF,
                          readable=True, writable=False, name="stack")
    return mem_layout


def make_solarwinds_cve_2021_35211_memory_layout(args: Any) -> MemoryLayout:
    mem_layout = MemoryLayout()
    mem_layout.add_region(0x0000000d09000000, 0x0000000d09ffffff,
                          readable=True, writable=False, name="stack")
    # give it a little more working space if we are trying to do func-call-4args
    controlled_size = 0x100 if args.goal == "func-call-4args" else 0x80
    mem_layout.add_region(0x000001ed4d5a40fa, 0x000001ed4d5a40fa +
                          controlled_size-1, readable=True, writable=False, name="controlled-buffer")
    return mem_layout


def make_foxit_cve_2018_9958_memory_layout(args: Any) -> MemoryLayout:
    mem_layout = MemoryLayout()
    mem_layout.add_region(0x00120000, 0x0012ffff,
                          readable=True, writable=False, name="stack")
    mem_layout.add_region(0x00733498, 0x00733498+0x3F,
                          readable=True, writable=False, name="corrupted-vtable")
    return mem_layout


def make_wd_pr4100_memory_layout(args: Any) -> MemoryLayout:
    mem_layout = MemoryLayout()
    mem_layout.add_region(0x7fffd04e0000, 0x7fffd04effff,
                          readable=True, writable=False, name="stack")
    return mem_layout


def make_ffmpeg_cve_2016_10190_memory_layout(args: Any) -> MemoryLayout:
    mem_layout = MemoryLayout()
    mem_layout.add_region(0x7fffffff0000, 0x7fffffffffff,
                          readable=True, writable=True, name="stack")
    mem_layout.add_region(0x1de6b80+0x8060, 0x1de6b80+0x8060+0xFF,
                          readable=True, writable=False, name="corrupted-object")
    return mem_layout


def make_r_edb_id_47122_memory_layout(args: Any) -> MemoryLayout:
    mem_layout = MemoryLayout()
    # don't have exact address
    mem_layout.add_region(0x41000000, 0x4100FFFF,
                          readable=True, writable=False, name="stack")
    return mem_layout


def make_routeros_cve_2023_30799_x86_memory_layout(args: Any) -> MemoryLayout:
    mem_layout = MemoryLayout()
    # don't have exact address
    mem_layout.add_region(0x41000000, 0x4100FFFF,
                          readable=True, writable=False, name="stack")
    return mem_layout


def make_routeros_cve_2023_30799_arm_memory_layout(args: Any) -> MemoryLayout:
    mem_layout = MemoryLayout()
    # don't have exact address
    mem_layout.add_region(0x41000000, 0x4100FFFF,
                          readable=True, writable=False, name="stack")
    return mem_layout


def make_optee_cve_2019_1010298_memory_layout(args: Any) -> MemoryLayout:
    mem_layout = MemoryLayout()
    mem_layout.add_region(0x8dc74c20, 0x8dc74c20+0x7F,
                          readable=True, writable=False, name="corrupted-mobj")
    return mem_layout


memory_layout_makers: Dict[str, Callable[[Any], MemoryLayout]] = {
    "CVE-2019-1010298": make_optee_cve_2019_1010298_memory_layout,
    "CVE-2023-30799_arm": make_routeros_cve_2023_30799_arm_memory_layout,
    "CVE-2023-30799_x86": make_routeros_cve_2023_30799_x86_memory_layout,
    "EDB-ID-47122": make_r_edb_id_47122_memory_layout,
    "CVE-2016-10190": make_ffmpeg_cve_2016_10190_memory_layout,
    "WD-PR4100-NAS": make_wd_pr4100_memory_layout,
    "CVE-2018-9958": make_foxit_cve_2018_9958_memory_layout,
    "CVE-2021-35211": make_solarwinds_cve_2021_35211_memory_layout,
    "CVE-2018-11529": make_vlc_cve_2018_11529_memory_layout,
    "CVE-2022-46152": make_optee_cve_2022_46152_memory_layout,
}


def make_memory_layout(args: Any) -> MemoryLayout:
    return memory_layout_makers[args.assumptions](args)


def make_goal_assumptions(args: Any) -> Assumptions:
    is_stack_goal = args.goal.startswith("stack")
    is_heap_goal = not is_stack_goal
    valid_stack_region = 0x7ffffffde180
    controlled_buffer = 0x7ffffffde000 if is_stack_goal else 0x7ffffff80000
    controlled_size = 0x80 if is_stack_goal else 0x200

    is_pivot_goal = 'stack-pivot' in args.goal
    pivot_buffer = 0x7ffffff40000
    pivot_buffer_size = 0x80

    def is_in_controlled_buffer(val: fnode.FNode) -> fnode.FNode:
        in_controlled_buffer = And(
            [val >= controlled_buffer, val < controlled_buffer+controlled_size])
        return in_controlled_buffer

    def _assumptions(input_state: State) -> fnode.FNode:
        memory = input_state.memory.clone_untainted().taint_range(
            controlled_buffer, controlled_size)

        # only use this pivot buffer for stack goal
        # in heap goal pivot buffer is the controlled buffer
        if is_pivot_goal and is_stack_goal:
            # say that the pivot buffer is controlled
            memory = memory.taint_range(pivot_buffer, pivot_buffer_size)

        memory_assertions = input_state.memory.Equals(memory)
        assertions = [memory_assertions]
        for regname, reg in input_state.registers.items():
            if regname == 'rip':
                assertions.append(reg.taint)
            elif (is_heap_goal and regname == 'rsp'):
                # put stack in a valid region to ensure validity of 'call' instruction (push to stack)
                assertions.append(reg.Equals(
                    TaintedBitvec.from_int(valid_stack_region, reg.bv_width)))
            elif (is_heap_goal and regname == 'rbp'):
                # put rbp in a valid region to ensure validity of rbp-based memory loads
                assertions.append(reg.Equals(
                    TaintedBitvec.from_int(valid_stack_region + 8, reg.bv_width)))
            elif (is_heap_goal and regname == args.reg):
                assertions.append(is_in_controlled_buffer(reg.value))
                assertions.append(reg.taint)
            elif (is_stack_goal and regname == 'rsp'):
                assertions.append(reg.Equals(
                    TaintedBitvec.from_int(controlled_buffer, reg.bv_width)))
            else:
                assertions.append(reg.Equals(
                    TaintedBitvec.new_zero_untainted(reg.bv_width)))

        for flag in input_state.flags.values():
            assertions.append(flag.Equals(TaintedBool.new_false_untainted()))

        assumptions = And(assertions)
        return assumptions

    return SimpleAssumptionFunction(_assumptions)


def make_optee_cve_2022_46152_assumptions(args: Any) -> Assumptions:
    def _assumptions(input_state: State) -> fnode.FNode:
        assertions = []
        # consider these uncontrolled because their values are too constrained
        # a0 = TaintedBitvec.with_name("a0", 32)
        # a1 = TaintedBitvec.with_name("a1", 32)
        # a2 = TaintedBitvec.with_name("a2", 32)

        a3 = TaintedBitvec.with_name("a3", 32)
        assertions.append(a3.taint)
        a4 = TaintedBitvec.with_name("a4", 32)
        assertions.append(a4.taint)
        a5 = TaintedBitvec.with_name("a5", 32)
        assertions.append(a5.taint)
        a6 = TaintedBitvec.with_name("a6", 32)
        assertions.append(a6.taint)
        a7 = TaintedBitvec.with_name("a7", 32)
        assertions.append(a7.taint)

        memory = input_state.memory.clone_untainted()
        # taint the pivot buffer (shared memory)
        memory = memory.taint_range(0x8F700000, 0x20)
        # give constraints on thread stack layout (controlled vs uncontrolled, args layout)
        memory = memory \
            .write_at(BV(0x8db5eac8, 32), a3) \
            .write_at(BV(0x8db5eacc, 32), a4) \
            .write_at(BV(0x8db5ead0, 32), a5) \
            .write_at(BV(0x8db5eae4, 32), a3) \
            .write_at(BV(0x8db5eae8, 32), a4) \
            .write_at(BV(0x8db5eaec, 32), a5) \
            .write_at(BV(0x8db5eaf0, 32), a6) \
            .write_at(BV(0x8db5eaf4, 32), a7)

        memory_assertions = input_state.memory.Equals(memory)
        assertions.append(memory_assertions)

        for regname, reg in input_state.registers.items():
            # overwritten pc using arb decrement
            if regname == "pc":
                assertions.append(reg.taint)
                assertions.append(reg.value < 0x8DB028CF)
            elif regname == "sp":
                assertions.append(reg.taint)
                assertions.append(reg.value.Equals(0x8db5eac8))
            else:
                assertions.append(reg.Equals(
                    TaintedBitvec.new_zero_untainted(reg.bv_width)))

        for flag in input_state.flags.values():
            assertions.append(flag.Equals(TaintedBool.new_false_untainted()))

        assumptions = And(assertions)
        return assumptions

    return SimpleAssumptionFunction(_assumptions)


def make_vlc_cve_2018_11529_assumptions(args: Any) -> Assumptions:
    def _assumptions(input_state: State) -> fnode.FNode:
        assertions = []

        overwritten_eip = TaintedBitvec.with_name("overwritten_eip", 32)
        assertions.append(overwritten_eip.taint)

        memory = input_state.memory.clone_untainted()
        memory = memory.taint_range(0x001D0000, 0x80)

        memory.write_at(BV(0x001D0000, 32), overwritten_eip)

        memory_assertions = input_state.memory.Equals(memory)
        assertions.append(memory_assertions)

        for regname, reg in input_state.registers.items():
            if regname == "eip":
                # overwritten eip
                assertions.append(reg.Equals(overwritten_eip))
            elif regname == "esp":
                # esp is in stack region
                assertions.append(reg.taint)
                assertions.append(reg.value >= 0x41000000)
                assertions.append(reg.value < 0x42000000)
            elif regname == "ecx":
                # ecx is in valid memory region
                assertions.append(reg.taint)
                assertions.append(reg.value.Equals(0x1E0040))
            elif regname == "eax":
                # eax points to the corrupted object
                assertions.append(reg.taint)
                assertions.append(reg.value.Equals(0x1D0004))
            else:
                assertions.append(reg.Equals(
                    TaintedBitvec.new_zero_untainted(reg.bv_width)))

        for flag in input_state.flags.values():
            assertions.append(flag.Equals(TaintedBool.new_false_untainted()))

        assumptions = And(assertions)
        return assumptions
    return SimpleAssumptionFunction(_assumptions)


def make_solarwinds_cve_2021_35211_assumptions(args: Any) -> Assumptions:
    def _assumptions(input_state: State) -> fnode.FNode:
        assertions = []

        overwritten_rip = TaintedBitvec.with_name("overwritten_rip", 64)
        assertions.append(overwritten_rip.taint)

        memory = input_state.memory.clone_untainted()
        # give it a little more working space if we are trying to do func-call-4args
        controlled_size = 0x100 if args.goal == "func-call-4args" else 0x80
        memory = memory.taint_range(0x000001ed4d5a40fa, controlled_size)

        memory_assertions = input_state.memory.Equals(memory)
        assertions.append(memory_assertions)

        for regname, reg in input_state.registers.items():
            if regname == "rip" or regname == "r9":
                # overwritten rip
                assertions.append(reg.Equals(overwritten_rip))
            elif regname == "rsp":
                assertions.append(reg.taint)
                assertions.append(reg.value.Equals(0x0000000d09bfebf0))
            elif regname == "rbp":
                assertions.append(reg.taint)
                assertions.append(reg.value.Equals(0x000001ed4d5a410a))
            elif regname == "r11":
                assertions.append(reg.taint)
                assertions.append(reg.value.Equals(0x000001ed4d5a40fa))
            else:
                assertions.append(reg.Equals(
                    TaintedBitvec.new_zero_untainted(reg.bv_width)))

        for flag in input_state.flags.values():
            assertions.append(flag.Equals(TaintedBool.new_false_untainted()))

        assumptions = And(assertions)
        return assumptions
    return SimpleAssumptionFunction(_assumptions)


def make_foxit_cve_2018_9958_assumptions(args: Any) -> Assumptions:
    def _assumptions(input_state: State) -> fnode.FNode:
        assertions = []

        overwritten_eip = TaintedBitvec.with_name("overwritten_eip", 32)
        assertions.append(overwritten_eip.taint)

        memory = input_state.memory.clone_untainted()
        # corrupted vtable is attacker-controlled
        memory = memory.taint_range(0x00733498, 0x40)

        # offset 8 is the address of the first attacker-controlled jump
        # via: mov edx,dword ptr [eax+8]; ...; call edx
        memory.write_at(BV(0x00733498 + 8, 32), overwritten_eip)

        memory_assertions = input_state.memory.Equals(memory)
        assertions.append(memory_assertions)

        for regname, reg in input_state.registers.items():
            if regname == "eip":
                # overwritten eip
                assertions.append(reg.Equals(overwritten_eip))
            elif regname == "esp":
                # esp is in stack region
                assertions.append(reg.taint)
                assertions.append(reg.value.Equals(0x0012e3cc))
            elif regname == "eax":
                # eax points to the corrupted vtable
                assertions.append(reg.taint)
                assertions.append(reg.value.Equals(0x00733498))
            else:
                assertions.append(reg.Equals(
                    TaintedBitvec.new_zero_untainted(reg.bv_width)))

        for flag in input_state.flags.values():
            assertions.append(flag.Equals(TaintedBool.new_false_untainted()))

        assumptions = And(assertions)
        return assumptions
    return SimpleAssumptionFunction(_assumptions)


def make_wd_pr4100_assumptions(args: Any) -> Assumptions:
    def _assumptions(input_state: State) -> fnode.FNode:
        assertions = []

        overwritten_rip = TaintedBitvec.with_name("overwritten_rip", 64)
        assertions.append(overwritten_rip.taint)

        memory = input_state.memory.clone_untainted()
        # attacker-controlled data are 0x110 bytes away from the actual rsp
        memory = memory.taint_range(0x7fffd04e85b0+0x110, 0x60)

        memory_assertions = input_state.memory.Equals(memory)
        assertions.append(memory_assertions)

        for regname, reg in input_state.registers.items():
            if regname == "rip":
                # overwritten rip
                assertions.append(reg.Equals(overwritten_rip))
            elif regname == "rsp":
                assertions.append(reg.taint)
                assertions.append(reg.value.Equals(0x7fffd04e85b0))
            elif regname in ["rbx", "r12", "r13"]:
                assertions.append(reg.taint)
            else:
                assertions.append(reg.Equals(
                    TaintedBitvec.new_zero_untainted(reg.bv_width)))

        for flag in input_state.flags.values():
            assertions.append(flag.Equals(TaintedBool.new_false_untainted()))

        assumptions = And(assertions)
        return assumptions
    return SimpleAssumptionFunction(_assumptions)


def make_ffmpeg_cve_2016_10190_assumptions(args: Any) -> Assumptions:
    def _assumptions(input_state: State) -> fnode.FNode:
        assertions = []

        overwritten_read_packet = TaintedBitvec.with_name(
            "overwritten_read_packet", 64)
        assertions.append(overwritten_read_packet.taint)

        overwritten_opaque = TaintedBitvec.with_name("overwritten_opaque", 64)
        assertions.append(overwritten_opaque.taint)

        memory = input_state.memory.clone_untainted()
        # attacker-controlled corrupted object
        memory = memory.taint_range(0x1de6b80+0x8060, 0x100)

        # offset of overwritten 'opaque' pointer, passed as first arg to 'read_packet'
        memory.write_at(BV(0x1de6b80+0x8060 + 0x20, 64), overwritten_opaque)
        # offset of overwritten 'read_packet', the location of the first gadget
        memory.write_at(BV(0x1de6b80+0x8060 + 0x28, 64),
                        overwritten_read_packet)
        # offset of 'eof_reached', must be zero for exploit to succeed
        memory.write_at(BV(0x1de6b80+0x8060 + 0x44, 64),
                        TaintedBitvec.from_int(0, 32))

        memory_assertions = input_state.memory.Equals(memory)
        assertions.append(memory_assertions)

        for regname, reg in input_state.registers.items():
            if regname == "rip":
                # overwritten rip
                assertions.append(reg.Equals(overwritten_read_packet))
            elif regname == "rsp":
                assertions.append(reg.taint)
                assertions.append(reg.value.Equals(0x7fffffffda80))
            elif args.with_rbx and regname == "rbx":
                assertions.append(reg.taint)
                assertions.append(reg.Equals(0x1de6b80+0x8060))
            elif regname == "rdi":
                assertions.append(reg.Equals(overwritten_opaque))
            elif regname == "rsi" or (args.with_rbp and regname == "rbp"):
                # actually the second arg passed to 'read_packet' is a pointer
                # that points just after the corrupted object!
                assertions.append(reg.Equals(0x1de6b80+0x8060 + 0xd8))
            else:
                assertions.append(reg.Equals(
                    TaintedBitvec.new_zero_untainted(reg.bv_width)))

        for flag in input_state.flags.values():
            assertions.append(flag.Equals(TaintedBool.new_false_untainted()))

        assumptions = And(assertions)
        return assumptions
    return SimpleAssumptionFunction(_assumptions)


def make_r_edb_id_47122_assumptions(args: Any) -> Assumptions:
    def _assumptions(input_state: State) -> fnode.FNode:
        assertions = []

        overwritten_eip = TaintedBitvec.with_name("overwritten_eip", 32)
        assertions.append(overwritten_eip.taint)

        memory = input_state.memory.clone_untainted()
        # attacker-controlled buffer is 0x7B4 bytes away from esp
        memory = memory.taint_range(0x41001000+0x7b4, 0x600)

        memory_assertions = input_state.memory.Equals(memory)
        assertions.append(memory_assertions)

        for regname, reg in input_state.registers.items():
            if regname == "eip":
                # overwritten eip
                assertions.append(reg.Equals(overwritten_eip))
            elif regname == "esp":
                # esp is in stack region
                assertions.append(reg.taint)
                assertions.append(reg.value.Equals(0x41001000))
            else:
                assertions.append(reg.Equals(
                    TaintedBitvec.new_zero_untainted(reg.bv_width)))

        for flag in input_state.flags.values():
            assertions.append(flag.Equals(TaintedBool.new_false_untainted()))

        assumptions = And(assertions)
        return assumptions
    return SimpleAssumptionFunction(_assumptions)


def make_routeros_cve_2023_30799_x86_assumptions(args: Any) -> Assumptions:
    def _assumptions(input_state: State) -> fnode.FNode:
        assertions = []

        overwritten_eip = TaintedBitvec.with_name("overwritten_eip", 32)
        assertions.append(overwritten_eip.taint)

        controlled_arg0 = TaintedBitvec.with_name("controlled_arg0", 32)
        assertions.append(controlled_arg0.taint)
        controlled_arg1 = TaintedBitvec.with_name("controlled_arg1", 32)
        assertions.append(controlled_arg1.taint)

        memory = input_state.memory.clone_untainted()
        # attacker-controlled data are 0x600 bytes away from esp
        memory = memory.taint_range(0x41001000+0x600, 0x600)

        # two args are controlled and therefore on the stack at esp+4 and esp+8
        memory.write_at(BV(0x41001000+4, 32), controlled_arg0)
        memory.write_at(BV(0x41001000+8, 32), controlled_arg1)

        memory_assertions = input_state.memory.Equals(memory)
        assertions.append(memory_assertions)

        for regname, reg in input_state.registers.items():
            if regname == "eip":
                # overwritten eip
                assertions.append(reg.Equals(overwritten_eip))
            elif regname == "esp":
                # esp is in stack region
                assertions.append(reg.taint)
                assertions.append(reg.value.Equals(0x41001000))
            else:
                assertions.append(reg.Equals(
                    TaintedBitvec.new_zero_untainted(reg.bv_width)))

        for flag in input_state.flags.values():
            assertions.append(flag.Equals(TaintedBool.new_false_untainted()))

        assumptions = And(assertions)
        return assumptions
    return SimpleAssumptionFunction(_assumptions)


def make_routeros_cve_2023_30799_arm_assumptions(args: Any) -> Assumptions:
    def _assumptions(input_state: State) -> fnode.FNode:
        assertions = []

        overwritten_pc = TaintedBitvec.with_name("overwritten_pc", 32)
        assertions.append(overwritten_pc.taint)

        controlled_arg0 = TaintedBitvec.with_name("controlled_arg0", 32)
        assertions.append(controlled_arg0.taint)
        controlled_arg1 = TaintedBitvec.with_name("controlled_arg1", 32)
        assertions.append(controlled_arg1.taint)

        memory = input_state.memory.clone_untainted()
        # attacker-controlled data are 0x500 bytes away from sp
        memory = memory.taint_range(0x41001000+0x500, 0x600)

        memory_assertions = input_state.memory.Equals(memory)
        assertions.append(memory_assertions)

        for regname, reg in input_state.registers.items():
            # overwritten pc using arb decrement
            if regname == "pc":
                assertions.append(reg.Equals(overwritten_pc))
            elif regname == "sp":
                assertions.append(reg.taint)
                assertions.append(reg.value.Equals(0x41001000))
            # elif regname == "r0":
            #     assertions.append(reg.Equals(controlled_arg0))
            # elif regname == "r1":
            #     assertions.append(reg.Equals(controlled_arg1))
            else:
                assertions.append(reg.Equals(
                    TaintedBitvec.new_zero_untainted(reg.bv_width)))

        for flag in input_state.flags.values():
            assertions.append(flag.Equals(TaintedBool.new_false_untainted()))

        assumptions = And(assertions)
        return assumptions

    return SimpleAssumptionFunction(_assumptions)


def make_optee_cve_2019_1010298_assumptions(args: Any) -> Assumptions:
    def _assumptions(input_state: State) -> fnode.FNode:
        assertions = []

        memory = input_state.memory.clone_untainted()
        # taint the corrupted mobj, but omit the vtable
        memory = memory.taint_range(0x8dc74c20+4, 0x7C)

        memory_assertions = input_state.memory.Equals(memory)
        assertions.append(memory_assertions)

        for regname, reg in input_state.registers.items():

            if regname == "pc":
                assertions.append(reg.taint)
            elif regname == "r0":
                assertions.append(reg.taint)
                assertions.append(reg.value.Equals(0x8dc74c20))
            else:
                assertions.append(reg.Equals(
                    TaintedBitvec.new_zero_untainted(reg.bv_width)))

        for flag in input_state.flags.values():
            assertions.append(flag.Equals(TaintedBool.new_false_untainted()))

        assumptions = And(assertions)
        return assumptions

    return SimpleAssumptionFunction(_assumptions)


assumption_makers: Dict[str, Callable[[Any], Assumptions]] = {
    "CVE-2019-1010298": make_optee_cve_2019_1010298_assumptions,
    "CVE-2023-30799_arm": make_routeros_cve_2023_30799_arm_assumptions,
    "CVE-2023-30799_x86": make_routeros_cve_2023_30799_x86_assumptions,
    "EDB-ID-47122": make_r_edb_id_47122_assumptions,
    "CVE-2016-10190": make_ffmpeg_cve_2016_10190_assumptions,
    "WD-PR4100-NAS": make_wd_pr4100_assumptions,
    "CVE-2018-9958": make_foxit_cve_2018_9958_assumptions,
    "CVE-2021-35211": make_solarwinds_cve_2021_35211_assumptions,
    "CVE-2018-11529": make_vlc_cve_2018_11529_assumptions,
    "CVE-2022-46152": make_optee_cve_2022_46152_assumptions,
}


def make_assumptions(args: Any) -> Assumptions:
    return assumption_makers[args.assumptions](args)


def make_generic_func_call_1arg_specs(args: Any) -> Specifications:
    def _x86_specifications(_: State, output_state: State) -> Specifications:
        esp = output_state.registers['esp']
        retaddr = output_state.memory.read_at(esp.value, 4)
        arg0 = output_state.memory.read_at(esp.value + 4, 4)
        eip = output_state.registers['eip']
        retaddr_is_arb = retaddr.Equals(TaintedBitvec.from_int(0xDEADC0DE, 32))
        arg0_is_arb = arg0.Equals(TaintedBitvec.from_int(0xBAD, 32))
        eip_is_arb = eip.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, eip.bv_width))
        assertions = And(
            [esp.taint, retaddr_is_arb, arg0_is_arb, eip_is_arb])
        return assertions

    def _x86_64_specifications(_: State, output_state: State) -> Specifications:
        rdi = output_state.registers['rdi']
        rip = output_state.registers['rip']
        rdi_is_arb = rdi.Equals(TaintedBitvec.from_int(
            0xDEADC0DE0BAD0DAD, rdi.bv_width))
        rip_is_arb = rip.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, rip.bv_width))
        assertions = And([rdi_is_arb, rip_is_arb])
        return assertions

    def _x86_64_specifications_windows(_: State, output_state: State) -> Specifications:
        rcx = output_state.registers['rcx']
        rip = output_state.registers['rip']
        rcx_is_arb = rcx.Equals(TaintedBitvec.from_int(
            0xDEADC0DE0BAD0DAD, rcx.bv_width))
        rip_is_arb = rip.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, rip.bv_width))
        assertions = And([rcx_is_arb, rip_is_arb])
        return assertions

    def _arm_specifications(_: State, output_state: State) -> Specifications:
        r0 = output_state.registers['r0']
        pc = output_state.registers['pc']
        r0_is_arb = r0.Equals(TaintedBitvec.from_int(0xDEADC0DE, r0.bv_width))
        pc_is_arb = pc.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, pc.bv_width))
        assertions = And(
            [r0_is_arb, pc_is_arb])
        return assertions

    match assumptions_arch[args.assumptions], assumptions_platform[args.assumptions]:
        case 'x86', _:
            return SimpleSpecificationFunction(_x86_specifications)
        case 'x86_64', 'linux':
            return SimpleSpecificationFunction(_x86_64_specifications)
        case 'x86_64', 'windows':
            return SimpleSpecificationFunction(_x86_64_specifications_windows)
        case 'arm', 'linux':
            return SimpleSpecificationFunction(_arm_specifications)
        case _:
            raise NotImplementedError


def make_generic_func_call_3args_specs(args: Any) -> Specifications:
    def _x86_specifications(_: State, output_state: State) -> Specifications:
        esp = output_state.registers['esp']
        retaddr = output_state.memory.read_at(esp.value, 4)
        arg0 = output_state.memory.read_at(esp.value + 4, 4)
        arg1 = output_state.memory.read_at(esp.value + 8, 4)
        arg2 = output_state.memory.read_at(esp.value + 12, 4)
        eip = output_state.registers['eip']
        retaddr_is_arb = retaddr.Equals(TaintedBitvec.from_int(0xDEADC0DE, 32))
        arg0_is_arb = arg0.Equals(TaintedBitvec.from_int(0xBAD, 32))
        arg1_is_arb = arg1.Equals(TaintedBitvec.from_int(0xC0DE, 32))
        arg2_is_arb = arg2.Equals(TaintedBitvec.from_int(0x0, 32))
        eip_is_arb = eip.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, eip.bv_width))
        assertions = And(
            [esp.taint, retaddr_is_arb, arg0_is_arb, arg1_is_arb, arg2_is_arb, eip_is_arb])
        return assertions

    def _x86_64_specifications(_: State, output_state: State) -> Specifications:
        rsi = output_state.registers['rsi']
        rdi = output_state.registers['rdi']
        rdx = output_state.registers['rdx']
        rip = output_state.registers['rip']
        rsi_is_arb = rsi.Equals(TaintedBitvec.from_int(0xBAD, rsi.bv_width))
        rdi_is_arb = rdi.Equals(TaintedBitvec.from_int(
            0xDEADC0DE0BAD0DAD, rdi.bv_width))
        rdx_is_arb = rdx.Equals(TaintedBitvec.from_int(
            0x0CAD00000DAD0000, rdx.bv_width))
        rip_is_arb = rip.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, rip.bv_width))
        assertions = And([rsi_is_arb, rdi_is_arb, rdx_is_arb, rip_is_arb])
        return assertions

    def _x86_64_specifications_windows(_: State, output_state: State) -> Specifications:
        rcx = output_state.registers['rcx']
        rdx = output_state.registers['rdx']
        r8 = output_state.registers['r8']
        rip = output_state.registers['rip']
        rcx_is_arb = rcx.Equals(TaintedBitvec.from_int(
            0xDEADC0DE0BAD0DAD, rcx.bv_width))
        rdx_is_arb = rdx.Equals(TaintedBitvec.from_int(
            0x000BADC0DE0CAD00, rdx.bv_width))
        r8_is_arb = r8.Equals(TaintedBitvec.from_int(
            0xBAD00000DEAD0000, r8.bv_width))
        rip_is_arb = rip.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, rip.bv_width))
        assertions = And([rcx_is_arb, rdx_is_arb, r8_is_arb, rip_is_arb])
        return assertions

    def _arm_specifications(_: State, output_state: State) -> Specifications:
        r0 = output_state.registers['r0']
        r1 = output_state.registers['r1']
        r2 = output_state.registers['r2']
        pc = output_state.registers['pc']
        r0_is_arb = r0.Equals(TaintedBitvec.from_int(0xDEADC0DE, r0.bv_width))
        r1_is_arb = r1.Equals(TaintedBitvec.from_int(0xC0DE0BAD, r1.bv_width))
        r2_is_arb = r2.Equals(TaintedBitvec.from_int(0x0DADDEAD, r2.bv_width))
        pc_is_arb = pc.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, pc.bv_width))
        assertions = And(
            [r0_is_arb, r1_is_arb, r2_is_arb, pc_is_arb])
        return assertions

    match assumptions_arch[args.assumptions], assumptions_platform[args.assumptions]:
        case 'x86', _:
            return SimpleSpecificationFunction(_x86_specifications)
        case 'x86_64', 'linux':
            return SimpleSpecificationFunction(_x86_64_specifications)
        case 'x86_64', 'windows':
            return SimpleSpecificationFunction(_x86_64_specifications_windows)
        case 'arm', 'linux':
            return SimpleSpecificationFunction(_arm_specifications)
        case _:
            raise NotImplementedError


def make_generic_func_call_4args_specs(args: Any) -> Specifications:
    def _x86_specifications(_: State, output_state: State) -> Specifications:
        esp = output_state.registers['esp']
        retaddr = output_state.memory.read_at(esp.value, 4)
        arg0 = output_state.memory.read_at(esp.value + 4, 4)
        arg1 = output_state.memory.read_at(esp.value + 8, 4)
        arg2 = output_state.memory.read_at(esp.value + 12, 4)
        arg3 = output_state.memory.read_at(esp.value + 16, 4)
        eip = output_state.registers['eip']
        retaddr_is_arb = retaddr.Equals(TaintedBitvec.from_int(0xDEADC0DE, 32))
        arg0_is_arb = arg0.Equals(TaintedBitvec.from_int(0xBAD, 32))
        arg1_is_arb = arg1.Equals(TaintedBitvec.from_int(0xC0DE, 32))
        arg2_is_arb = arg2.Equals(TaintedBitvec.from_int(0x0, 32))
        arg3_is_arb = arg3.Equals(TaintedBitvec.from_int(0xFF, 32))
        eip_is_arb = eip.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, eip.bv_width))
        assertions = And(
            [esp.taint, retaddr_is_arb, arg0_is_arb, arg1_is_arb, arg2_is_arb, arg3_is_arb, eip_is_arb])
        return assertions

    def _x86_64_specifications(_: State, output_state: State) -> Specifications:
        rsi = output_state.registers['rsi']
        rdi = output_state.registers['rdi']
        rdx = output_state.registers['rdx']
        rcx = output_state.registers['rcx']
        rip = output_state.registers['rip']
        rsi_is_arb = rsi.Equals(TaintedBitvec.from_int(0xBAD, rsi.bv_width))
        rdi_is_arb = rdi.Equals(TaintedBitvec.from_int(
            0xDEADC0DE0BAD0DAD, rdi.bv_width))
        rdx_is_arb = rdx.Equals(TaintedBitvec.from_int(
            0x000BADC0DE0CAD00, rdx.bv_width))
        rcx_is_arb = rcx.Equals(TaintedBitvec.from_int(
            0xFFDDEEAABB00CC88, rcx.bv_width))
        rip_is_arb = rip.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, rip.bv_width))
        assertions = And(
            [rsi_is_arb, rdi_is_arb, rdx_is_arb, rcx_is_arb, rip_is_arb])
        return assertions

    def _x86_64_specifications_windows(_: State, output_state: State) -> Specifications:
        rcx = output_state.registers['rcx']
        rdx = output_state.registers['rdx']
        r8 = output_state.registers['r8']
        r9 = output_state.registers['r9']
        rip = output_state.registers['rip']
        rcx_is_arb = rcx.Equals(TaintedBitvec.from_int(
            0xDEADC0DE0BAD0DAD, rcx.bv_width))
        rdx_is_arb = rdx.Equals(TaintedBitvec.from_int(
            0x000BADC0DE0CAD00, rdx.bv_width))
        r8_is_arb = r8.Equals(TaintedBitvec.from_int(
            0xBAD00000DEAD0000, r8.bv_width))
        r9_is_arb = r9.Equals(TaintedBitvec.from_int(
            0xFFDDEEAABB00CC88, r9.bv_width))
        rip_is_arb = rip.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, rip.bv_width))
        assertions = And(
            [rcx_is_arb, rdx_is_arb, r8_is_arb, r9_is_arb, rip_is_arb])
        return assertions

    def _arm_specifications(_: State, output_state: State) -> Specifications:
        r0 = output_state.registers['r0']
        r1 = output_state.registers['r1']
        r2 = output_state.registers['r2']
        r3 = output_state.registers['r3']
        pc = output_state.registers['pc']
        r0_is_arb = r0.Equals(TaintedBitvec.from_int(0xDEADC0DE, r0.bv_width))
        r1_is_arb = r1.Equals(TaintedBitvec.from_int(0xC0DE0BAD, r1.bv_width))
        r2_is_arb = r2.Equals(TaintedBitvec.from_int(0x0DADDEAD, r2.bv_width))
        r3_is_arb = r3.Equals(TaintedBitvec.from_int(0xBABADADA, r3.bv_width))
        pc_is_arb = pc.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, pc.bv_width))
        assertions = And(
            [r0_is_arb, r1_is_arb, r2_is_arb, r3_is_arb, pc_is_arb])
        return assertions

    match assumptions_arch[args.assumptions], assumptions_platform[args.assumptions]:
        case 'x86', _:
            return SimpleSpecificationFunction(_x86_specifications)
        case 'x86_64', 'linux':
            return SimpleSpecificationFunction(_x86_64_specifications)
        case 'x86_64', 'windows':
            return SimpleSpecificationFunction(_x86_64_specifications_windows)
        case 'arm', 'linux':
            return SimpleSpecificationFunction(_arm_specifications)
        case _:
            raise NotImplementedError


def make_syscall_4args_specs(args: Any) -> Specifications:
    raise NotImplementedError


def make_optee_cve_stack_pivot_specs(args: Any) -> Specifications:
    def _specifications(_: State, output_state: State) -> Specifications:
        sp = output_state.registers['sp']
        pc = output_state.registers['pc']
        sp_points_in_pivot_buffer = And(
            [sp.taint, sp.value >= 0x8F700000, sp.value < 0x8F700100])
        pc_is_arb = pc.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, pc.bv_width))
        assertions = And(
            [sp_points_in_pivot_buffer, pc_is_arb])
        return assertions
    return SimpleSpecificationFunction(_specifications)


def make_solarwinds_cve_2021_35211_stack_pivot_specs(args: Any) -> Specifications:
    def _specifications(_: State, output_state: State) -> Specifications:
        rsp = output_state.registers['rsp']
        rip = output_state.registers['rip']
        rsp_points_in_pivot_buffer = And(
            [rsp.taint, rsp.value >= 0x000001ed4d5a40fa, rsp.value < 0x000001ed4d5a40fa+0x80])
        rip_is_arb = rip.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, rip.bv_width))
        assertions = And(
            [rsp_points_in_pivot_buffer, rip_is_arb])
        return assertions
    return SimpleSpecificationFunction(_specifications)


def make_foxit_cve_2018_9958_stack_pivot_specs(args: Any) -> Specifications:
    def _specifications(_: State, output_state: State) -> Specifications:
        esp = output_state.registers['esp']
        eip = output_state.registers['eip']
        esp_points_in_pivot_buffer = And(
            [esp.taint, esp.value >= 0x00733498, esp.value < 0x00733498+0x40])
        eip_is_arb = eip.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, eip.bv_width))
        assertions = And(
            [esp_points_in_pivot_buffer, eip_is_arb])
        return assertions
    return SimpleSpecificationFunction(_specifications)


def make_wd_pr4100_stack_pivot_specs(args: Any) -> Specifications:
    def _specifications(_: State, output_state: State) -> Specifications:
        rsp = output_state.registers['rsp']
        rip = output_state.registers['rip']
        rsp_points_in_pivot_buffer = And(
            [rsp.taint, rsp.value >= 0x7fffd04e85b0+0x110, rsp.value < 0x7fffd04e85b0+0x110+0x60])
        rip_is_arb = rip.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, rip.bv_width))
        assertions = And(
            [rsp_points_in_pivot_buffer, rip_is_arb])
        return assertions
    return SimpleSpecificationFunction(_specifications)


def make_ffmpeg_cve_2016_10190_stack_pivot_specs(args: Any) -> Specifications:
    def _specifications(_: State, output_state: State) -> Specifications:
        rsp = output_state.registers['rsp']
        rip = output_state.registers['rip']
        rsp_points_in_pivot_buffer = And(
            [rsp.taint, rsp.value >= 0x1de6b80+0x8060, rsp.value < 0x1de6b80+0x8060+0x100])
        rip_is_arb = rip.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, rip.bv_width))
        assertions = And(
            [rsp_points_in_pivot_buffer, rip_is_arb])
        return assertions
    return SimpleSpecificationFunction(_specifications)


def make_r_edb_id_47122_stack_pivot_specs(args: Any) -> Specifications:
    def _specifications(_: State, output_state: State) -> Specifications:
        esp = output_state.registers['esp']
        eip = output_state.registers['eip']
        esp_points_in_pivot_buffer = And(
            [esp.taint, esp.value >= 0x41001000+0x7b4, esp.value < 0x41001000+0x7b4+0x600])
        eip_is_arb = eip.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, eip.bv_width))
        assertions = And(
            [esp_points_in_pivot_buffer, eip_is_arb])
        return assertions
    return SimpleSpecificationFunction(_specifications)


def make_routeros_cve_2023_30799_x86_stack_pivot_specs(args: Any) -> Specifications:
    def _specifications(_: State, output_state: State) -> Specifications:
        esp = output_state.registers['esp']
        eip = output_state.registers['eip']
        esp_points_in_pivot_buffer = And(
            [esp.taint, esp.value >= 0x41001000+0x600, esp.value < 0x41001000+0x600+0x600])
        eip_is_arb = eip.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, eip.bv_width))
        assertions = And(
            [esp_points_in_pivot_buffer, eip_is_arb])
        return assertions
    return SimpleSpecificationFunction(_specifications)


def make_routeros_cve_2023_30799_arm_stack_pivot_specs(args: Any) -> Specifications:
    def _specifications(_: State, output_state: State) -> Specifications:
        sp = output_state.registers['sp']
        pc = output_state.registers['pc']
        sp_points_in_pivot_buffer = And(
            [sp.taint, sp.value >= 0x41001000+0x500, sp.value < 0x41001000+0x500+0x600])
        pc_is_arb = pc.Equals(
            TaintedBitvec.from_int(0xDEADCAFE, pc.bv_width))
        assertions = And(
            [sp_points_in_pivot_buffer, pc_is_arb])
        return assertions
    return SimpleSpecificationFunction(_specifications)


specification_makers: Dict[str, Dict[str, Callable[[Any], Specifications]]] = {
    "CVE-2019-1010298": {"func-call-3args": make_generic_func_call_3args_specs,
                         "func-call-4args": make_generic_func_call_4args_specs, },
    "CVE-2023-30799_arm": {"stack-pivot": make_routeros_cve_2023_30799_arm_stack_pivot_specs,
                           "func-call-3args": make_generic_func_call_3args_specs,
                           "func-call-4args": make_generic_func_call_4args_specs, },
    "CVE-2023-30799_x86": {"stack-pivot": make_routeros_cve_2023_30799_x86_stack_pivot_specs,
                           "func-call-3args": make_generic_func_call_3args_specs,
                           "func-call-4args": make_generic_func_call_4args_specs, },
    "EDB-ID-47122": {"stack-pivot": make_r_edb_id_47122_stack_pivot_specs,
                     "func-call-3args": make_generic_func_call_3args_specs,
                     "func-call-4args": make_generic_func_call_4args_specs, },
    "CVE-2016-10190": {"stack-pivot": make_ffmpeg_cve_2016_10190_stack_pivot_specs,
                       "func-call-3args": make_generic_func_call_3args_specs,
                       "func-call-4args": make_generic_func_call_4args_specs},
    "WD-PR4100-NAS": {"stack-pivot": make_wd_pr4100_stack_pivot_specs,
                      "func-call-1arg": make_generic_func_call_1arg_specs,
                      "func-call-3args": make_generic_func_call_3args_specs,
                      "func-call-4args": make_generic_func_call_4args_specs, },
    "CVE-2018-9958": {"stack-pivot": make_foxit_cve_2018_9958_stack_pivot_specs,
                      "func-call-3args": make_generic_func_call_3args_specs,
                      "func-call-4args": make_generic_func_call_4args_specs, },
    "CVE-2021-35211": {"stack-pivot": make_solarwinds_cve_2021_35211_stack_pivot_specs,
                       "func-call-3args": make_generic_func_call_3args_specs,
                       "func-call-4args": make_generic_func_call_4args_specs, },
    "CVE-2018-11529": {"func-call-3args": make_generic_func_call_3args_specs,
                       "func-call-4args": make_generic_func_call_4args_specs, },
    "CVE-2022-46152": {"stack-pivot": make_optee_cve_stack_pivot_specs,
                       "func-call-3args": make_generic_func_call_3args_specs,
                       "func-call-4args": make_generic_func_call_4args_specs, },
}


def make_specifications(args: Any) -> Specifications:
    return specification_makers[args.assumptions][args.goal](args)


def memory_profiler(processes: List[multiprocessing.Process], memusages: List[int], stop_event: threading.Event) -> None:
    procs = list(map(lambda p: psutil.Process(p.pid), processes))
    while not stop_event.is_set():
        for i in range(len(procs)):
            p = procs[i]
            try:
                memusages[i] = max(p.memory_info().vms, memusages[i])
            except Exception as _:
                continue
        time.sleep(0.01)


def benchmark(args: Any):
    mem_layout = make_memory_layout(args)
    assumptions = make_assumptions(args)
    specifications = make_specifications(args)

    random.seed(args.seed)
    seed_queue = Queue()
    for _ in range(args.jobs):
        seed_queue.put(random.getrandbits(64))

    mem_store_proportion_queue = Queue()
    with_mem_store_count = int(args.jobs*args.jobs_with_mem_stores)
    with_high_mem_store_count = with_mem_store_count//2
    with_low_mem_store_count = with_mem_store_count - with_high_mem_store_count
    without_mem_store_count = args.jobs - with_mem_store_count
    for _ in range(without_mem_store_count):
        mem_store_proportion_queue.put(0.00)
    for _ in range(with_low_mem_store_count):
        mem_store_proportion_queue.put(args.low_mem_store_ratio)
    for _ in range(with_high_mem_store_count):
        mem_store_proportion_queue.put(args.high_mem_store_ratio)

    init_barrier = multiprocessing.Barrier(args.jobs + 1)
    start_event = multiprocessing.Event()
    result_queue = multiprocessing.Queue()
    synthesis_fn = get_synthesis_function(args)

    synthesis_args = {'result_queue': result_queue, 'start_event': start_event, 'init_barrier': init_barrier,
                      'seed_queue': seed_queue, 'mem_store_proportion_queue': mem_store_proportion_queue, 'args': args, 'mem_layout': mem_layout, 'assumptions': assumptions, 'specifications': specifications}
    processes = [multiprocessing.Process(
        target=synthesis_fn, args=(i,), kwargs=synthesis_args, daemon=True) for i in range(args.jobs)]

    mem_usages = [0]*len(processes)
    stop_profile_event = threading.Event()
    mem_profile_thread = Thread(target=memory_profiler, args=(
        processes, mem_usages, stop_profile_event))
    mem_profile_thread.start()

    for p in processes:
        p.start()

    init_barrier.wait()
    start = timer()
    deadline = start + args.timeout
    start_event.set()

    chain: SynthesizedChain | None = None
    timed_out = False

    while chain is None and any(map(lambda p: p.is_alive(), processes)):
        remaining = deadline - timer()
        if remaining <= 0:
            LOGGER.warning("Timed out...")
            timed_out = True
            time_taken = args.timeout
            break
        try:
            # FIXME: seems like 'get' with timeout ends up not working for whatever reason
            # when a log of values are put in the queue simultaneously, 'get' with timeout fails
            # to get the values...
            idx, timestamp, chain = result_queue.get_nowait()
            time.sleep(1)
        except queue.Empty:
            continue
        processes[idx].terminate()
        time_taken = timestamp - start

    for p in processes:
        p.kill()

    stop_profile_event.set()
    mem_profile_thread.join()

    if chain is not None:
        LOGGER.info(f"Successfully found chain in {time_taken}s")
        for g in chain.chain:
            LOGGER.info(g.assembly_str)
    else:
        LOGGER.warning("Unable to find chain...")

    if args.output:
        log_results = dict()
        log_results["time"] = time_taken
        log_results["timeout"] = timed_out
        log_results["success"] = chain is not None
        log_results["max_length"] = args.max_length
        log_results["library_size"] = args.library_size
        log_results["synthesis_per_length"] = args.jobs
        log_results["jobs"] = args.jobs
        log_results["memory_peaks"] = mem_usages
        if chain is not None:
            log_results["chain_length"] = len(chain.chain)
            log_results["raw"] = list(
                map(lambda g: g.assembly_str, chain.chain))
        with open(args.output, 'w') as f:
            json.dump(log_results, f)

    sys.exit()


assumptions_arch = {
    "CVE-2019-1010298": "arm",
    "CVE-2023-30799_arm": "arm",
    "CVE-2023-30799_x86": "x86",
    "EDB-ID-47122": "x86",
    "CVE-2016-10190": "x86_64",
    "WD-PR4100-NAS": "x86_64",
    "CVE-2018-9958": "x86",
    "CVE-2021-35211": "x86_64",
    "CVE-2018-11529": "x86",
    "CVE-2022-46152": "arm",
}

assumptions_platform = {
    "CVE-2019-1010298": "linux",
    "CVE-2023-30799_arm": "linux",
    "CVE-2023-30799_x86": "linux",
    "EDB-ID-47122": "windows",
    "CVE-2016-10190": "linux",
    "WD-PR4100-NAS": "linux",
    "CVE-2018-9958": "windows",
    "CVE-2021-35211": "windows",
    "CVE-2018-11529": "windows",
    "CVE-2022-46152": "linux",
}

assumptions_list = [
    ("CVE-2019-1010298", "Heap Overflow in OPTEE <= 3.3"),
    ("CVE-2023-30799_arm", "Arbitrary Jump in RouterOS <= 6.49.6 (ARM)"),
    ("CVE-2023-30799_x86", "Arbitrary Jump in RouterOS <= 6.49.6 (x86)"),
    ("EDB-ID-47122", "Stack Overflow in R <= 3.4.4"),
    ("CVE-2016-10190",
     "Heap Overflow in FFMPEG (libavformat) <= 3.2.2 (AVIOContext object corruption)"),
    ("WD-PR4100-NAS", "Stack Overflow in Western Digital PR4100 NAS (login_mgr.cgi) <= v2.41.116 (stack-pointer does not point to controlled data)"),
    ("CVE-2018-9958", "UaF in FoxitReader <= 9.0.1.1049 (corrupted vtable)"),
    ("CVE-2021-35211", "Arbitrary Jump in SolarWinds Serv-U FTP <= 15.2.3.717"),
    ("CVE-2018-11529", "UaF vulnerability in VLC <= 2.2.8 (corrupted object)"),
    ("CVE-2022-46152", "Arbitrary stack value decrement in OPTEE <= 3.6"),
]


goals_list = {
    "CVE-2019-1010298": [("func-call-3args", "Function call with 3 arguments"),
                         ("func-call-4args", "Function call with 4 arguments")],
    "CVE-2023-30799_arm": [("stack-pivot", "Move the stack-pointer to a controlled buffer"),
                           ("func-call-3args", "Function call with 3 arguments"),
                           ("func-call-4args", "Function call with 4 arguments")],
    "CVE-2023-30799_x86": [("stack-pivot", "Move the stack-pointer to a controlled buffer"),
                           ("func-call-3args", "Function call with 3 arguments"),
                           ("func-call-4args", "Function call with 4 arguments")],
    "EDB-ID-47122": [("stack-pivot", "Move the stack-pointer to a controlled buffer"),
                     ("func-call-3args", "Function call with 3 arguments"),
                     ("func-call-4args", "Function call with 4 arguments")],
    "CVE-2016-10190": [("stack-pivot", "Move the stack-pointer to a controlled buffer"),
                       ("func-call-3args", "Function call with 3 arguments"),
                       ("func-call-4args", "Function call with 4 arguments")],
    "WD-PR4100-NAS": [("stack-pivot", "Move the stack-pointer to a controlled buffer"),
                      ("func-call-1arg",
                       "Function call with 1 argument (e.g. 'system(cmd)')"),
                      ("func-call-3args", "Function call with 3 arguments"),
                      ("func-call-4args", "Function call with 4 arguments")],
    "CVE-2018-9958": [("stack-pivot", "Move the stack-pointer to a controlled buffer"),
                      ("func-call-3args", "Function call with 3 arguments"),
                      ("func-call-4args", "Function call with 4 arguments")],
    "CVE-2021-35211": [("stack-pivot", "Move the stack-pointer to a controlled buffer"),
                       ("func-call-3args", "Function call with 3 arguments"),
                       ("func-call-4args", "Function call with 4 arguments"),],
    "CVE-2018-11529": [("func-call-3args", "Function call with 3 arguments"),
                       ("func-call-4args", "Function call with 4 arguments"),],
    "CVE-2022-46152": [("stack-pivot", "Move the stack-pointer to a controlled buffer"),
                       ("func-call-3args", "Function call with 3 arguments"),
                       ("func-call-4args", "Function call with 4 arguments"),],
}


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Use ARCANIST to find chains for specific concrete CVEs and several goals")

    parser.add_argument("gadgets", help="Path to the JSON gadget library")
    parser.add_argument(
        "max_length", help="Max length of synthesized chain", type=int)
    parser.add_argument(
        "library_size", help="Size of gadget libraries provided to the solver", type=int)

    parser.add_argument("--strategy", help="Solving strategy",
                        choices=['one-shot', 'incremental'], default='incremental')

    parser.add_argument(
        "--seed", help="Seed for random library sampling", default=1337, type=int)

    parser.add_argument(
        "--timeout", help="Timeout limit in seconds", default=3600, type=int)
    parser.add_argument(
        "--jobs", help="Number of processes", type=int, default=1)
    parser.add_argument(
        "--jobs_with_mem_stores", help="Proportion of syntheses given gadgets that include memory store operations", type=float, default=0.25
    )

    parser.add_argument(
        "--low_mem_store_ratio", help="The proportion of gadgets with memory stores operation in 'low mem store proportion' mode", type=float, default=0.05
    )

    parser.add_argument(
        "--high_mem_store_ratio", help="The proportion of gadgets with memory stores operation in 'high mem store proportion' mode", type=float, default=0.10
    )

    parser.add_argument(
        "--balance-rop-jop-gadgets", help="Gadget sampling heuristics that balance the number of 'ROP' and 'JOP' gadgets", action='store_true', default=False
    )

    parser.add_argument(
        "--force-rare-gadgets", help="Gadget sampling heuristics that forces the inclusion of rare gadgets", action='store_true', default=False
    )

    parser.add_argument(
        "--output", help="Output results to JSON file", type=str)

    assumptions_parsers = parser.add_subparsers(
        dest="assumptions", help="Which CVEs, in which memory layout"
    )

    for cve_name, help in assumptions_list:
        subparser = assumptions_parsers.add_parser(cve_name, help=help)

        if cve_name == 'CVE-2016-10190':
            subparser.add_argument("--with-rbx", action='store_true')
            subparser.add_argument("--with-rbp", action='store_true')
        elif cve_name == 'CVE-2021-35211':
            subparser.add_argument("--force-r9-gadgets", action='store_true')

        goal_parsers = subparser.add_subparsers(
            dest="goal", help="Which goal to achieve", required=True)
        for goal_name, help in goals_list[cve_name]:
            goal_parsers.add_parser(goal_name, help=help)

    args = parser.parse_args()
    benchmark(args)


if __name__ == '__main__':
    main()
