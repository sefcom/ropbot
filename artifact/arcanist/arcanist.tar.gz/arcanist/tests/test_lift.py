from arcanist.architecture import Architecture
from arcanist.platform import Platform
from arcanist.extractor.ropper import RopperExtractor

import random

import logging
from arcanist.gadgets.extraction import RawGadget, RawGadgetLibrary
from arcanist.synthesizer.gadget import GadgetLibrary, JSONGadget
from arcanist.synthesizer.memory import TaintedMemory
from arcanist.synthesizer.memory_layout import MemoryLayout
from arcanist.synthesizer.smt.simplifiers import Z3Simplifier
from arcanist.synthesizer.state import State
from arcanist.synthesizer.state_builder import OnlyUsedRegisterStateBuilder, StateBuilderBase
from arcanist.synthesizer.synthesis import Assumptions, IncrementalSynthesizer, Specifications, OneShotSynthesizer
from arcanist.synthesizer.tainted_types.bitvec import TaintedBitvec

from arcanist.translator.binaryninja.llil_gadget import CustomWorkflowSSAGadgetAnalysis
from arcanist.translator.binaryninja.smt_gadget import SMTGadget, binaryninja_arch_to_synthesizer_arch_info

from arcanist.translator.binaryninja.translate import BinaryNinjaTranslator
from pysmt import fnode
from pysmt.shortcuts import And, Solver, TRUE
from pysmt.logics import QF_AUFBV

import binaryninja.architecture

from timeit import default_timer as timer
LOGGER = logging.getLogger(__name__)

# x86 lifting quirks
# - 'setl al'        => 'al = flag:s != flag:o' instead of LLIL_BOOL_TO_INT


def test_lift_no_error():
    extractor = RopperExtractor()
    LOGGER.info("Extracting gadgets...")
    # gadgets = extractor.extract_from_elf("/lib64/libc.so.6", base=0x1000)
    gadgets = extractor.extract_from_elf("/bin/ls", base=0x1000)
    # gadgets = RawGadgetList(Architecture.x86_64, [RawGadget(
    #    "", 0, b'\x00\x00H9\xcar\x05H9\xd1\x19\xc0\xc3', 0)])
    LOGGER.info("Extraction done.")
    LOGGER.info("Beginning analysis...")
    LOGGER.info(f"{len(gadgets.gadgets)} gadgets to analyze")

    has_select_after_store = 0
    bad_count = 0
    i = 0
    for gadget in gadgets.gadgets[i:]:
        LOGGER.info(f"gadget {i}")
        data = gadget.raw_bytes
        addr = gadget.address

        LOGGER.info("lifting...")
        g = CustomWorkflowSSAGadgetAnalysis.lift(
            data, addr, 'x86_64', 'linux-x86_64', gadget.assembly_string)
        # for instr in g.llil_ssa.instructions:
        #     print(instr)
        if g is None:
            # LOGGER.error("INVALID GADGET:\n" + gadget.assembly_string)
            # LOGGER.error(gadget.raw_bytes)
            bad_count += 1
        else:
            try:
                LOGGER.info("smt translation...")
                simplifier = Z3Simplifier()
                arch_info = binaryninja_arch_to_synthesizer_arch_info(
                    binaryninja.Architecture['x86_64'])
                smt_gadget = SMTGadget(arch_info, g, simplifier)
            except Exception as e:
                LOGGER.fatal(f"FAILED TO TRANSLATE INTO SMT, GADGET {i}")
                LOGGER.fatal(gadget.assembly_string)
                LOGGER.fatal(gadget.raw_bytes)
                raise e

            if smt_gadget.has_select_after_store_operation:
                has_select_after_store += 1

            # try:
            #     smt_gadget.build_output_state()
            # except Exception as e:
            #     LOGGER.fatal(f"FAILED TO BUILD OUTPUT STATE, GADGET {i}")
            #     LOGGER.fatal(gadget.assembly_string)
            #     LOGGER.fatal(gadget.raw_bytes)
            #     raise e

            arch_info = binaryninja_arch_to_synthesizer_arch_info(g._func.arch)
            state_builder = StateBuilderBase(arch_info, [smt_gadget])
            init_state = state_builder.build_with_name("state0")
            final_state = state_builder.build_with_name("state1")
            memory_layout = MemoryLayout()
            memory_layout.add_region(
                0x1000, 0x100F, readable=True, writable=True)

            try:
                LOGGER.info("check building concrete formula...")
                smt_gadget.build_formula(
                    init_state, final_state, memory_layout)
            except Exception as e:
                LOGGER.fatal(f"FAILED TO BUILD FORMULA, GADGET {i}")
                LOGGER.fatal(gadget.assembly_string)
                LOGGER.fatal(gadget.raw_bytes)
                raise e

            try:
                LOGGER.info("check serialize json...")
                json = smt_gadget.to_json_str()
            except Exception as e:
                LOGGER.fatal(f"FAILED TO SERIALIZE TO JSON, GADGET {i}")
                LOGGER.fatal(gadget.assembly_string)
                LOGGER.fatal(gadget.raw_bytes)
                raise e

            try:
                LOGGER.info("check deserialize json...")
                json_gadget: JSONGadget = JSONGadget.from_json_str(
                    arch_info, json)
            except Exception as e:
                LOGGER.fatal(f"FAILED TO DESERIALIZE FROM JSON, GADGET {i}")
                LOGGER.fatal(gadget.assembly_string)
                LOGGER.fatal(gadget.raw_bytes)
                raise e

            LOGGER.info("check desizerialized is valid...")
            if json_gadget.inputs != smt_gadget.inputs or json_gadget.outputs != smt_gadget.outputs or json_gadget.memory_predicates != smt_gadget.memory_predicates or json_gadget.formula != smt_gadget.formula:
                LOGGER.fatal(
                    f"MISTMATCH BETWEEN ORIGINAL AND DESERIALIZED, GADGET {i}")
                LOGGER.fatal(gadget.assembly_string)
                LOGGER.fatal(gadget.raw_bytes)
                raise ValueError()

        i += 1

    LOGGER.info(f"Initial library size: {len(gadgets.gadgets)}")
    LOGGER.info(f"Found {bad_count}/{len(gadgets.gadgets)} invalid gadgets")
    LOGGER.info(
        f"Found {has_select_after_store}/{len(gadgets.gadgets) - bad_count} gadgets with select-after-store constraints")
    LOGGER.info("Analysis done.")

    # cProfile.run("_lift()", "/tmp/lift_stats")
    # p = pstats.Stats("/tmp/lift_stats")
    # LOGGER.info(str(p.sort_stats("cumulative")))


def test_basic_one_shot_x86_synthesis():
    gadget0 = RawGadget('xor rax, rax; ret', 0xb41a9, b'\x48\x31\xC0\xC3', 2)
    gadget1 = RawGadget('add rax, 1; ret', 0xc8480,
                        b'\x48\x83\xC0\x01\xC3', 2)

    translator = BinaryNinjaTranslator(Platform.LINUX)

    # lifted_gadget0 = CustomWorkflowSSAGadgetAnalysis.lift_raw_gadget(
    #     gadget0, Architecture.x86_64, Platform.LINUX)
    # lifted_gadget1 = CustomWorkflowSSAGadgetAnalysis.lift_raw_gadget(
    #     gadget1, Architecture.x86_64, Platform.LINUX)

    smt_gadget0 = translator.translate_single(Architecture.x86_64, gadget0)
    smt_gadget1 = translator.translate_single(Architecture.x86_64, gadget1)

    # LOGGER.info(smt_gadget0._final_formula)
    # LOGGER.info(smt_gadget1._final_formula)

    memory_layout = MemoryLayout()
    memory_layout.add_region(
        0x00007FFF00000000, 0x00007FFF0000000F, readable=True, writable=False)

    class AllUntaintedAssumptions(Assumptions):
        def __init__(self):
            pass

        def assumptions(self, input: State) -> fnode.FNode:
            memory = input.memory.clone_untainted().taint_range(
                0x00007FFF00000000, 0x40)
            memory_assertions = input.memory.Equals(memory)
            assertions = [memory_assertions]
            for regname, reg in input.registers.items():
                if regname == 'rip':
                    assertions.append(reg.taint)
                elif regname == 'rsp':
                    assertions.append(reg.Equals(
                        TaintedBitvec.from_int(0x00007FFF00000000, reg.bv_width)))
                else:
                    assertions.append(reg.Equals(
                        TaintedBitvec.new_zero_untainted(reg.bv_width)))

            assumptions = And(assertions)
            return assumptions

    class RaxIsOneSpecifications(Specifications):
        def __init__(self):
            pass

        def specifications(self, _: State, output: State) -> fnode.FNode:
            rax = output.registers["rax"]
            rip = output.registers['rip']
            rax_is_one = rax.Equals(TaintedBitvec.from_int(1, rax.bv_width))
            rip_is_arb = rip.Equals(
                TaintedBitvec.from_int(0xDEADC0DE, rip.bv_width))
            assertions = And([rax_is_one, rip_is_arb])
            return assertions

    arch = binaryninja_arch_to_synthesizer_arch_info(
        binaryninja.Architecture['x86_64'])

    solver_1 = Solver(logic=QF_AUFBV, name='btor')
    synthesizer_1 = OneShotSynthesizer(
        solver_1, arch, 1, [smt_gadget0, smt_gadget1]*100, OnlyUsedRegisterStateBuilder)

    solver_2 = Solver(logic=QF_AUFBV, name='btor')
    synthesizer_2 = OneShotSynthesizer(
        solver_2, arch, 2, [smt_gadget0, smt_gadget1]*100, OnlyUsedRegisterStateBuilder)

    start = timer()
    synthesizer_1.add_instance(
        memory_layout, AllUntaintedAssumptions(), RaxIsOneSpecifications())
    synthesizer_2.add_instance(
        memory_layout, AllUntaintedAssumptions(), RaxIsOneSpecifications())
    chain_1 = synthesizer_1.synthesize()
    chain_2 = synthesizer_2.synthesize()
    end = timer()
    assert chain_1 is None
    assert chain_2 is not None
    for gadget in chain_2.chain:
        LOGGER.info(gadget.assembly_str)
    LOGGER.info(f"Found in {end - start}s")


def test_basic_incremental_x86_synthesis():
    gadget0 = RawGadget('xor rax, rax; ret', 0xb41a9, b'\x48\x31\xC0\xC3', 2)
    gadget1 = RawGadget('add rax, 1; ret', 0xc8480,
                        b'\x48\x83\xC0\x01\xC3', 2)

    translator = BinaryNinjaTranslator(Platform.LINUX)

    # lifted_gadget0 = CustomWorkflowSSAGadgetAnalysis.lift_raw_gadget(
    #     gadget0, Architecture.x86_64, Platform.LINUX)
    # lifted_gadget1 = CustomWorkflowSSAGadgetAnalysis.lift_raw_gadget(
    #     gadget1, Architecture.x86_64, Platform.LINUX)

    smt_gadget0 = translator.translate_single(Architecture.x86_64, gadget0)
    smt_gadget1 = translator.translate_single(Architecture.x86_64, gadget1)

    # LOGGER.info(smt_gadget0._final_formula)
    # LOGGER.info(smt_gadget1._final_formula)

    memory_layout = MemoryLayout()
    memory_layout.add_region(
        0x00007FFF00000000, 0x00007FFF0000000F, readable=True, writable=False)

    class AllUntaintedAssumptions(Assumptions):
        def __init__(self):
            pass

        def assumptions(self, input: State) -> fnode.FNode:
            memory = input.memory.clone_untainted().taint_range(
                0x00007FFF00000000, 0x40)
            memory_assertions = input.memory.Equals(memory)
            assertions = [memory_assertions]
            for regname, reg in input.registers.items():
                if regname == 'rip':
                    assertions.append(reg.taint)
                elif regname == 'rsp':
                    assertions.append(reg.Equals(
                        TaintedBitvec.from_int(0x00007FFF00000000, reg.bv_width)))
                else:
                    assertions.append(reg.Equals(
                        TaintedBitvec.new_zero_untainted(reg.bv_width)))

            assumptions = And(assertions)
            return assumptions

    class RaxIsOneSpecifications(Specifications):
        def __init__(self):
            pass

        def specifications(self, _: State, output: State) -> fnode.FNode:
            rax = output.registers["rax"]
            rip = output.registers['rip']
            rax_is_one = rax.Equals(TaintedBitvec.from_int(1, rax.bv_width))
            rip_is_arb = rip.Equals(
                TaintedBitvec.from_int(0xDEADC0DE, rip.bv_width))
            assertions = And([rax_is_one, rip_is_arb])
            return assertions

    arch = binaryninja_arch_to_synthesizer_arch_info(
        binaryninja.Architecture['x86_64'])

    solver = Solver(logic=QF_AUFBV, name="btor")
    synthesizer = IncrementalSynthesizer(
        solver, arch, [smt_gadget0, smt_gadget1]*100, OnlyUsedRegisterStateBuilder)
    start = timer()
    chain = synthesizer.synthesize(
        2, memory_layout, AllUntaintedAssumptions(), RaxIsOneSpecifications())
    end = timer()
    assert chain is not None
    for gadget in chain.chain:
        LOGGER.info(gadget.assembly_str)
    LOGGER.info(f"Found in {end - start}s")


def test_incremental_x86_synthesis_ls():
    extractor = RopperExtractor()
    LOGGER.info("Extracting gadgets...")
    gadgets = extractor.extract_from_elf("/bin/ls", base=0x1000)
    translator = BinaryNinjaTranslator(Platform.LINUX, Z3Simplifier())
    library = translator.translate_library(
        gadgets)

    smt_gadgets = library.gadgets
    # lifted_gadgets = filter(lambda gadget: gadget is not None, map(
    #     lambda rawgadget: CustomWorkflowSSAGadgetAnalysis.lift_raw_gadget(rawgadget, Architecture.x86_64, Platform.LINUX), gadgets.gadgets))
    # simplifier = Z3Simplifier()
    # smt_gadgets = list(
    #     filter(lambda smt: True or not smt.has_select_after_store_operation, map(lambda lifted_gadget: SMTGadget(lifted_gadget, simplifier), lifted_gadgets)))

    memory_layout = MemoryLayout()
    memory_layout.add_region(
        0x00007FFF00000000, 0x00007FFF0000003F, readable=True, writable=False)

    class AllUntaintedAssumptions(Assumptions):
        def __init__(self):
            pass

        def assumptions(self, input: State) -> fnode.FNode:
            memory = input.memory.clone_untainted().taint_range(
                0x00007FFF00000000, 0x40)
            memory_assertions = input.memory.Equals(memory)
            assertions = [memory_assertions]
            for regname, reg in input.registers.items():
                if regname == 'rip':
                    assertions.append(reg.taint)
                elif regname == 'rsp':
                    assertions.append(reg.Equals(
                        TaintedBitvec.from_int(0x00007FFF00000000, reg.bv_width)))
                else:
                    assertions.append(reg.Equals(
                        TaintedBitvec.new_zero_untainted(reg.bv_width)))

            assumptions = And(assertions)
            return assumptions

    class SetRaxRbxSpecifications(Specifications):
        def __init__(self):
            pass

        def specifications(self, _: State, output: State) -> fnode.FNode:
            rax = output.registers["rax"]
            rbx = output.registers["rbx"]
            rip = output.registers['rip']
            rax_is_one = rax.Equals(
                TaintedBitvec.from_int(0xDEADBEEF, rax.bv_width))
            rbx_is_one = rbx.Equals(
                TaintedBitvec.from_int(0xDEAD0DAD, rbx.bv_width))
            rip_is_arb = rip.Equals(
                TaintedBitvec.from_int(0xDEADC0DE, rip.bv_width))
            assertions = And([rax_is_one, rbx_is_one, rip_is_arb])
            return assertions

    arch = binaryninja_arch_to_synthesizer_arch_info(
        binaryninja.Architecture['x86_64'])

    solver = Solver(logic='QF_AUFBV*', name='btor')
    synthesizer = IncrementalSynthesizer(
        solver, arch, smt_gadgets, OnlyUsedRegisterStateBuilder)
    start = timer()
    chain = synthesizer.synthesize(
        2, memory_layout, AllUntaintedAssumptions(), SetRaxRbxSpecifications())
    end = timer()
    if chain is not None:
        for gadget in chain.chain:
            LOGGER.info(gadget.assembly_str)
    LOGGER.info(f"Done in {end - start}s")


def test_deserialize_x86_ls():
    extractor = RopperExtractor()
    LOGGER.info("Extracting gadgets...")
    gadgets = extractor.extract_from_elf("/bin/ls", base=0x1000)
    LOGGER.info("Translating gadgets...")
    translator = BinaryNinjaTranslator(Platform.LINUX, Z3Simplifier())
    library = translator.translate_library(
        gadgets)
    LOGGER.info("Serializing library to JSON...")
    j = library.to_json_str()
    LOGGER.info("Deserializing library...")
    deserialized = GadgetLibrary.from_json_str(j)

    LOGGER.info("Checking for equality...")
    assert library == deserialized
