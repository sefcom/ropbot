"""
These procedures implement functions described in the gnulib library: https://www.gnu.org/software/gnulib/
"""
