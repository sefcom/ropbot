from arcanist.architecture import Architecture
from arcanist.extractor.ropper import RopperExtractor


def test_ropper():
    extractor = RopperExtractor()
    gadgets = extractor.extract_from_elf("/bin/ls", base=0x1000)
    assert gadgets.architecture == Architecture.x86_64
