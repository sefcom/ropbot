from binaryninja.architecture import IntrinsicInfo, Architecture, IntrinsicIndex, IntrinsicName

GADGET_EXIT_INTRINSIC_NAME = 'gadget'


def inject_gadget_exit_intrinsic(base: Architecture):
    # kinda very hacky :S
    i = 0
    while base._intrinsics_by_index.get(IntrinsicIndex(i)) is not None:
        i += 1
    intrinsic_index = IntrinsicIndex(i)
    intrinsic = IntrinsicName(GADGET_EXIT_INTRINSIC_NAME)
    info = IntrinsicInfo([], [], intrinsic_index)
    base._intrinsics[intrinsic] = intrinsic_index
    base._intrinsics_by_index[intrinsic_index] = (intrinsic, info)

# Would be better that way, but custom intrinsics are not supported it seems...
#
# class GadgetExitIntrinsicArchHook(ArchitectureHook):
#     intrinsics = {'gadget exit': IntrinsicInfo([], [])}

#     def __init__(self, base: Architecture):
#         super(GadgetExitIntrinsicArchHook, self).__init__(base)
