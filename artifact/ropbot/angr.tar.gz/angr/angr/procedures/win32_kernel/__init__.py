"""
These procedures implement functions from the Windows kernel.
"""
