Build-in Analyses
=================

.. toctree::
   :maxdepth: 1

   cfg
   backward_slice
   identifier
   decompiler
