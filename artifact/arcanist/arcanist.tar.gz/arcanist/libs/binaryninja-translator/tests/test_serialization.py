from arcanist.architecture import Architecture
from arcanist.gadgets.extraction import RawGadget
from arcanist.platform import Platform
from arcanist.synthesizer.gadget import JSONGadget
from arcanist.translator.binaryninja.llil_gadget import CustomWorkflowSSAGadgetAnalysis
from arcanist.translator.binaryninja.smt_gadget import SMTGadget

import logging

from arcanist.translator.binaryninja.translate import BinaryNinjaTranslator
LOGGER = logging.getLogger(__name__)


def test_serialize_x86_gadget():
    gadget0 = RawGadget('xor rax, rax; ret', 0xb41a9, b'\x48\x31\xC0\xC3', 2)
    translator = BinaryNinjaTranslator(Platform.LINUX)
    smt_gadget0 = translator.translate_single(Architecture.x86_64, gadget0)

    arch = smt_gadget0.arch_info
    json = smt_gadget0.to_json_str()
    json_gadget0 = JSONGadget.from_json_str(arch, json)

    assert smt_gadget0.inputs == json_gadget0.inputs
    assert smt_gadget0.outputs == json_gadget0.outputs
    assert smt_gadget0.memory_predicates == json_gadget0.memory_predicates
    assert smt_gadget0.formula == json_gadget0.formula
