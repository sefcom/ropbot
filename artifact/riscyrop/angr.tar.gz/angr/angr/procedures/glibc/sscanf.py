from __future__ import annotations
from angr.procedures.libc.sscanf import sscanf


class __isoc99_sscanf(sscanf):
    pass
