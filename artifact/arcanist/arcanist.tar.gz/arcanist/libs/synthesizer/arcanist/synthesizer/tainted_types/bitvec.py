from __future__ import annotations

from multimethod import multimethod
from .taint import SingleTaintValue
from .bool import TaintedBool

from pysmt import fnode
from pysmt.shortcuts import BVNot, BVNeg, SBV, BV, BVOne, BVZero, FreshSymbol, Symbol, BOOL, TRUE, FALSE, Bool
from pysmt.typing import BVType
from pysmt.exceptions import PysmtTypeError
from pysmt.simplifier import Simplifier
from typing import Any, Self, cast


class TaintedBitvec(SingleTaintValue):
    def __init__(self, value: fnode.FNode, taint: fnode.FNode):
        super().__init__(value, taint)
        if not value.get_type().is_bv_type():
            raise PysmtTypeError(
                f"Expected symbol type of 'value' to be 'BV' for constructing '{self.__class__.__name__}', got '{value.get_type()}' instead")

    @property
    def bv_width(self) -> int:
        return cast(int, self.value.bv_width())

    @classmethod
    def with_name(cls, name: str, width: int) -> Self:
        value = Symbol(name + "_value", BVType(width))
        taint = Symbol(name + "_taint", BOOL)
        return cls(value, taint)

    @classmethod
    def new_zero_untainted(cls, width: int) -> Self:
        value = BVZero(width)
        taint = FALSE()
        return cls(value, taint)

    # @classmethod
    # def fresh(cls, template: str, width: int) -> Self:
    #     value = FreshSymbol(template + "_value", BVType(width))
    #     taint = FreshSymbol(template + "_taint", BOOL)
    #     return cls(value, taint)

    @classmethod
    def from_int(cls, value: int, width: int) -> Self:
        value = BV(value, width) if value >= 0 else SBV(value, width)
        taint = TRUE()
        return cls(value, taint)

    @classmethod
    def from_tainted_bool(cls, tbool: TaintedBool, width: int = 1) -> Self:
        value = tbool.value.Ite(BVOne(width), BVZero(width))
        taint = tbool.taint
        return cls(value, taint)

    def to_tainted_bool(self) -> TaintedBool:
        value = self.value.BVUGT(BVZero(self.bv_width))
        taint = self.taint
        return TaintedBool(value, taint)

    def __neg__(self) -> TaintedBitvec:
        value = BVNeg(self.value)
        taint = self.taint
        return TaintedBitvec(value, taint)

    def __invert__(self) -> TaintedBitvec:
        value = BVNot(self.value)
        taint = self.taint
        return TaintedBitvec(value, taint)

    @multimethod
    def __add__(self, other: Any) -> Self:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec '+' operator")

    @multimethod
    def __sub__(self, other: Any) -> Self:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec '-' operator")

    @multimethod
    def __mul__(self, other: Any) -> Self:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec '*' operator")

    @multimethod
    def __truediv__(self, other: Any) -> Self:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec '/' operator")

    @multimethod
    def __mod__(self, other: Any) -> Self:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec '%' operator")

    @multimethod
    def __rshift__(self, other: Any) -> Self:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec '>>' operator")

    @multimethod
    def __lshift__(self, other: Any) -> Self:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec '<<' operator")

    @multimethod
    def __and__(self, other: Any) -> Self:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec '&' operator")

    @multimethod
    def __or__(self, other: Any) -> Self:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec '|' operator")

    @multimethod
    def __xor__(self, other: Any) -> Self:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec '^' operator")

    @multimethod
    def __lt__(self, other: Any) -> TaintedBool:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec '<' operator")

    @multimethod
    def __gt__(self, other: Any) -> TaintedBool:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec '>' operator")

    @multimethod
    def __le__(self, other: Any) -> TaintedBool:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec '<=' operator")

    @multimethod
    def __ge__(self, other: Any) -> TaintedBool:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec '>=' operator")

    @multimethod
    def SLt(self, other: Any) -> TaintedBool:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec *signed* '<' operator")

    @multimethod
    def SGt(self, other: Any) -> TaintedBool:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec *signed* '>' operator")

    @multimethod
    def SLe(self, other: Any) -> TaintedBool:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec *signed* '<=' operator")

    @multimethod
    def SGe(self, other: Any) -> TaintedBool:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec *signed* '>=' operator")

    @multimethod
    def Concat(self, other: Any) -> TaintedBitvec:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec 'concat' operator")

    @multimethod
    def SignedAddOverflow(self, other: Any) -> TaintedBool:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec 'add_overflow' operator")

    @multimethod
    def SignedAddUnderflow(self, other: Any) -> TaintedBool:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec 'add_underflow' operator")

    @multimethod
    def SignedSubOverflow(self, other: Any) -> TaintedBool:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec 'add_overflow' operator")

    @multimethod
    def SignedSubUnderflow(self, other: Any) -> TaintedBool:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec 'add_underflow' operator")

    @multimethod
    def Rol(self, other: Any) -> TaintedBitvec:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec 'rol' operator")

    @multimethod
    def Ror(self, other: Any) -> TaintedBitvec:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec 'ror' operator")

    @multimethod
    def Asr(self, other: Any) -> TaintedBitvec:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec 'asr' operator")

    @multimethod
    def SignedDiv(self, other: Any) -> TaintedBitvec:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec *signed* '/' operator")

    @multimethod
    def SignedMod(self, other: Any) -> TaintedBitvec:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec *signed* '%' operator")

    def ZeroExtend(self, increase: int) -> TaintedBitvec:
        value = self.value.BVZExt(increase)
        taint = self.taint
        return TaintedBitvec(value, taint)

    def SignExtend(self, increase: int) -> TaintedBitvec:
        value = self.value.BVSExt(increase)
        taint = self.taint
        return TaintedBitvec(value, taint)

    def Extract(self, start: int, stop: int) -> TaintedBitvec:
        value = self.value.BVExtract(start, stop)
        taint = self.taint
        return TaintedBitvec(value, taint)

    @multimethod
    def Equals(self, other: Any) -> fnode.FNode:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec 'Equals' operator")

    @multimethod
    def tainted_equals(self, other: Any) -> TaintedBool:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec '==' (tainted) operator")

    @multimethod
    def tainted_not_equals(self, other: Any) -> TaintedBool:
        raise TypeError(
            f"Invalid type {type(other).__name__} for TaintedBitvec '!=' (tainted) operator")

    def simplify(self, simplifier: Simplifier = Simplifier()) -> TaintedBitvec:
        return TaintedBitvec(simplifier.simplify(self.value), simplifier.simplify(self.taint))


@TaintedBitvec.Equals.register
def _(self, other: TaintedBitvec) -> TaintedBool:
    return self.value.Equals(other.value) & self.taint.Iff(other.taint)


@TaintedBitvec.Equals.register
def _(self, other: int) -> TaintedBool:
    return self.value.Equals(other) & self.taint


@TaintedBitvec.tainted_equals.register
def _(self, other: TaintedBitvec) -> TaintedBool:
    value = self.value.Equals(other.value)
    taint = self.taint & other.taint
    return TaintedBool(value, taint)


@TaintedBitvec.tainted_equals.register
def _(self, other: int) -> TaintedBool:
    value = self.value.Equals(other)
    taint = self.taint
    return TaintedBool(value, taint)


@TaintedBitvec.tainted_not_equals.register
def _(self, other: TaintedBitvec) -> TaintedBool:
    value = self.value.NotEquals(other.value)
    taint = self.taint & other.taint
    return TaintedBool(value, taint)


@TaintedBitvec.tainted_not_equals.register
def _(self, other: int) -> TaintedBool:
    value = self.value.NotEquals(other)
    taint = self.taint
    return TaintedBool(value, taint)


@TaintedBitvec.__add__.register
def _(self, other: TaintedBitvec) -> TaintedBitvec:
    value = self.value + other.value
    taint = self.taint & other.taint
    return TaintedBitvec(value, taint)


@TaintedBitvec.__add__.register
def _(self, other: int) -> TaintedBitvec:
    value = self.value + other
    taint = self.taint
    return TaintedBitvec(value, taint)


@TaintedBitvec.__sub__.register
def _(self, other: TaintedBitvec) -> TaintedBitvec:
    value = self.value - other.value
    taint = self.taint & other.taint
    return TaintedBitvec(value, taint)


@TaintedBitvec.__sub__.register
def _(self, other: int) -> TaintedBitvec:
    value = self.value - other
    taint = self.taint
    return TaintedBitvec(value, taint)


@TaintedBitvec.__mul__.register
def _(self, other: TaintedBitvec) -> TaintedBitvec:
    zero = BV(0, self.bv_width)
    value = self.value * other.value
    taint = (self.taint & other.taint) | (self.taint & self.value.Equals(
        zero)) | (other.taint & other.value.Equals(zero))
    return TaintedBitvec(value, taint)


@TaintedBitvec.__mul__.register
def _(self, other: int) -> TaintedBitvec:
    value = self.value * other
    taint = self.taint if other != 0 else TRUE()
    return TaintedBitvec(value, taint)


@TaintedBitvec.__truediv__.register
def _(self, other: TaintedBitvec) -> TaintedBitvec:
    value = self.value / other.value
    taint = self.taint & other.taint
    return TaintedBitvec(value, taint)


@TaintedBitvec.__truediv__.register
def _(self, other: int) -> TaintedBitvec:
    value = self.value / other
    taint = self.taint
    return TaintedBitvec(value, taint)


@TaintedBitvec.__mod__.register
def _(self, other: TaintedBitvec) -> TaintedBitvec:
    value = self.value % other.value
    taint = (self.taint & other.taint) | (
        other.taint & other.value.Equals(BVOne(self.bv_width)))
    return TaintedBitvec(value, taint)


@TaintedBitvec.__mod__.register
def _(self, other: int) -> TaintedBitvec:
    value = self.value % other
    taint = self.taint if other != 1 else TRUE()
    return TaintedBitvec(value, taint)


@TaintedBitvec.__rshift__.register
def _(self, other: TaintedBitvec) -> TaintedBitvec:
    bv_width = BV(self.bv_width, self.bv_width)
    value = self.value >> other.value
    taint = (self.taint & other.taint) | (
        other.taint & (other.value >= bv_width))
    return TaintedBitvec(value, taint)


@TaintedBitvec.__rshift__.register
def _(self, other: int) -> TaintedBitvec:
    value = self.value >> other
    taint = self.taint if other < self.bv_width else TRUE()
    return TaintedBitvec(value, taint)


@TaintedBitvec.__lshift__.register
def _(self, other: TaintedBitvec) -> TaintedBitvec:
    bv_width = BV(self.bv_width, self.bv_width)
    value = self.value << other.value
    taint = (self.taint & other.taint) | (
        other.taint & (other.value >= bv_width))
    return TaintedBitvec(value, taint)


@TaintedBitvec.__lshift__.register
def _(self, other: int) -> TaintedBitvec:
    value = self.value << other
    taint = self.taint if other < self.bv_width else TRUE()
    return TaintedBitvec(value, taint)


@TaintedBitvec.__and__.register
def _(self, other: TaintedBitvec) -> TaintedBitvec:
    all_zero = BVZero(self.bv_width)
    value = self.value & other.value
    taint = (self.taint & other.taint) | (self.taint &
                                          self.value.Equals(all_zero)) | (other.taint & other.value.Equals(all_zero))
    return TaintedBitvec(value, taint)


@TaintedBitvec.__and__.register
def _(self, other: int) -> TaintedBitvec:
    value = self.value & other
    taint = self.taint if other != 0 else TRUE()
    return TaintedBitvec(value, taint)


@TaintedBitvec.__or__.register
def _(self, other: TaintedBitvec) -> TaintedBitvec:
    all_one = BV((1 << self.bv_width)-1, self.bv_width)
    value = self.value | other.value
    taint = (self.taint & other.taint) | (self.taint &
                                          self.value.Equals(all_one)) | (other.taint & other.value.Equals(all_one))
    return TaintedBitvec(value, taint)


@TaintedBitvec.__or__.register
def _(self, other: int) -> TaintedBitvec:
    all_one = (1 << self.bv_width) - 1
    value = self.value | other
    taint = self.taint if other != all_one else TRUE()
    return TaintedBitvec(value, taint)


@TaintedBitvec.__xor__.register
def _(self, other: TaintedBitvec) -> TaintedBitvec:
    value = self.value ^ other.value
    taint = self.taint & other.taint
    return TaintedBitvec(value, taint)


@TaintedBitvec.__xor__.register
def _(self, other: int) -> TaintedBitvec:
    value = self.value ^ other
    taint = self.taint
    return TaintedBitvec(value, taint)


@TaintedBitvec.__lt__.register
def _(self, other: TaintedBitvec) -> TaintedBool:
    value = self.value < other.value
    taint = self.taint & other.taint
    return TaintedBool(value, taint)


@TaintedBitvec.__lt__.register
def _(self, other: int) -> TaintedBool:
    value = self.value < other
    taint = self.taint
    return TaintedBool(value, taint)


@TaintedBitvec.__gt__.register
def _(self, other: TaintedBitvec) -> TaintedBool:
    value = self.value > other.value
    taint = self.taint & other.taint
    return TaintedBool(value, taint)


@TaintedBitvec.__gt__.register
def _(self, other: int) -> TaintedBool:
    value = self.value > other
    taint = self.taint
    return TaintedBool(value, taint)


@TaintedBitvec.__le__.register
def _(self, other: TaintedBitvec) -> TaintedBool:
    all_zero = BVZero(self.bv_width)
    all_one = BV((1 << self.bv_width)-1, self.bv_width)
    value = self.value <= other.value
    taint = (self.taint & other.taint) | (self.taint & self.value.Equals(
        all_zero)) | (other.taint & other.value.Equals(all_one))
    return TaintedBool(value, taint)


@TaintedBitvec.__le__.register
def _(self, other: int) -> TaintedBool:
    maximum_unsigned = (1 << self.bv_width) - 1
    value = self.value <= other
    taint = self.taint if other != maximum_unsigned else TRUE()
    return TaintedBool(value, taint)


@TaintedBitvec.__ge__.register
def _(self, other: TaintedBitvec) -> TaintedBool:
    all_zero = BVZero(self.bv_width)
    all_one = BV((1 << self.bv_width)-1, self.bv_width)
    value = self.value >= other.value
    taint = (self.taint & other.taint) | (self.taint & self.value.Equals(
        all_one)) | (other.taint & other.value.Equals(all_zero))
    return TaintedBool(value, taint)


@TaintedBitvec.__ge__.register
def _(self, other: int) -> TaintedBool:
    value = self.value >= other
    taint = self.taint if other != 0 else TRUE()
    return TaintedBool(value, taint)


@TaintedBitvec.SLt.register
def _(self, other: TaintedBitvec) -> TaintedBool:
    value = self.value.BVSLT(other.value)
    taint = self.taint & other.taint
    return TaintedBool(value, taint)


@TaintedBitvec.SLt.register
def _(self, other: int) -> TaintedBool:
    value = self.value.BVSLT(other)
    taint = self.taint
    return TaintedBool(value, taint)


@TaintedBitvec.SGt.register
def _(self, other: TaintedBitvec) -> TaintedBool:
    value = self.value.BVSGT(other.value)
    taint = self.taint & other.taint
    return TaintedBool(value, taint)


@TaintedBitvec.SGt.register
def _(self, other: int) -> TaintedBool:
    value = self.value.BVSGT(other)
    taint = self.taint
    return TaintedBool(value, taint)


@TaintedBitvec.SLe.register
def _(self, other: TaintedBitvec) -> TaintedBool:
    signed_minimum = BV(1 << (self.bv_width - 1), self.bv_width)
    signed_maximum = BV((1 << (self.bv_width - 1)) - 1, self.bv_width)
    value = self.value.BVSLE(other.value)
    taint = (self.taint & other.taint) | (self.taint & self.value.Equals(
        signed_minimum)) | (other.taint & other.value.Equals(signed_maximum))
    return TaintedBool(value, taint)


@TaintedBitvec.SLe.register
def _(self, other: int) -> TaintedBool:
    signed_maximum = (1 << (self.bv_width - 1)) - 1
    value = self.value.BVSLE(other)
    taint = self.taint if other != signed_maximum else TRUE()
    return TaintedBool(value, taint)


@TaintedBitvec.SGe.register
def _(self, other: TaintedBitvec) -> TaintedBool:
    signed_minimum = BV(1 << (self.bv_width - 1), self.bv_width)
    signed_maximum = BV((1 << (self.bv_width - 1)) - 1, self.bv_width)
    value = self.value.BVSGE(other.value)
    taint = (self.taint & other.taint) | (self.taint & self.value.Equals(
        signed_maximum)) | (other.taint & other.value.Equals(signed_minimum))
    return TaintedBool(value, taint)


@TaintedBitvec.SGe.register
def _(self, other: int) -> TaintedBool:
    signed_minimum = - (1 << (self.bv_width - 1))
    value = self.value.BVSGE(other)
    taint = self.taint if other != signed_minimum else TRUE()
    return TaintedBool(value, taint)


@TaintedBitvec.Concat.register
def _(self, other: TaintedBitvec) -> TaintedBitvec:
    value = self.value.BVConcat(other.value)
    taint = self.taint & other.taint
    return TaintedBitvec(value, taint)


@TaintedBitvec.SignedAddOverflow.register
def _(self, other: TaintedBitvec) -> TaintedBool:
    zero = BVZero(self.bv_width)
    bv_sum = self.value + other.value
    is_sum_neg = bv_sum.BVSLT(zero)
    is_self_pos = zero.BVSLT(self.value)
    is_other_pos = zero.BVSLT(other.value)
    all_operands_positive = is_self_pos & is_other_pos

    value = all_operands_positive & is_sum_neg
    # TODO: more precise taint propagation? when self or other is zero?
    taint = self.taint & other.taint
    return TaintedBool(value, taint)


@TaintedBitvec.SignedAddOverflow.register
def _(self, other: int) -> TaintedBool:
    return self.SignedAddOverflow(self, TaintedBitvec.from_int(other, self.bv_width))


@TaintedBitvec.SignedAddUnderflow.register
def _(self, other: TaintedBitvec) -> TaintedBool:
    zero = BVZero(self.bv_width)
    bv_sum = self.value + other.value
    is_sum_pos = zero.BVSLE(bv_sum)
    is_self_neg = self.value.BVSLT(zero)
    is_other_neg = other.value.BVSLT(zero)
    all_operands_negative = is_self_neg & is_other_neg

    value = all_operands_negative & is_sum_pos
    # TODO: more precise taint propagation? when self or other is zero?
    taint = self.taint & other.taint
    return TaintedBool(value, taint)


@TaintedBitvec.SignedAddUnderflow.register
def _(self, other: int) -> TaintedBool:
    return self.SignedAddUnderflow(self, TaintedBitvec.from_int(other, self.bv_width))


@TaintedBitvec.SignedSubOverflow.register
def _(self, other: TaintedBitvec) -> TaintedBool:
    return self.SignedAddOverflow(-other)


@TaintedBitvec.SignedSubOverflow.register
def _(self, other: int) -> TaintedBool:
    return self.SignedSubOverflow(self, TaintedBitvec.from_int(other, self.bv_width))


@TaintedBitvec.SignedSubUnderflow.register
def _(self, other: TaintedBitvec) -> TaintedBool:
    return self.SignedAddUnderflow(-other)


@TaintedBitvec.SignedSubUnderflow.register
def _(self, other: int) -> TaintedBool:
    return self.SignedSubUnderflow(self, TaintedBitvec.from_int(other, self.bv_width))


@TaintedBitvec.Rol.register
def _(self, other: TaintedBitvec) -> TaintedBitvec:
    value = self.value.BVRol(other.value)
    taint = self.taint & other.taint
    return TaintedBitvec(value, taint)


@TaintedBitvec.Rol.register
def _(self, other: int) -> TaintedBitvec:
    value = self.value.BVRol(other)
    taint = self.taint
    return TaintedBitvec(value, taint)


@TaintedBitvec.Ror.register
def _(self, other: TaintedBitvec) -> TaintedBitvec:
    value = self.value.BVRor(other.value)
    taint = self.taint & other.taint
    return TaintedBitvec(value, taint)


@TaintedBitvec.Ror.register
def _(self, other: int) -> TaintedBitvec:
    value = self.value.BVRor(other)
    taint = self.taint
    return TaintedBitvec(value, taint)


@TaintedBitvec.Asr.register
def _(self, other: TaintedBitvec) -> TaintedBitvec:
    value = self.value.BVAShr(other.value)
    taint = self.taint & other.taint
    return TaintedBitvec(value, taint)


@TaintedBitvec.Asr.register
def _(self, other: int) -> TaintedBitvec:
    value = self.value.BVAShr(other)
    taint = self.taint
    return TaintedBitvec(value, taint)


@TaintedBitvec.SignedDiv.register
def _(self, other: TaintedBitvec) -> TaintedBitvec:
    value = self.value.BVSDiv(other.value)
    taint = self.taint & other.taint
    return TaintedBitvec(value, taint)


@TaintedBitvec.SignedDiv.register
def _(self, other: int) -> TaintedBitvec:
    value = self.value.BVSDiv(other)
    taint = self.taint
    return TaintedBitvec(value, taint)


@TaintedBitvec.SignedMod.register
def _(self, other: TaintedBitvec) -> TaintedBitvec:
    value = self.value.BVSMod(other.value)
    # FIXME: better taint propagation when other is one?
    taint = self.taint & other.taint
    return TaintedBitvec(value, taint)


@TaintedBitvec.SignedMod.register
def _(self, other: int) -> TaintedBitvec:
    value = self.value.BVSMod(other)
    # FIXME: better taint propagation when other is one?
    taint = self.taint
    return TaintedBitvec(value, taint)

###############################################################################
# TaintedBool If-Then-Else for TaintedBitvec                                  #
###############################################################################


@TaintedBool.Ite.register
def _(self, then: TaintedBitvec, elze: TaintedBitvec) -> TaintedBitvec:
    if type(then) != type(elze):
        raise TypeError(
            f"Both sides of if-then-else should be of same type, but got 'then':{type(then)}, 'else':{type(elze)}")

    value = self.value.Ite(then.value, elze.value)
    taint = (then.taint & elze.taint & (then.value.Equals(elze.value))) | (
        self.taint & (self.value.Ite(then.taint, elze.taint)))
    return then.__class__(value, taint)
